﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace newform
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        public static Dictionary<string, string> Users = new Dictionary<string, string>();

        public static void Load_users()
        {
            Users.Add("Orkhan", "12345AA");
            Users.Add("Samir", "1agAA");
            Users.Add("Afaq", "0000AA");
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Load_users();

            string Get_name = textBox1.Text;
            string Get_password = textBox2.Text;

            for (int i = 0; i < Users.Count; i++)
            {
                if(Users.ContainsKey(Get_name) && Users[Get_name].CompareTo(Get_password) == 0)
                {
                    MessageBox.Show("You are in system");
                    break;
                }
                else if (i == Users.Count-1)
                {
                    MessageBox.Show("Error message");
                }
            }

            Users.Clear();
        }
    }
}
