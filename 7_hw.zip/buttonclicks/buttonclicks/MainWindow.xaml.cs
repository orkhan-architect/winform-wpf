﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace buttonclicks
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        public Random rnd;

        public void left_click_operation(Button btn)
        {
            byte[] colors = new byte[3];
            for (byte i = 0; i < 3; i++)
            {
                rnd = new Random();
                colors[i] = Convert.ToByte(rnd.Next(0, 255));
            }
            btn.Background = new SolidColorBrush(Color.FromRgb(colors[0], colors[1], colors[2]));

            var about_btn = new StringBuilder();
            about_btn.Append("button name ->" + btn.Name.ToString() + "\n");
            about_btn.Append("button color ->" + btn.Background.ToString() + "\n");
            about_btn.Append("button content ->" + btn.Content.ToString() + "\n");
            about_btn.Append("button font weight ->" + btn.FontWeight.ToString() + "\n");
            about_btn.Append("button font size ->" + btn.FontSize.ToString() + "\n");

            MessageBox.Show(about_btn.ToString());
        }

        public void right_click_operation(Button btn)
        {
            mywindow.Title = "button " + btn.Content.ToString();
            btn.Visibility = Visibility.Hidden;
        }

        private void btn_1_Click(object sender, RoutedEventArgs e)
        {
            left_click_operation(btn_1);
        }

        private void btn_2_Click(object sender, RoutedEventArgs e)
        {
            left_click_operation(btn_2);
        }

        private void btn_3_Click(object sender, RoutedEventArgs e)
        {
            left_click_operation(btn_3);
        }

        private void btn_4_Click(object sender, RoutedEventArgs e)
        {
            left_click_operation(btn_4);
        }

        private void btn_5_Click(object sender, RoutedEventArgs e)
        {
            left_click_operation(btn_5);
        }

        private void btn_6_Click(object sender, RoutedEventArgs e)
        {
            left_click_operation(btn_6);
        }

        private void btn_1_MouseRightButtonDown(object sender, MouseButtonEventArgs e)
        {
            right_click_operation(btn_1);
        }

        private void btn_2_MouseRightButtonDown(object sender, MouseButtonEventArgs e)
        {
            right_click_operation(btn_2);
        }

        private void btn_3_MouseRightButtonDown(object sender, MouseButtonEventArgs e)
        {
            right_click_operation(btn_3);
        }

        private void btn_4_MouseRightButtonDown(object sender, MouseButtonEventArgs e)
        {
            right_click_operation(btn_4);
        }

        private void btn_5_MouseRightButtonDown(object sender, MouseButtonEventArgs e)
        {
            right_click_operation(btn_5);
        }

        private void btn_6_MouseRightButtonDown(object sender, MouseButtonEventArgs e)
        {
            right_click_operation(btn_6);
        }
    }
}
