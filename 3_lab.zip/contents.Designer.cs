﻿namespace asilimenu
{
    partial class content_form
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.prod_name_lbl = new System.Windows.Forms.Label();
            this.prod_name_txtbox = new System.Windows.Forms.TextBox();
            this.country_txtbox = new System.Windows.Forms.TextBox();
            this.country_lbl = new System.Windows.Forms.Label();
            this.cost_txtbox = new System.Windows.Forms.TextBox();
            this.cost_lbl = new System.Windows.Forms.Label();
            this.save_btn = new System.Windows.Forms.Button();
            this.cancel_btn = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // prod_name_lbl
            // 
            this.prod_name_lbl.AutoSize = true;
            this.prod_name_lbl.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.prod_name_lbl.Location = new System.Drawing.Point(12, 9);
            this.prod_name_lbl.Name = "prod_name_lbl";
            this.prod_name_lbl.Size = new System.Drawing.Size(93, 19);
            this.prod_name_lbl.TabIndex = 0;
            this.prod_name_lbl.Text = "Product name";
            // 
            // prod_name_txtbox
            // 
            this.prod_name_txtbox.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.prod_name_txtbox.Location = new System.Drawing.Point(16, 31);
            this.prod_name_txtbox.Name = "prod_name_txtbox";
            this.prod_name_txtbox.Size = new System.Drawing.Size(194, 26);
            this.prod_name_txtbox.TabIndex = 1;
            // 
            // country_txtbox
            // 
            this.country_txtbox.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.country_txtbox.Location = new System.Drawing.Point(16, 95);
            this.country_txtbox.Name = "country_txtbox";
            this.country_txtbox.Size = new System.Drawing.Size(194, 26);
            this.country_txtbox.TabIndex = 3;
            // 
            // country_lbl
            // 
            this.country_lbl.AutoSize = true;
            this.country_lbl.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.country_lbl.Location = new System.Drawing.Point(12, 73);
            this.country_lbl.Name = "country_lbl";
            this.country_lbl.Size = new System.Drawing.Size(95, 19);
            this.country_lbl.TabIndex = 2;
            this.country_lbl.Text = "Origin country";
            // 
            // cost_txtbox
            // 
            this.cost_txtbox.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.cost_txtbox.Location = new System.Drawing.Point(16, 163);
            this.cost_txtbox.Name = "cost_txtbox";
            this.cost_txtbox.Size = new System.Drawing.Size(194, 26);
            this.cost_txtbox.TabIndex = 5;
            // 
            // cost_lbl
            // 
            this.cost_lbl.AutoSize = true;
            this.cost_lbl.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.cost_lbl.Location = new System.Drawing.Point(12, 141);
            this.cost_lbl.Name = "cost_lbl";
            this.cost_lbl.Size = new System.Drawing.Size(86, 19);
            this.cost_lbl.TabIndex = 4;
            this.cost_lbl.Text = "Product cost";
            // 
            // save_btn
            // 
            this.save_btn.AutoSize = true;
            this.save_btn.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.save_btn.Location = new System.Drawing.Point(16, 216);
            this.save_btn.Name = "save_btn";
            this.save_btn.Size = new System.Drawing.Size(75, 29);
            this.save_btn.TabIndex = 6;
            this.save_btn.Text = "Ok";
            this.save_btn.UseVisualStyleBackColor = true;
            this.save_btn.Click += new System.EventHandler(this.save_btn_Click);
            // 
            // cancel_btn
            // 
            this.cancel_btn.AutoSize = true;
            this.cancel_btn.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.cancel_btn.Location = new System.Drawing.Point(135, 216);
            this.cancel_btn.Name = "cancel_btn";
            this.cancel_btn.Size = new System.Drawing.Size(75, 29);
            this.cancel_btn.TabIndex = 7;
            this.cancel_btn.Text = "Cancel";
            this.cancel_btn.UseVisualStyleBackColor = true;
            this.cancel_btn.Click += new System.EventHandler(this.cancel_btn_Click);
            // 
            // content_form
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(229, 263);
            this.Controls.Add(this.cancel_btn);
            this.Controls.Add(this.save_btn);
            this.Controls.Add(this.cost_txtbox);
            this.Controls.Add(this.cost_lbl);
            this.Controls.Add(this.country_txtbox);
            this.Controls.Add(this.country_lbl);
            this.Controls.Add(this.prod_name_txtbox);
            this.Controls.Add(this.prod_name_lbl);
            this.Name = "content_form";
            this.Text = "contents";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label prod_name_lbl;
        private System.Windows.Forms.Label country_lbl;
        private System.Windows.Forms.Label cost_lbl;
        private System.Windows.Forms.Button save_btn;
        private System.Windows.Forms.Button cancel_btn;
        public System.Windows.Forms.TextBox prod_name_txtbox;
        public System.Windows.Forms.TextBox country_txtbox;
        public System.Windows.Forms.TextBox cost_txtbox;
    }
}