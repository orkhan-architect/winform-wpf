﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace asilimenu
{
    public partial class content_form : Form
    {
        public string Prod_Name { get; set; }
        public string Prod_Country { get; set; }
        public int Prod_Cost { get; set; }

        public content_form()
        {
            InitializeComponent();
        }

        private void save_btn_Click(object sender, EventArgs e)
        {
            Prod_Name = prod_name_txtbox.Text;
            Prod_Country = country_txtbox.Text;
            Prod_Cost = Convert.ToInt32(cost_txtbox.Text);

            prod_name_txtbox.Text = "";
            country_txtbox.Text = "";
            cost_txtbox.Text = "";

            DialogResult = DialogResult.OK;
        }

        private void cancel_btn_Click(object sender, EventArgs e)
        {
            prod_name_txtbox.Text = "";
            country_txtbox.Text = "";
            cost_txtbox.Text = "";

            DialogResult = DialogResult.Cancel;
        }
    }
}
