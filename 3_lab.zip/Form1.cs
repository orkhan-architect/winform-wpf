﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using System.Xml.Serialization;

namespace asilimenu
{
    public partial class products_form : Form
    {
        public products_form()
        {
            InitializeComponent();
        }

        public List<Product> prdocuts_list = new List<Product>();

        private void FS_out_in()
        {
            string user_path = "productlist.xml";
            XmlSerializer xmlFormat = new XmlSerializer(typeof(List<Product>));
            using (Stream fStream = File.Create(user_path))
            {
                xmlFormat.Serialize(fStream, prdocuts_list);
            }

            if (File.Exists(user_path))
            {
                XmlSerializer xmlFormat2 = new XmlSerializer(typeof(List<Product>));
                using (Stream fStream = File.OpenRead(user_path))
                {
                    prdocuts_list = (List<Product>)xmlFormat.Deserialize(fStream);
                    products_listbox.Items.Clear();
                    products_listbox.Items.AddRange(prdocuts_list.ToArray());
                }
            }
        }

        private void add_btn_Click(object sender, EventArgs e)
        {
            content_form cf = new content_form();
            Product new_product = new Product();

            this.Hide();

            var result = cf.ShowDialog();

            if (result == DialogResult.OK)
            {
                new_product.Name = cf.Prod_Name;
                new_product.Country = cf.Prod_Country;
                new_product.Cost = cf.Prod_Cost;
                prdocuts_list.Add(new_product);
                products_listbox.Items.Add(new_product);
            }            

            string user_path = "productlist.xml";
            XmlSerializer xmlFormat = new XmlSerializer(typeof(List<Product>));
            using (Stream fStream = File.Create(user_path))
            {
                xmlFormat.Serialize(fStream, prdocuts_list);
            }

            this.Show();          
        }

        private void products_form_Load(object sender, EventArgs e)
        {
            string user_path = "productlist.xml";

            if (File.Exists(user_path))
            {
                XmlSerializer xmlFormat = new XmlSerializer(typeof(List<Product>));
                using (Stream fStream = File.OpenRead(user_path))
                {
                    prdocuts_list = (List<Product>)xmlFormat.Deserialize(fStream);
                    products_listbox.Items.AddRange(prdocuts_list.ToArray());
                }
            }
        }

        private void edit_btn_Click(object sender, EventArgs e)
        {
            content_form cf = new content_form();
            Product new_product = new Product();

            int ID = products_listbox.SelectedIndex;

            cf.prod_name_txtbox.Text = prdocuts_list[ID].Name;
            cf.country_txtbox.Text = prdocuts_list[ID].Country;
            cf.cost_txtbox.Text = (prdocuts_list[ID].Cost).ToString();

            this.Hide();

            var result = cf.ShowDialog();

            if (result == DialogResult.OK)
            {
                new_product.Name = cf.Prod_Name;
                new_product.Country = cf.Prod_Country;
                new_product.Cost = cf.Prod_Cost;
                prdocuts_list[ID] = new_product;
                products_listbox.SelectedItem = prdocuts_list[ID];                
            }

            FS_out_in();

            this.Show();
        }

        private void remove_btn_Click(object sender, EventArgs e)
        {
            int ID = products_listbox.SelectedIndex;
            prdocuts_list.RemoveAt(ID);
            products_listbox.Items.RemoveAt(ID);

            FS_out_in();
        }

        private void clear_btn_Click(object sender, EventArgs e)
        {
            prdocuts_list.Clear();

            FS_out_in();
        }
    }

    public class Product
    {
        public string Name { get; set; }
        public string Country { get; set; }
        public int Cost { get; set; }

        public Product() { }

        public override string ToString()
        {
            return $"{Name} {Cost}";
        }
    }
}
