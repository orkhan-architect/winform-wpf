﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using OilCafeMVP.Models;

namespace OilCafeMVP.Views
{
    public interface IOilCafeView
    {        
        EventHandler ComboboxEventHandler { get; set; }

        EventHandler OilVolumeEventHandler { get; set; }
        EventHandler OilSumEventHandler { get; set; }

        EventHandler HotdogEventHandler { get; set; }
        EventHandler HamburgerEventHandler { get; set; }
        EventHandler FriEventHandler { get; set; }
        EventHandler ColaEventHandler { get; set; }

        EventHandler PayEventHandler { get; set; }

        string OilTypeText { get; set; } 
        string OilPriceText { get; set; }
        string OilVolumeText { get; set; }
        string OilPriceSumText { get; set; }
        string OilPaymentText { get; set; }

        string HotdogPriceText { get; set; }
        string HotdogCountText { get; set; }
        string HamburgerPriceText { get; set; }
        string HamburgerCountText { get; set; }
        string FriPriceText { get; set; }
        string FriCountText { get; set; }
        string ColaPriceText { get; set; }
        string ColaCountText { get; set; }
        string CafePaymentText { get; set; }

        string AllPaymentText { get; set; }

        bool VolBtnChecking();
        bool OilPriceSumChecking();

        void VoltxtBoxEnabled();
        void SumtxtBoxEnabled();
        void VoltxtBoxDisabled();
        void SumtxtBoxDisabled();

        bool HotdogChecking();
        void HotdogCountEnabled();
        void HotdogCountDisabled();

        bool HamburgerChecking();
        void HamburgerCountEnabled();
        void HamburgerCountDisabled();

        bool FriChecking();
        void FriCountEnabled();
        void FriCountDisabled();

        bool ColaChecking();
        void ColaCountEnabled();
        void ColaCountDisabled();
    }
}
