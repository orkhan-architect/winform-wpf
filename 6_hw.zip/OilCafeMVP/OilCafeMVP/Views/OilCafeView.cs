﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using OilCafeMVP.Models;

namespace OilCafeMVP.Views
{
    public partial class OilCafeView : Form, IOilCafeView
    {
        public OilCafeView()
        {
            InitializeComponent();
        }

        public EventHandler ComboboxEventHandler { get => oiltype_combobox_SelectedIndexChanged; set => oiltype_combobox.SelectedIndexChanged += value; }
       
        public EventHandler OilVolumeEventHandler { get => volume_rbutton_CheckedChanged; set => volume_rbutton.CheckedChanged += value; }
        public EventHandler OilSumEventHandler { get => sumprice_rbutton_CheckedChanged; set => sumprice_rbutton.CheckedChanged += value; }
        
        public EventHandler HotdogEventHandler { get => hotdog_chbox_CheckedChanged; set => hotdog_chbox.CheckedChanged += value; }
        public EventHandler HamburgerEventHandler { get => hamburger_chbox_CheckedChanged; set => hamburger_chbox.CheckedChanged += value; }
        public EventHandler FriEventHandler { get => fripotatos_chbox_CheckedChanged; set => fripotatos_chbox.CheckedChanged += value; }
        public EventHandler ColaEventHandler { get => cocacola_chbox_CheckedChanged; set => cocacola_chbox.CheckedChanged += value; }

        public EventHandler PayEventHandler { get => pay_btn_Click; set => pay_btn.Click += value; }

        public string OilTypeText
        {
            get => oiltype_combobox.SelectedItem.ToString();
            set => oiltype_combobox.SelectedItem = value;
        }
        public string OilPriceText
        {
            get => oilprice_txtbox.Text;
            set => oilprice_txtbox.Text = value;
        }
        public string OilVolumeText
        {
            get => oilvolume_txtbox.Text;
            set => oilvolume_txtbox.Text = value;
        }
        public string OilPriceSumText
        {
            get => oilsumprice_txtbox.Text;
            set => oilsumprice_txtbox.Text = value;
        }
        public string OilPaymentText
        {
            get => oil_payment_lbl.Text;
            set => oil_payment_lbl.Text = value;
        }

        public string HotdogPriceText 
        {
            get => hotdog_price_txtbox.Text;
            set => hotdog_price_txtbox.Text = value;
        }
        public string HotdogCountText
        {
            get => hotdog_count_txtbox.Text;
            set => hotdog_count_txtbox.Text = value;
        }
        public string HamburgerPriceText
        {
            get => hamburger_price_txtbox.Text;
            set => hamburger_price_txtbox.Text = value;
        }
        public string HamburgerCountText
        {
            get => hamburger_count_txtbox.Text;
            set => hamburger_count_txtbox.Text = value;
        }
        public string FriPriceText
        {
            get => fri_price_txtbox.Text;
            set => fri_price_txtbox.Text = value;
        }
        public string FriCountText
        {
            get => fri_count_txtbox.Text;
            set => fri_count_txtbox.Text = value;
        }
        public string ColaPriceText
        {
            get => cola_price_txtbox.Text;
            set => cola_price_txtbox.Text = value;
        }
        public string ColaCountText
        {
            get => cola_count_txtbox.Text;
            set => cola_count_txtbox.Text = value;
        }
        public string CafePaymentText 
        {
            get => cafe_payment_lbl.Text;
            set => cafe_payment_lbl.Text = value;
        }
        
        public string AllPaymentText
        {
            get => payment_sum_lbl.Text;
            set => payment_sum_lbl.Text = value;
        }                

        public void oiltype_combobox_SelectedIndexChanged (object sender, EventArgs e)
        {            
            ComboboxEventHandler.Invoke(sender, e);
        }

        public void volume_rbutton_CheckedChanged (object sender, EventArgs e)
        {
            OilVolumeEventHandler.Invoke(sender, e);
        }
        public void sumprice_rbutton_CheckedChanged (object sender, EventArgs e)
        {
            OilSumEventHandler.Invoke(sender, e);
        }

        public void hotdog_chbox_CheckedChanged (object sender, EventArgs e)
        {
            HotdogEventHandler.Invoke(sender, e);
        }
        public void hamburger_chbox_CheckedChanged (object sender, EventArgs e)
        {
            HamburgerEventHandler.Invoke(sender, e);
        }
        public void fripotatos_chbox_CheckedChanged (object sender, EventArgs e)
        {
            FriEventHandler.Invoke(sender, e);
        }
        public void cocacola_chbox_CheckedChanged (object sender, EventArgs e)
        {
            ColaEventHandler.Invoke(sender, e);
        }

        public void pay_btn_Click (object sender, EventArgs e)
        {
            PayEventHandler.Invoke(sender, e);
        }

        public bool VolBtnChecking()
        {
            return volume_rbutton.Checked;
        }
        public bool OilPriceSumChecking()
        {
            return sumprice_rbutton.Checked;
        }

        public void VoltxtBoxEnabled()
        {
            oilvolume_txtbox.Enabled = true;
        }
        public void SumtxtBoxEnabled()
        {
            oilsumprice_txtbox.Enabled = true;
        }
        public void VoltxtBoxDisabled()
        {
            oilvolume_txtbox.Enabled = false;
        }
        public void SumtxtBoxDisabled()
        {
            oilsumprice_txtbox.Enabled = false;
        }

        public bool HotdogChecking()
        {
            return hotdog_chbox.Checked;
        }
        public void HotdogCountEnabled()
        {
            hotdog_count_txtbox.Enabled = true;
        }
        public void HotdogCountDisabled()
        {
            hotdog_count_txtbox.Enabled = false;
        }

        public bool HamburgerChecking()
        {
            return hamburger_chbox.Checked;
        }
        public void HamburgerCountEnabled()
        {
            hamburger_count_txtbox.Enabled = true;
        }
        public void HamburgerCountDisabled()
        {
            hamburger_count_txtbox.Enabled = false;
        }

        public bool FriChecking()
        {
            return fripotatos_chbox.Checked;
        }
        public void FriCountEnabled()
        {
            fri_count_txtbox.Enabled = true;
        }
        public void FriCountDisabled()
        {
            fri_count_txtbox.Enabled = false;
        }

        public bool ColaChecking()
        {
            return cocacola_chbox.Checked;
        }
        public void ColaCountEnabled()
        {
            cola_count_txtbox.Enabled = true;
        }
        public void ColaCountDisabled()
        {
            cola_count_txtbox.Enabled = false;
        }
    }
}
