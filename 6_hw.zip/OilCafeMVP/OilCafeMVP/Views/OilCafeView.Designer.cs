﻿namespace OilCafeMVP.Views
{
    partial class OilCafeView
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.oil_station_gbox = new System.Windows.Forms.GroupBox();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.label7 = new System.Windows.Forms.Label();
            this.oil_payment_lbl = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.oilsumprice_txtbox = new System.Windows.Forms.TextBox();
            this.oilvolume_txtbox = new System.Windows.Forms.TextBox();
            this.sumprice_rbutton = new System.Windows.Forms.RadioButton();
            this.volume_rbutton = new System.Windows.Forms.RadioButton();
            this.label3 = new System.Windows.Forms.Label();
            this.oilprice_txtbox = new System.Windows.Forms.TextBox();
            this.oiltype_combobox = new System.Windows.Forms.ComboBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.mini_cafe_gbox = new System.Windows.Forms.GroupBox();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.label10 = new System.Windows.Forms.Label();
            this.cafe_payment_lbl = new System.Windows.Forms.Label();
            this.cola_count_txtbox = new System.Windows.Forms.TextBox();
            this.cola_price_txtbox = new System.Windows.Forms.TextBox();
            this.cocacola_chbox = new System.Windows.Forms.CheckBox();
            this.fri_count_txtbox = new System.Windows.Forms.TextBox();
            this.fri_price_txtbox = new System.Windows.Forms.TextBox();
            this.fripotatos_chbox = new System.Windows.Forms.CheckBox();
            this.hamburger_count_txtbox = new System.Windows.Forms.TextBox();
            this.hamburger_price_txtbox = new System.Windows.Forms.TextBox();
            this.hamburger_chbox = new System.Windows.Forms.CheckBox();
            this.label9 = new System.Windows.Forms.Label();
            this.hotdog_count_txtbox = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.hotdog_price_txtbox = new System.Windows.Forms.TextBox();
            this.hotdog_chbox = new System.Windows.Forms.CheckBox();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.pay_btn = new System.Windows.Forms.Button();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.label6 = new System.Windows.Forms.Label();
            this.payment_sum_lbl = new System.Windows.Forms.Label();
            this.oil_station_gbox.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.mini_cafe_gbox.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.groupBox3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // oil_station_gbox
            // 
            this.oil_station_gbox.Controls.Add(this.groupBox1);
            this.oil_station_gbox.Controls.Add(this.label5);
            this.oil_station_gbox.Controls.Add(this.label4);
            this.oil_station_gbox.Controls.Add(this.oilsumprice_txtbox);
            this.oil_station_gbox.Controls.Add(this.oilvolume_txtbox);
            this.oil_station_gbox.Controls.Add(this.sumprice_rbutton);
            this.oil_station_gbox.Controls.Add(this.volume_rbutton);
            this.oil_station_gbox.Controls.Add(this.label3);
            this.oil_station_gbox.Controls.Add(this.oilprice_txtbox);
            this.oil_station_gbox.Controls.Add(this.oiltype_combobox);
            this.oil_station_gbox.Controls.Add(this.label2);
            this.oil_station_gbox.Controls.Add(this.label1);
            this.oil_station_gbox.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.oil_station_gbox.Location = new System.Drawing.Point(12, 12);
            this.oil_station_gbox.Name = "oil_station_gbox";
            this.oil_station_gbox.Size = new System.Drawing.Size(247, 269);
            this.oil_station_gbox.TabIndex = 0;
            this.oil_station_gbox.TabStop = false;
            this.oil_station_gbox.Text = "Oil Station";
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.label7);
            this.groupBox1.Controls.Add(this.oil_payment_lbl);
            this.groupBox1.Location = new System.Drawing.Point(12, 181);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(225, 82);
            this.groupBox1.TabIndex = 11;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Oil payment";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(175, 44);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(41, 19);
            this.label7.TabIndex = 10;
            this.label7.Text = "AZN";
            // 
            // oil_payment_lbl
            // 
            this.oil_payment_lbl.AutoSize = true;
            this.oil_payment_lbl.Font = new System.Drawing.Font("Times New Roman", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.oil_payment_lbl.Location = new System.Drawing.Point(106, 34);
            this.oil_payment_lbl.Name = "oil_payment_lbl";
            this.oil_payment_lbl.Size = new System.Drawing.Size(63, 31);
            this.oil_payment_lbl.TabIndex = 1;
            this.oil_payment_lbl.Text = "0.00";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(196, 122);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(16, 19);
            this.label5.TabIndex = 10;
            this.label5.Text = "lt";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(196, 156);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(41, 19);
            this.label4.TabIndex = 9;
            this.label4.Text = "AZN";
            // 
            // oilsumprice_txtbox
            // 
            this.oilsumprice_txtbox.Enabled = false;
            this.oilsumprice_txtbox.Location = new System.Drawing.Point(90, 149);
            this.oilsumprice_txtbox.Name = "oilsumprice_txtbox";
            this.oilsumprice_txtbox.Size = new System.Drawing.Size(100, 26);
            this.oilsumprice_txtbox.TabIndex = 8;
            // 
            // oilvolume_txtbox
            // 
            this.oilvolume_txtbox.Enabled = false;
            this.oilvolume_txtbox.Location = new System.Drawing.Point(90, 117);
            this.oilvolume_txtbox.Name = "oilvolume_txtbox";
            this.oilvolume_txtbox.Size = new System.Drawing.Size(100, 26);
            this.oilvolume_txtbox.TabIndex = 7;
            // 
            // sumprice_rbutton
            // 
            this.sumprice_rbutton.AutoSize = true;
            this.sumprice_rbutton.Location = new System.Drawing.Point(10, 149);
            this.sumprice_rbutton.Name = "sumprice_rbutton";
            this.sumprice_rbutton.Size = new System.Drawing.Size(54, 23);
            this.sumprice_rbutton.TabIndex = 6;
            this.sumprice_rbutton.TabStop = true;
            this.sumprice_rbutton.Text = "Sum";
            this.sumprice_rbutton.UseVisualStyleBackColor = true;
            // 
            // volume_rbutton
            // 
            this.volume_rbutton.AutoSize = true;
            this.volume_rbutton.Location = new System.Drawing.Point(10, 120);
            this.volume_rbutton.Name = "volume_rbutton";
            this.volume_rbutton.Size = new System.Drawing.Size(72, 23);
            this.volume_rbutton.TabIndex = 5;
            this.volume_rbutton.TabStop = true;
            this.volume_rbutton.Text = "Volume";
            this.volume_rbutton.UseVisualStyleBackColor = true;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(187, 70);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(41, 19);
            this.label3.TabIndex = 4;
            this.label3.Text = "AZN";
            // 
            // oilprice_txtbox
            // 
            this.oilprice_txtbox.Enabled = false;
            this.oilprice_txtbox.Location = new System.Drawing.Point(69, 63);
            this.oilprice_txtbox.Name = "oilprice_txtbox";
            this.oilprice_txtbox.Size = new System.Drawing.Size(100, 26);
            this.oilprice_txtbox.TabIndex = 3;
            // 
            // oiltype_combobox
            // 
            this.oiltype_combobox.FormattingEnabled = true;
            this.oiltype_combobox.Items.AddRange(new object[] {
            "AI-92",
            "AI-95",
            "AI-98"});
            this.oiltype_combobox.Location = new System.Drawing.Point(69, 28);
            this.oiltype_combobox.Name = "oiltype_combobox";
            this.oiltype_combobox.Size = new System.Drawing.Size(100, 27);
            this.oiltype_combobox.TabIndex = 2;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(6, 70);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(40, 19);
            this.label2.TabIndex = 1;
            this.label2.Text = "Price";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(6, 31);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(57, 19);
            this.label1.TabIndex = 0;
            this.label1.Text = "Oil type";
            // 
            // mini_cafe_gbox
            // 
            this.mini_cafe_gbox.Controls.Add(this.groupBox2);
            this.mini_cafe_gbox.Controls.Add(this.cola_count_txtbox);
            this.mini_cafe_gbox.Controls.Add(this.cola_price_txtbox);
            this.mini_cafe_gbox.Controls.Add(this.cocacola_chbox);
            this.mini_cafe_gbox.Controls.Add(this.fri_count_txtbox);
            this.mini_cafe_gbox.Controls.Add(this.fri_price_txtbox);
            this.mini_cafe_gbox.Controls.Add(this.fripotatos_chbox);
            this.mini_cafe_gbox.Controls.Add(this.hamburger_count_txtbox);
            this.mini_cafe_gbox.Controls.Add(this.hamburger_price_txtbox);
            this.mini_cafe_gbox.Controls.Add(this.hamburger_chbox);
            this.mini_cafe_gbox.Controls.Add(this.label9);
            this.mini_cafe_gbox.Controls.Add(this.hotdog_count_txtbox);
            this.mini_cafe_gbox.Controls.Add(this.label8);
            this.mini_cafe_gbox.Controls.Add(this.hotdog_price_txtbox);
            this.mini_cafe_gbox.Controls.Add(this.hotdog_chbox);
            this.mini_cafe_gbox.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.mini_cafe_gbox.Location = new System.Drawing.Point(265, 12);
            this.mini_cafe_gbox.Name = "mini_cafe_gbox";
            this.mini_cafe_gbox.Size = new System.Drawing.Size(225, 269);
            this.mini_cafe_gbox.TabIndex = 1;
            this.mini_cafe_gbox.TabStop = false;
            this.mini_cafe_gbox.Text = "Mini cafe";
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.label10);
            this.groupBox2.Controls.Add(this.cafe_payment_lbl);
            this.groupBox2.Location = new System.Drawing.Point(6, 181);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(213, 82);
            this.groupBox2.TabIndex = 24;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Cafe payment";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(162, 44);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(41, 19);
            this.label10.TabIndex = 12;
            this.label10.Text = "AZN";
            // 
            // cafe_payment_lbl
            // 
            this.cafe_payment_lbl.AutoSize = true;
            this.cafe_payment_lbl.Font = new System.Drawing.Font("Times New Roman", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cafe_payment_lbl.Location = new System.Drawing.Point(93, 34);
            this.cafe_payment_lbl.Name = "cafe_payment_lbl";
            this.cafe_payment_lbl.Size = new System.Drawing.Size(63, 31);
            this.cafe_payment_lbl.TabIndex = 11;
            this.cafe_payment_lbl.Text = "0.00";
            // 
            // cola_count_txtbox
            // 
            this.cola_count_txtbox.Enabled = false;
            this.cola_count_txtbox.Location = new System.Drawing.Point(166, 127);
            this.cola_count_txtbox.Name = "cola_count_txtbox";
            this.cola_count_txtbox.Size = new System.Drawing.Size(53, 26);
            this.cola_count_txtbox.TabIndex = 23;
            this.cola_count_txtbox.Text = "0";
            // 
            // cola_price_txtbox
            // 
            this.cola_price_txtbox.Enabled = false;
            this.cola_price_txtbox.Location = new System.Drawing.Point(109, 127);
            this.cola_price_txtbox.Name = "cola_price_txtbox";
            this.cola_price_txtbox.Size = new System.Drawing.Size(53, 26);
            this.cola_price_txtbox.TabIndex = 22;
            this.cola_price_txtbox.Text = "1.70";
            // 
            // cocacola_chbox
            // 
            this.cocacola_chbox.AutoSize = true;
            this.cocacola_chbox.Location = new System.Drawing.Point(6, 129);
            this.cocacola_chbox.Name = "cocacola_chbox";
            this.cocacola_chbox.Size = new System.Drawing.Size(92, 23);
            this.cocacola_chbox.TabIndex = 21;
            this.cocacola_chbox.Text = "Coca-cola";
            this.cocacola_chbox.UseVisualStyleBackColor = true;
            // 
            // fri_count_txtbox
            // 
            this.fri_count_txtbox.Enabled = false;
            this.fri_count_txtbox.Location = new System.Drawing.Point(166, 98);
            this.fri_count_txtbox.Name = "fri_count_txtbox";
            this.fri_count_txtbox.Size = new System.Drawing.Size(53, 26);
            this.fri_count_txtbox.TabIndex = 20;
            this.fri_count_txtbox.Text = "0";
            // 
            // fri_price_txtbox
            // 
            this.fri_price_txtbox.Enabled = false;
            this.fri_price_txtbox.Location = new System.Drawing.Point(109, 98);
            this.fri_price_txtbox.Name = "fri_price_txtbox";
            this.fri_price_txtbox.Size = new System.Drawing.Size(53, 26);
            this.fri_price_txtbox.TabIndex = 19;
            this.fri_price_txtbox.Text = "2.50";
            // 
            // fripotatos_chbox
            // 
            this.fripotatos_chbox.AutoSize = true;
            this.fripotatos_chbox.Location = new System.Drawing.Point(6, 100);
            this.fripotatos_chbox.Name = "fripotatos_chbox";
            this.fripotatos_chbox.Size = new System.Drawing.Size(94, 23);
            this.fripotatos_chbox.TabIndex = 18;
            this.fripotatos_chbox.Text = "Fri potatos";
            this.fripotatos_chbox.UseVisualStyleBackColor = true;
            // 
            // hamburger_count_txtbox
            // 
            this.hamburger_count_txtbox.Enabled = false;
            this.hamburger_count_txtbox.Location = new System.Drawing.Point(166, 69);
            this.hamburger_count_txtbox.Name = "hamburger_count_txtbox";
            this.hamburger_count_txtbox.Size = new System.Drawing.Size(53, 26);
            this.hamburger_count_txtbox.TabIndex = 17;
            this.hamburger_count_txtbox.Text = "0";
            // 
            // hamburger_price_txtbox
            // 
            this.hamburger_price_txtbox.Enabled = false;
            this.hamburger_price_txtbox.Location = new System.Drawing.Point(109, 69);
            this.hamburger_price_txtbox.Name = "hamburger_price_txtbox";
            this.hamburger_price_txtbox.Size = new System.Drawing.Size(53, 26);
            this.hamburger_price_txtbox.TabIndex = 16;
            this.hamburger_price_txtbox.Text = "3.50";
            // 
            // hamburger_chbox
            // 
            this.hamburger_chbox.AutoSize = true;
            this.hamburger_chbox.Location = new System.Drawing.Point(6, 71);
            this.hamburger_chbox.Name = "hamburger_chbox";
            this.hamburger_chbox.Size = new System.Drawing.Size(96, 23);
            this.hamburger_chbox.TabIndex = 15;
            this.hamburger_chbox.Text = "Hamburger";
            this.hamburger_chbox.UseVisualStyleBackColor = true;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(168, 18);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(46, 19);
            this.label9.TabIndex = 14;
            this.label9.Text = "Count";
            // 
            // hotdog_count_txtbox
            // 
            this.hotdog_count_txtbox.Enabled = false;
            this.hotdog_count_txtbox.Location = new System.Drawing.Point(166, 40);
            this.hotdog_count_txtbox.Name = "hotdog_count_txtbox";
            this.hotdog_count_txtbox.Size = new System.Drawing.Size(53, 26);
            this.hotdog_count_txtbox.TabIndex = 13;
            this.hotdog_count_txtbox.Text = "0";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(115, 18);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(40, 19);
            this.label8.TabIndex = 12;
            this.label8.Text = "Price";
            // 
            // hotdog_price_txtbox
            // 
            this.hotdog_price_txtbox.Enabled = false;
            this.hotdog_price_txtbox.Location = new System.Drawing.Point(109, 40);
            this.hotdog_price_txtbox.Name = "hotdog_price_txtbox";
            this.hotdog_price_txtbox.Size = new System.Drawing.Size(53, 26);
            this.hotdog_price_txtbox.TabIndex = 4;
            this.hotdog_price_txtbox.Text = "2.20";
            // 
            // hotdog_chbox
            // 
            this.hotdog_chbox.AutoSize = true;
            this.hotdog_chbox.Location = new System.Drawing.Point(6, 42);
            this.hotdog_chbox.Name = "hotdog_chbox";
            this.hotdog_chbox.Size = new System.Drawing.Size(80, 23);
            this.hotdog_chbox.TabIndex = 2;
            this.hotdog_chbox.Text = "Hot-dog";
            this.hotdog_chbox.UseVisualStyleBackColor = true;
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.pay_btn);
            this.groupBox3.Controls.Add(this.pictureBox1);
            this.groupBox3.Controls.Add(this.label6);
            this.groupBox3.Controls.Add(this.payment_sum_lbl);
            this.groupBox3.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox3.Location = new System.Drawing.Point(12, 287);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(478, 100);
            this.groupBox3.TabIndex = 2;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Payment sum";
            // 
            // pay_btn
            // 
            this.pay_btn.AutoSize = true;
            this.pay_btn.Font = new System.Drawing.Font("Times New Roman", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.pay_btn.Location = new System.Drawing.Point(93, 33);
            this.pay_btn.Name = "pay_btn";
            this.pay_btn.Size = new System.Drawing.Size(76, 41);
            this.pay_btn.TabIndex = 16;
            this.pay_btn.Text = "PAY";
            this.pay_btn.UseVisualStyleBackColor = true;
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackgroundImage = global::OilCafeMVP.Properties.Resources.cashlogo;
            this.pictureBox1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pictureBox1.Location = new System.Drawing.Point(12, 25);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(70, 62);
            this.pictureBox1.TabIndex = 15;
            this.pictureBox1.TabStop = false;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(374, 55);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(41, 19);
            this.label6.TabIndex = 14;
            this.label6.Text = "AZN";
            // 
            // payment_sum_lbl
            // 
            this.payment_sum_lbl.AutoSize = true;
            this.payment_sum_lbl.Font = new System.Drawing.Font("Times New Roman", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.payment_sum_lbl.Location = new System.Drawing.Point(305, 45);
            this.payment_sum_lbl.Name = "payment_sum_lbl";
            this.payment_sum_lbl.Size = new System.Drawing.Size(63, 31);
            this.payment_sum_lbl.TabIndex = 13;
            this.payment_sum_lbl.Text = "0.00";
            // 
            // OilCafeView
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(502, 399);
            this.Controls.Add(this.groupBox3);
            this.Controls.Add(this.mini_cafe_gbox);
            this.Controls.Add(this.oil_station_gbox);
            this.Name = "OilCafeView";
            this.Text = "OilCafeView";
            this.oil_station_gbox.ResumeLayout(false);
            this.oil_station_gbox.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.mini_cafe_gbox.ResumeLayout(false);
            this.mini_cafe_gbox.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox oil_station_gbox;
        private System.Windows.Forms.TextBox oilprice_txtbox;
        private System.Windows.Forms.ComboBox oiltype_combobox;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label oil_payment_lbl;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.GroupBox mini_cafe_gbox;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TextBox hotdog_count_txtbox;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox hotdog_price_txtbox;
        private System.Windows.Forms.CheckBox hotdog_chbox;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label cafe_payment_lbl;
        private System.Windows.Forms.TextBox cola_count_txtbox;
        private System.Windows.Forms.TextBox cola_price_txtbox;
        private System.Windows.Forms.CheckBox cocacola_chbox;
        private System.Windows.Forms.TextBox fri_count_txtbox;
        private System.Windows.Forms.TextBox fri_price_txtbox;
        private System.Windows.Forms.CheckBox fripotatos_chbox;
        private System.Windows.Forms.TextBox hamburger_count_txtbox;
        private System.Windows.Forms.TextBox hamburger_price_txtbox;
        private System.Windows.Forms.CheckBox hamburger_chbox;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label payment_sum_lbl;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Button pay_btn;
        private System.Windows.Forms.TextBox oilvolume_txtbox;
        private System.Windows.Forms.RadioButton volume_rbutton;
        private System.Windows.Forms.TextBox oilsumprice_txtbox;
        private System.Windows.Forms.RadioButton sumprice_rbutton;
    }
}