﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using OilCafeMVP.Models;
using OilCafeMVP.Views;
using System.Globalization;
using System.IO;
using System.Xml.Serialization;

namespace OilCafeMVP.Presenters
{
    public class OilCafePresenter
    {
        private IOilCafeView oilcafeview;

        public OilCafePresenter(IOilCafeView view)
        {
            oilcafeview = view;

            oilcafeview.ComboboxEventHandler = new System.EventHandler(ComboboxSelected);

            oilcafeview.OilVolumeEventHandler = new System.EventHandler(VolumeBTNSelected);
            oilcafeview.OilSumEventHandler = new System.EventHandler(OilsumBTNSelected);

            oilcafeview.HotdogEventHandler = new System.EventHandler(HotdogSelected);
            oilcafeview.HamburgerEventHandler = new System.EventHandler(HamburgerSelected);
            oilcafeview.FriEventHandler = new System.EventHandler(FriSelected);
            oilcafeview.ColaEventHandler = new System.EventHandler(ColaSelected);

            oilcafeview.PayEventHandler = new System.EventHandler(PayBTNSelected);
        }

        private void ComboboxSelected (object sender, EventArgs e)
        {
            if (oilcafeview.OilTypeText == "AI-92")
                oilcafeview.OilPriceText = "1.00";
            else if (oilcafeview.OilTypeText == "AI-95")
                oilcafeview.OilPriceText = "1.60";
            else if (oilcafeview.OilTypeText == "AI-98")
                oilcafeview.OilPriceText = "1.90";
        }

        private void VolumeBTNSelected (object sender, EventArgs e)
        {
            oilcafeview.VoltxtBoxEnabled();
            oilcafeview.SumtxtBoxDisabled();
            oilcafeview.OilPriceSumText = "";
        }

        private void OilsumBTNSelected (object sender, EventArgs e)
        {
            oilcafeview.VoltxtBoxDisabled();
            oilcafeview.SumtxtBoxEnabled();
            oilcafeview.OilVolumeText = "";
        }

        private void HotdogSelected (object sender, EventArgs e)
        {
            if (oilcafeview.HotdogChecking())
            {
                oilcafeview.HotdogCountEnabled();
            }
            else
            {
                oilcafeview.HotdogCountText = "0";
                oilcafeview.HotdogCountDisabled();
            }
        }

        private void HamburgerSelected (object sender, EventArgs e)
        {
            if (oilcafeview.HamburgerChecking())
            {
                oilcafeview.HamburgerCountEnabled();
            }
            else
            {
                oilcafeview.HamburgerCountText = "0";
                oilcafeview.HamburgerCountDisabled();
            }
        }

        private void FriSelected (object sender, EventArgs e)
        {
            if (oilcafeview.FriChecking())
            {
                oilcafeview.FriCountEnabled();
            }
            else
            {
                oilcafeview.FriCountText = "0";
                oilcafeview.FriCountDisabled();
            }
        }

        private void ColaSelected (object sender, EventArgs e)
        {
            if (oilcafeview.ColaChecking())
            {
                oilcafeview.ColaCountEnabled();
            }
            else
            {
                oilcafeview.ColaCountText = "0";
                oilcafeview.ColaCountDisabled();
            }
        }

        private void PayBTNSelected (object sender, EventArgs e)
        {
            float oilprice = float.Parse(oilcafeview.OilPriceText, CultureInfo.InvariantCulture.NumberFormat);
            float oilliter = float.Parse(oilcafeview.OilVolumeText, CultureInfo.InvariantCulture.NumberFormat);
            float oilresult = oilprice * oilliter;

            float hdogprice = 0;
            float hamburgprice = 0;
            float friprice = 0;
            float colaprice = 0;
            float caferesult = 0;

            hdogprice =
                float.Parse(oilcafeview.HotdogPriceText, CultureInfo.InvariantCulture.NumberFormat) *
                int.Parse(oilcafeview.HotdogCountText, CultureInfo.InvariantCulture.NumberFormat);

            hamburgprice =
               float.Parse(oilcafeview.HamburgerPriceText, CultureInfo.InvariantCulture.NumberFormat) *
               int.Parse(oilcafeview.HamburgerCountText, CultureInfo.InvariantCulture.NumberFormat);

            friprice =
               float.Parse(oilcafeview.FriPriceText, CultureInfo.InvariantCulture.NumberFormat) *
               int.Parse(oilcafeview.FriCountText, CultureInfo.InvariantCulture.NumberFormat);

            colaprice =
               float.Parse(oilcafeview.ColaPriceText, CultureInfo.InvariantCulture.NumberFormat) *
               int.Parse(oilcafeview.ColaCountText, CultureInfo.InvariantCulture.NumberFormat);

            caferesult = hdogprice + hamburgprice + friprice + colaprice;

            if (oilcafeview.VolBtnChecking())
                oilcafeview.OilPaymentText = oilresult.ToString();
            else if (oilcafeview.OilPriceSumChecking())
                oilcafeview.OilPaymentText = oilcafeview.OilPriceSumText;

            oilcafeview.CafePaymentText = caferesult.ToString();

            float all_result = oilresult + caferesult;
            oilcafeview.AllPaymentText = all_result.ToString();

            var cafeoil = new OilCafe
            {
                OilType = oilcafeview.OilTypeText,
                OilPrice = float.Parse(oilcafeview.OilPriceText, CultureInfo.InvariantCulture.NumberFormat),
                OilPayment = Convert.ToSingle(oilcafeview.OilPaymentText),
                CafePayment = Convert.ToSingle(oilcafeview.CafePaymentText),
                AllPayment = Convert.ToSingle(oilcafeview.AllPaymentText)
            };

            List<OilCafe> list;

            string user_path = "bestoil.xml";
            if (File.Exists(user_path))
            {
                XmlSerializer xmlFormat2 = new XmlSerializer(typeof(List<OilCafe>));
                using (Stream fStream = File.OpenRead(user_path))
                {
                    list = (List<OilCafe>)xmlFormat2.Deserialize(fStream);
                }
            }
            else
            {
                list = new List<OilCafe>();
            }
            
            list.Add(cafeoil);
            XmlSerializer xmlFormat = new XmlSerializer(typeof(List<OilCafe>));
            using (Stream fStream = File.Create(user_path))
            {
                xmlFormat.Serialize(fStream, list);
            }
        }
    }
}
