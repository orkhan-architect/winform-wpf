﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OilCafeMVP.Models
{
    public class OilCafe
    {
        public string OilType { get; set; }
        public float OilPrice { get; set; }
        public float OilPayment { get; set; }

        public float CafePayment { get; set; }

        public float AllPayment { get; set; }
    }
}
