﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using movielist.Services.Interfaces;
using System.Net;
using movielist.Model;
using System.Text.Json;

namespace movielist.Services.Classes
{
    public class Movie: IMovie
    {
        private WebClient webClient = new();

        private readonly string _link = "https://www.omdbapi.com/?apikey=";
        private readonly string _apiKey = "e0768061";

        public string GetJsonBase(string movieName)
        {
            string _url = $"{_link}{_apiKey}&s={movieName}";

            string json = webClient.DownloadString(_url);
            return json;
        }

        public Search[] GetMovies(string movieName)
        {
            try
            {
                string json = GetJsonBase(movieName);

                var result = JsonSerializer.Deserialize<MovieModel>(json);

                var found_array = result.Search;
                return found_array;
            }
            catch (Exception ex)
            {
                throw;
            }
        }
    }
}
