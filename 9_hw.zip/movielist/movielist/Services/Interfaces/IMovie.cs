﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using movielist.Model;

namespace movielist.Services.Interfaces
{
    public interface IMovie
    {
        public string GetJsonBase(string movieName);
        public Search[] GetMovies(string movieName);
    }
}
