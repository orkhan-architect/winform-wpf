﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using movielist.Services.Interfaces;
using movielist.Services.Classes;
using System.ComponentModel;
using System.Runtime.CompilerServices;
using System.Collections.ObjectModel;
using movielist.Model;
using GalaSoft.MvvmLight;
using GalaSoft.MvvmLight.Command;

namespace movielist.ViewModel
{
    public class MovieViewModel
    {
        public event PropertyChangedEventHandler PropertyChanged;
        public void OnPropertyChanged([CallerMemberName] string prop = "")
        {
            if (PropertyChanged != null)
                PropertyChanged(this, new PropertyChangedEventArgs(prop));
        }

        public string? MovieName { get; set; }        

        private ObservableCollection<Search> foundmovies;
        public ObservableCollection<Search> FoundMovies
        {
            get { return foundmovies; }
            set { foundmovies = value; OnPropertyChanged("FoundMovies"); }
        }

        private IMovie _movieclient;
        public MovieViewModel(IMovie client)
        {
            _movieclient = client;
            FoundMovies = new ObservableCollection<Search>();
        }

        private RelayCommand? searchcommand;
        public RelayCommand SearchCommand
        {
            get => searchcommand ??= new RelayCommand(
                ()=> {
                    FoundMovies.Clear();
                    var tmp_array = _movieclient.GetMovies(MovieName);
                    for (int i = 0; i < tmp_array.Length; i++)
                    {
                        FoundMovies.Add(tmp_array[i]);
                    }                    
                });
        }
    }
}
