﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Globalization;

namespace hw2
{
    public partial class BestOil : Form
    {
        public BestOil()
        {
            InitializeComponent();
        }

        private float oil_counter()
        {
            float oilprice = float.Parse(oilprice_txtbox.Text, CultureInfo.InvariantCulture.NumberFormat);
            float oilliter = float.Parse(volume_txtbox.Text, CultureInfo.InvariantCulture.NumberFormat);
            float oilresult = oilprice * oilliter;

            return oilresult;
        }

        private float cafe_counter()
        {
            float hdogprice = 0;
            float hamburgprice = 0;
            float friprice = 0;
            float colaprice = 0;
            float result = 0;
           
            hdogprice = 
                float.Parse(hotdog_pricebox.Text, CultureInfo.InvariantCulture.NumberFormat) * 
                int.Parse(hotdog_countbox.Text, CultureInfo.InvariantCulture.NumberFormat);
            
            
            hamburgprice =
                float.Parse(hamburger_pricebox.Text, CultureInfo.InvariantCulture.NumberFormat) *
                int.Parse(hamburger_countbox.Text, CultureInfo.InvariantCulture.NumberFormat);
            
            friprice =
                float.Parse(fri_pricebox.Text, CultureInfo.InvariantCulture.NumberFormat) *
                int.Parse(fri_countbox.Text, CultureInfo.InvariantCulture.NumberFormat);

            colaprice =
                float.Parse(cola_pricebox.Text, CultureInfo.InvariantCulture.NumberFormat) *
                int.Parse(cola_countbox.Text, CultureInfo.InvariantCulture.NumberFormat);

            result = hdogprice + hamburgprice + friprice + colaprice;

            return result;
        }

        private void oil_combobox_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (oil_combobox.SelectedIndex == 0)
                oilprice_txtbox.Text = "1.00";
            else if (oil_combobox.SelectedIndex == 1)
                oilprice_txtbox.Text = "1.60";
            else if (oil_combobox.SelectedIndex == 2)
                oilprice_txtbox.Text = "1.90";
        }

        private void volume_rbutton_CheckedChanged(object sender, EventArgs e)
        {
            if (volume_rbutton.Checked)
            {
                volume_txtbox.Enabled = true;
                oilsum_txtbox.Text = "";
                oilsum_txtbox.Enabled = false;
            }
        }

        private void sum_rbutton_CheckedChanged(object sender, EventArgs e)
        {
            if (sum_rbutton.Checked)
            {
                oilsum_txtbox.Enabled = true;
                volume_txtbox.Text = "";
                volume_txtbox.Enabled = false;
            }
        }

        private void hotdog_chbox_CheckedChanged(object sender, EventArgs e)
        {
            if (hotdog_chbox.Checked)
            {
                hotdog_pricebox.Text = "2.20";
                hotdog_countbox.Enabled = true;
            }
            else
            {
                hotdog_countbox.Enabled = false;
                hotdog_countbox.Text = "0";
            }
        }

        private void hamburger_chbox_CheckedChanged(object sender, EventArgs e)
        {
            if (hamburger_chbox.Checked)
            {
                hamburger_pricebox.Text = "3.50";
                hamburger_countbox.Enabled = true;
            }
            else
            {
                hamburger_countbox.Enabled = false;
                hamburger_countbox.Text = "0";
            }
        }

        private void fri_chbox_CheckedChanged(object sender, EventArgs e)
        {
            if (fri_chbox.Checked)
            {
                fri_pricebox.Text = "2.50";
                fri_countbox.Enabled = true;
            }
            else
            {
                fri_countbox.Enabled = false;
                fri_countbox.Text = "0";
            }
        }

        private void cocacola_chbox_CheckedChanged(object sender, EventArgs e)
        {
            if (cocacola_chbox.Checked)
            {
                cola_pricebox.Text = "1.70";
                cola_countbox.Enabled = true;
            }
            else
            {
                cola_countbox.Enabled = false;
                cola_countbox.Text = "0";
            }
        }

        private void pay_btn_Click(object sender, EventArgs e)
        {
            if (volume_rbutton.Checked)
            {
                oilres_lbl.Text = oil_counter().ToString();
            }
            else if (sum_rbutton.Checked)
            {
                oilres_lbl.Text = oilsum_txtbox.Text;
            }

            caferes_lbl.Text = cafe_counter().ToString();

            float all_result = oil_counter() + cafe_counter();

            allres_lbl.Text = all_result.ToString();
        }
    }
}
