﻿namespace hw2
{
    partial class BestOil
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.oil_station_gbox = new System.Windows.Forms.GroupBox();
            this.oil_res_gbox = new System.Windows.Forms.GroupBox();
            this.oilres_lbl = new System.Windows.Forms.Label();
            this.cur3_lbl = new System.Windows.Forms.Label();
            this.liter_lbl = new System.Windows.Forms.Label();
            this.oilsum_txtbox = new System.Windows.Forms.TextBox();
            this.cur2_lbl = new System.Windows.Forms.Label();
            this.volume_txtbox = new System.Windows.Forms.TextBox();
            this.oil_rbuttons_gbox = new System.Windows.Forms.GroupBox();
            this.sum_rbutton = new System.Windows.Forms.RadioButton();
            this.volume_rbutton = new System.Windows.Forms.RadioButton();
            this.cur1_lbl = new System.Windows.Forms.Label();
            this.oilprice_txtbox = new System.Windows.Forms.TextBox();
            this.oil_price_lbl = new System.Windows.Forms.Label();
            this.oil_lbl = new System.Windows.Forms.Label();
            this.oil_combobox = new System.Windows.Forms.ComboBox();
            this.cafe_gbox = new System.Windows.Forms.GroupBox();
            this.cola_countbox = new System.Windows.Forms.TextBox();
            this.cola_pricebox = new System.Windows.Forms.TextBox();
            this.fri_countbox = new System.Windows.Forms.TextBox();
            this.fri_pricebox = new System.Windows.Forms.TextBox();
            this.hamburger_countbox = new System.Windows.Forms.TextBox();
            this.hamburger_pricebox = new System.Windows.Forms.TextBox();
            this.hotdog_countbox = new System.Windows.Forms.TextBox();
            this.hotdog_pricebox = new System.Windows.Forms.TextBox();
            this.cafecount_lbl = new System.Windows.Forms.Label();
            this.cafeprice_lbl = new System.Windows.Forms.Label();
            this.cafe_res_gbox = new System.Windows.Forms.GroupBox();
            this.caferes_lbl = new System.Windows.Forms.Label();
            this.cur4_lbl = new System.Windows.Forms.Label();
            this.cocacola_chbox = new System.Windows.Forms.CheckBox();
            this.fri_chbox = new System.Windows.Forms.CheckBox();
            this.hamburger_chbox = new System.Windows.Forms.CheckBox();
            this.hotdog_chbox = new System.Windows.Forms.CheckBox();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.allres_lbl = new System.Windows.Forms.Label();
            this.cur5_lbl = new System.Windows.Forms.Label();
            this.pay_btn = new System.Windows.Forms.Button();
            this.cash_logo = new System.Windows.Forms.PictureBox();
            this.oil_station_gbox.SuspendLayout();
            this.oil_res_gbox.SuspendLayout();
            this.oil_rbuttons_gbox.SuspendLayout();
            this.cafe_gbox.SuspendLayout();
            this.cafe_res_gbox.SuspendLayout();
            this.groupBox3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.cash_logo)).BeginInit();
            this.SuspendLayout();
            // 
            // oil_station_gbox
            // 
            this.oil_station_gbox.Controls.Add(this.oil_res_gbox);
            this.oil_station_gbox.Controls.Add(this.liter_lbl);
            this.oil_station_gbox.Controls.Add(this.oilsum_txtbox);
            this.oil_station_gbox.Controls.Add(this.cur2_lbl);
            this.oil_station_gbox.Controls.Add(this.volume_txtbox);
            this.oil_station_gbox.Controls.Add(this.oil_rbuttons_gbox);
            this.oil_station_gbox.Controls.Add(this.cur1_lbl);
            this.oil_station_gbox.Controls.Add(this.oilprice_txtbox);
            this.oil_station_gbox.Controls.Add(this.oil_price_lbl);
            this.oil_station_gbox.Controls.Add(this.oil_lbl);
            this.oil_station_gbox.Controls.Add(this.oil_combobox);
            this.oil_station_gbox.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.oil_station_gbox.Location = new System.Drawing.Point(12, 12);
            this.oil_station_gbox.Name = "oil_station_gbox";
            this.oil_station_gbox.Size = new System.Drawing.Size(259, 283);
            this.oil_station_gbox.TabIndex = 0;
            this.oil_station_gbox.TabStop = false;
            this.oil_station_gbox.Text = "Oil station";
            // 
            // oil_res_gbox
            // 
            this.oil_res_gbox.Controls.Add(this.oilres_lbl);
            this.oil_res_gbox.Controls.Add(this.cur3_lbl);
            this.oil_res_gbox.Location = new System.Drawing.Point(10, 193);
            this.oil_res_gbox.Name = "oil_res_gbox";
            this.oil_res_gbox.Size = new System.Drawing.Size(243, 71);
            this.oil_res_gbox.TabIndex = 10;
            this.oil_res_gbox.TabStop = false;
            this.oil_res_gbox.Text = "Result";
            // 
            // oilres_lbl
            // 
            this.oilres_lbl.AutoSize = true;
            this.oilres_lbl.Font = new System.Drawing.Font("Times New Roman", 26.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.oilres_lbl.Location = new System.Drawing.Point(101, 18);
            this.oilres_lbl.Name = "oilres_lbl";
            this.oilres_lbl.Size = new System.Drawing.Size(80, 40);
            this.oilres_lbl.TabIndex = 9;
            this.oilres_lbl.Text = "0.00";
            // 
            // cur3_lbl
            // 
            this.cur3_lbl.AutoSize = true;
            this.cur3_lbl.Location = new System.Drawing.Point(196, 39);
            this.cur3_lbl.Name = "cur3_lbl";
            this.cur3_lbl.Size = new System.Drawing.Size(41, 19);
            this.cur3_lbl.TabIndex = 8;
            this.cur3_lbl.Text = "AZN";
            // 
            // liter_lbl
            // 
            this.liter_lbl.AutoSize = true;
            this.liter_lbl.Location = new System.Drawing.Point(212, 128);
            this.liter_lbl.Name = "liter_lbl";
            this.liter_lbl.Size = new System.Drawing.Size(21, 19);
            this.liter_lbl.TabIndex = 9;
            this.liter_lbl.Text = "ltr";
            // 
            // oilsum_txtbox
            // 
            this.oilsum_txtbox.Enabled = false;
            this.oilsum_txtbox.Location = new System.Drawing.Point(106, 153);
            this.oilsum_txtbox.Name = "oilsum_txtbox";
            this.oilsum_txtbox.Size = new System.Drawing.Size(100, 26);
            this.oilsum_txtbox.TabIndex = 8;
            // 
            // cur2_lbl
            // 
            this.cur2_lbl.AutoSize = true;
            this.cur2_lbl.Location = new System.Drawing.Point(212, 160);
            this.cur2_lbl.Name = "cur2_lbl";
            this.cur2_lbl.Size = new System.Drawing.Size(41, 19);
            this.cur2_lbl.TabIndex = 7;
            this.cur2_lbl.Text = "AZN";
            // 
            // volume_txtbox
            // 
            this.volume_txtbox.Enabled = false;
            this.volume_txtbox.Location = new System.Drawing.Point(106, 121);
            this.volume_txtbox.Name = "volume_txtbox";
            this.volume_txtbox.Size = new System.Drawing.Size(100, 26);
            this.volume_txtbox.TabIndex = 6;
            // 
            // oil_rbuttons_gbox
            // 
            this.oil_rbuttons_gbox.Controls.Add(this.sum_rbutton);
            this.oil_rbuttons_gbox.Controls.Add(this.volume_rbutton);
            this.oil_rbuttons_gbox.Location = new System.Drawing.Point(10, 98);
            this.oil_rbuttons_gbox.Name = "oil_rbuttons_gbox";
            this.oil_rbuttons_gbox.Size = new System.Drawing.Size(90, 89);
            this.oil_rbuttons_gbox.TabIndex = 5;
            this.oil_rbuttons_gbox.TabStop = false;
            // 
            // sum_rbutton
            // 
            this.sum_rbutton.AutoSize = true;
            this.sum_rbutton.Location = new System.Drawing.Point(7, 55);
            this.sum_rbutton.Name = "sum_rbutton";
            this.sum_rbutton.Size = new System.Drawing.Size(54, 23);
            this.sum_rbutton.TabIndex = 1;
            this.sum_rbutton.TabStop = true;
            this.sum_rbutton.Text = "Sum";
            this.sum_rbutton.UseVisualStyleBackColor = true;
            this.sum_rbutton.CheckedChanged += new System.EventHandler(this.sum_rbutton_CheckedChanged);
            // 
            // volume_rbutton
            // 
            this.volume_rbutton.AutoSize = true;
            this.volume_rbutton.Location = new System.Drawing.Point(7, 26);
            this.volume_rbutton.Name = "volume_rbutton";
            this.volume_rbutton.Size = new System.Drawing.Size(72, 23);
            this.volume_rbutton.TabIndex = 0;
            this.volume_rbutton.TabStop = true;
            this.volume_rbutton.Text = "Volume";
            this.volume_rbutton.UseVisualStyleBackColor = true;
            this.volume_rbutton.CheckedChanged += new System.EventHandler(this.volume_rbutton_CheckedChanged);
            // 
            // cur1_lbl
            // 
            this.cur1_lbl.AutoSize = true;
            this.cur1_lbl.Location = new System.Drawing.Point(212, 67);
            this.cur1_lbl.Name = "cur1_lbl";
            this.cur1_lbl.Size = new System.Drawing.Size(41, 19);
            this.cur1_lbl.TabIndex = 4;
            this.cur1_lbl.Text = "AZN";
            // 
            // oilprice_txtbox
            // 
            this.oilprice_txtbox.Enabled = false;
            this.oilprice_txtbox.Location = new System.Drawing.Point(73, 64);
            this.oilprice_txtbox.Name = "oilprice_txtbox";
            this.oilprice_txtbox.Size = new System.Drawing.Size(133, 26);
            this.oilprice_txtbox.TabIndex = 3;
            this.oilprice_txtbox.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // oil_price_lbl
            // 
            this.oil_price_lbl.AutoSize = true;
            this.oil_price_lbl.Location = new System.Drawing.Point(6, 67);
            this.oil_price_lbl.Name = "oil_price_lbl";
            this.oil_price_lbl.Size = new System.Drawing.Size(61, 19);
            this.oil_price_lbl.TabIndex = 2;
            this.oil_price_lbl.Text = "Oil price";
            // 
            // oil_lbl
            // 
            this.oil_lbl.AutoSize = true;
            this.oil_lbl.Location = new System.Drawing.Point(6, 33);
            this.oil_lbl.Name = "oil_lbl";
            this.oil_lbl.Size = new System.Drawing.Size(57, 19);
            this.oil_lbl.TabIndex = 1;
            this.oil_lbl.Text = "Oil type";
            // 
            // oil_combobox
            // 
            this.oil_combobox.FormattingEnabled = true;
            this.oil_combobox.Items.AddRange(new object[] {
            "AI-92",
            "AI-95",
            "AI-98"});
            this.oil_combobox.Location = new System.Drawing.Point(73, 25);
            this.oil_combobox.Name = "oil_combobox";
            this.oil_combobox.Size = new System.Drawing.Size(180, 27);
            this.oil_combobox.TabIndex = 0;
            this.oil_combobox.SelectedIndexChanged += new System.EventHandler(this.oil_combobox_SelectedIndexChanged);
            // 
            // cafe_gbox
            // 
            this.cafe_gbox.Controls.Add(this.cola_countbox);
            this.cafe_gbox.Controls.Add(this.cola_pricebox);
            this.cafe_gbox.Controls.Add(this.fri_countbox);
            this.cafe_gbox.Controls.Add(this.fri_pricebox);
            this.cafe_gbox.Controls.Add(this.hamburger_countbox);
            this.cafe_gbox.Controls.Add(this.hamburger_pricebox);
            this.cafe_gbox.Controls.Add(this.hotdog_countbox);
            this.cafe_gbox.Controls.Add(this.hotdog_pricebox);
            this.cafe_gbox.Controls.Add(this.cafecount_lbl);
            this.cafe_gbox.Controls.Add(this.cafeprice_lbl);
            this.cafe_gbox.Controls.Add(this.cafe_res_gbox);
            this.cafe_gbox.Controls.Add(this.cocacola_chbox);
            this.cafe_gbox.Controls.Add(this.fri_chbox);
            this.cafe_gbox.Controls.Add(this.hamburger_chbox);
            this.cafe_gbox.Controls.Add(this.hotdog_chbox);
            this.cafe_gbox.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.cafe_gbox.Location = new System.Drawing.Point(291, 12);
            this.cafe_gbox.Name = "cafe_gbox";
            this.cafe_gbox.Size = new System.Drawing.Size(242, 283);
            this.cafe_gbox.TabIndex = 1;
            this.cafe_gbox.TabStop = false;
            this.cafe_gbox.Text = "Mini cafe";
            // 
            // cola_countbox
            // 
            this.cola_countbox.Enabled = false;
            this.cola_countbox.Location = new System.Drawing.Point(187, 164);
            this.cola_countbox.Name = "cola_countbox";
            this.cola_countbox.Size = new System.Drawing.Size(49, 26);
            this.cola_countbox.TabIndex = 14;
            this.cola_countbox.Text = "0";
            // 
            // cola_pricebox
            // 
            this.cola_pricebox.Enabled = false;
            this.cola_pricebox.Location = new System.Drawing.Point(124, 164);
            this.cola_pricebox.Name = "cola_pricebox";
            this.cola_pricebox.Size = new System.Drawing.Size(49, 26);
            this.cola_pricebox.TabIndex = 13;
            this.cola_pricebox.Text = "0";
            // 
            // fri_countbox
            // 
            this.fri_countbox.Enabled = false;
            this.fri_countbox.Location = new System.Drawing.Point(187, 128);
            this.fri_countbox.Name = "fri_countbox";
            this.fri_countbox.Size = new System.Drawing.Size(49, 26);
            this.fri_countbox.TabIndex = 12;
            this.fri_countbox.Text = "0";
            // 
            // fri_pricebox
            // 
            this.fri_pricebox.Enabled = false;
            this.fri_pricebox.Location = new System.Drawing.Point(124, 128);
            this.fri_pricebox.Name = "fri_pricebox";
            this.fri_pricebox.Size = new System.Drawing.Size(49, 26);
            this.fri_pricebox.TabIndex = 11;
            this.fri_pricebox.Text = "0";
            // 
            // hamburger_countbox
            // 
            this.hamburger_countbox.Enabled = false;
            this.hamburger_countbox.Location = new System.Drawing.Point(187, 90);
            this.hamburger_countbox.Name = "hamburger_countbox";
            this.hamburger_countbox.Size = new System.Drawing.Size(49, 26);
            this.hamburger_countbox.TabIndex = 10;
            this.hamburger_countbox.Text = "0";
            // 
            // hamburger_pricebox
            // 
            this.hamburger_pricebox.Enabled = false;
            this.hamburger_pricebox.Location = new System.Drawing.Point(124, 90);
            this.hamburger_pricebox.Name = "hamburger_pricebox";
            this.hamburger_pricebox.Size = new System.Drawing.Size(49, 26);
            this.hamburger_pricebox.TabIndex = 9;
            this.hamburger_pricebox.Text = "0";
            // 
            // hotdog_countbox
            // 
            this.hotdog_countbox.Enabled = false;
            this.hotdog_countbox.Location = new System.Drawing.Point(187, 52);
            this.hotdog_countbox.Name = "hotdog_countbox";
            this.hotdog_countbox.Size = new System.Drawing.Size(49, 26);
            this.hotdog_countbox.TabIndex = 8;
            this.hotdog_countbox.Text = "0";
            // 
            // hotdog_pricebox
            // 
            this.hotdog_pricebox.Enabled = false;
            this.hotdog_pricebox.Location = new System.Drawing.Point(124, 52);
            this.hotdog_pricebox.Name = "hotdog_pricebox";
            this.hotdog_pricebox.Size = new System.Drawing.Size(49, 26);
            this.hotdog_pricebox.TabIndex = 7;
            this.hotdog_pricebox.Text = "0";
            // 
            // cafecount_lbl
            // 
            this.cafecount_lbl.AutoSize = true;
            this.cafecount_lbl.Location = new System.Drawing.Point(190, 22);
            this.cafecount_lbl.Name = "cafecount_lbl";
            this.cafecount_lbl.Size = new System.Drawing.Size(46, 19);
            this.cafecount_lbl.TabIndex = 6;
            this.cafecount_lbl.Text = "Count";
            // 
            // cafeprice_lbl
            // 
            this.cafeprice_lbl.AutoSize = true;
            this.cafeprice_lbl.Location = new System.Drawing.Point(130, 22);
            this.cafeprice_lbl.Name = "cafeprice_lbl";
            this.cafeprice_lbl.Size = new System.Drawing.Size(40, 19);
            this.cafeprice_lbl.TabIndex = 5;
            this.cafeprice_lbl.Text = "Price";
            // 
            // cafe_res_gbox
            // 
            this.cafe_res_gbox.Controls.Add(this.caferes_lbl);
            this.cafe_res_gbox.Controls.Add(this.cur4_lbl);
            this.cafe_res_gbox.Location = new System.Drawing.Point(7, 193);
            this.cafe_res_gbox.Name = "cafe_res_gbox";
            this.cafe_res_gbox.Size = new System.Drawing.Size(229, 75);
            this.cafe_res_gbox.TabIndex = 4;
            this.cafe_res_gbox.TabStop = false;
            this.cafe_res_gbox.Text = "Result";
            // 
            // caferes_lbl
            // 
            this.caferes_lbl.AutoSize = true;
            this.caferes_lbl.Font = new System.Drawing.Font("Times New Roman", 26.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.caferes_lbl.Location = new System.Drawing.Point(90, 18);
            this.caferes_lbl.Name = "caferes_lbl";
            this.caferes_lbl.Size = new System.Drawing.Size(80, 40);
            this.caferes_lbl.TabIndex = 10;
            this.caferes_lbl.Text = "0.00";
            // 
            // cur4_lbl
            // 
            this.cur4_lbl.AutoSize = true;
            this.cur4_lbl.Location = new System.Drawing.Point(176, 39);
            this.cur4_lbl.Name = "cur4_lbl";
            this.cur4_lbl.Size = new System.Drawing.Size(41, 19);
            this.cur4_lbl.TabIndex = 9;
            this.cur4_lbl.Text = "AZN";
            // 
            // cocacola_chbox
            // 
            this.cocacola_chbox.AutoSize = true;
            this.cocacola_chbox.Location = new System.Drawing.Point(7, 163);
            this.cocacola_chbox.Name = "cocacola_chbox";
            this.cocacola_chbox.Size = new System.Drawing.Size(92, 23);
            this.cocacola_chbox.TabIndex = 3;
            this.cocacola_chbox.Text = "Coca-cola";
            this.cocacola_chbox.UseVisualStyleBackColor = true;
            this.cocacola_chbox.CheckedChanged += new System.EventHandler(this.cocacola_chbox_CheckedChanged);
            // 
            // fri_chbox
            // 
            this.fri_chbox.AutoSize = true;
            this.fri_chbox.Location = new System.Drawing.Point(7, 126);
            this.fri_chbox.Name = "fri_chbox";
            this.fri_chbox.Size = new System.Drawing.Size(45, 23);
            this.fri_chbox.TabIndex = 2;
            this.fri_chbox.Text = "Fri";
            this.fri_chbox.UseVisualStyleBackColor = true;
            this.fri_chbox.CheckedChanged += new System.EventHandler(this.fri_chbox_CheckedChanged);
            // 
            // hamburger_chbox
            // 
            this.hamburger_chbox.AutoSize = true;
            this.hamburger_chbox.Location = new System.Drawing.Point(7, 89);
            this.hamburger_chbox.Name = "hamburger_chbox";
            this.hamburger_chbox.Size = new System.Drawing.Size(96, 23);
            this.hamburger_chbox.TabIndex = 1;
            this.hamburger_chbox.Text = "Hamburger";
            this.hamburger_chbox.UseVisualStyleBackColor = true;
            this.hamburger_chbox.CheckedChanged += new System.EventHandler(this.hamburger_chbox_CheckedChanged);
            // 
            // hotdog_chbox
            // 
            this.hotdog_chbox.AutoSize = true;
            this.hotdog_chbox.Location = new System.Drawing.Point(7, 52);
            this.hotdog_chbox.Name = "hotdog_chbox";
            this.hotdog_chbox.Size = new System.Drawing.Size(80, 23);
            this.hotdog_chbox.TabIndex = 0;
            this.hotdog_chbox.Text = "Hot-dog";
            this.hotdog_chbox.UseVisualStyleBackColor = true;
            this.hotdog_chbox.CheckedChanged += new System.EventHandler(this.hotdog_chbox_CheckedChanged);
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.allres_lbl);
            this.groupBox3.Controls.Add(this.cur5_lbl);
            this.groupBox3.Controls.Add(this.pay_btn);
            this.groupBox3.Controls.Add(this.cash_logo);
            this.groupBox3.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.groupBox3.Location = new System.Drawing.Point(12, 301);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(521, 117);
            this.groupBox3.TabIndex = 2;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "All result";
            // 
            // allres_lbl
            // 
            this.allres_lbl.AutoSize = true;
            this.allres_lbl.Font = new System.Drawing.Font("Times New Roman", 26.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.allres_lbl.Location = new System.Drawing.Point(356, 45);
            this.allres_lbl.Name = "allres_lbl";
            this.allres_lbl.Size = new System.Drawing.Size(80, 40);
            this.allres_lbl.TabIndex = 11;
            this.allres_lbl.Text = "0.00";
            // 
            // cur5_lbl
            // 
            this.cur5_lbl.AutoSize = true;
            this.cur5_lbl.Location = new System.Drawing.Point(462, 66);
            this.cur5_lbl.Name = "cur5_lbl";
            this.cur5_lbl.Size = new System.Drawing.Size(41, 19);
            this.cur5_lbl.TabIndex = 10;
            this.cur5_lbl.Text = "AZN";
            // 
            // pay_btn
            // 
            this.pay_btn.AutoSize = true;
            this.pay_btn.Font = new System.Drawing.Font("Times New Roman", 36F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.pay_btn.Location = new System.Drawing.Point(118, 25);
            this.pay_btn.Name = "pay_btn";
            this.pay_btn.Size = new System.Drawing.Size(104, 80);
            this.pay_btn.TabIndex = 1;
            this.pay_btn.Text = "Pay";
            this.pay_btn.UseVisualStyleBackColor = true;
            this.pay_btn.Click += new System.EventHandler(this.pay_btn_Click);
            // 
            // cash_logo
            // 
            this.cash_logo.Image = global::hw2.Properties.Resources.cashlogo;
            this.cash_logo.Location = new System.Drawing.Point(6, 25);
            this.cash_logo.Name = "cash_logo";
            this.cash_logo.Size = new System.Drawing.Size(80, 80);
            this.cash_logo.TabIndex = 0;
            this.cash_logo.TabStop = false;
            // 
            // BestOil
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(546, 436);
            this.Controls.Add(this.groupBox3);
            this.Controls.Add(this.cafe_gbox);
            this.Controls.Add(this.oil_station_gbox);
            this.Name = "BestOil";
            this.Text = "BestOil";
            this.oil_station_gbox.ResumeLayout(false);
            this.oil_station_gbox.PerformLayout();
            this.oil_res_gbox.ResumeLayout(false);
            this.oil_res_gbox.PerformLayout();
            this.oil_rbuttons_gbox.ResumeLayout(false);
            this.oil_rbuttons_gbox.PerformLayout();
            this.cafe_gbox.ResumeLayout(false);
            this.cafe_gbox.PerformLayout();
            this.cafe_res_gbox.ResumeLayout(false);
            this.cafe_res_gbox.PerformLayout();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.cash_logo)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox oil_station_gbox;
        private System.Windows.Forms.Label liter_lbl;
        private System.Windows.Forms.TextBox oilsum_txtbox;
        private System.Windows.Forms.Label cur2_lbl;
        private System.Windows.Forms.TextBox volume_txtbox;
        private System.Windows.Forms.GroupBox oil_rbuttons_gbox;
        private System.Windows.Forms.RadioButton sum_rbutton;
        private System.Windows.Forms.RadioButton volume_rbutton;
        private System.Windows.Forms.Label cur1_lbl;
        private System.Windows.Forms.TextBox oilprice_txtbox;
        private System.Windows.Forms.Label oil_price_lbl;
        private System.Windows.Forms.Label oil_lbl;
        private System.Windows.Forms.ComboBox oil_combobox;
        private System.Windows.Forms.GroupBox oil_res_gbox;
        private System.Windows.Forms.Label oilres_lbl;
        private System.Windows.Forms.Label cur3_lbl;
        private System.Windows.Forms.GroupBox cafe_gbox;
        private System.Windows.Forms.TextBox cola_countbox;
        private System.Windows.Forms.TextBox cola_pricebox;
        private System.Windows.Forms.TextBox fri_countbox;
        private System.Windows.Forms.TextBox fri_pricebox;
        private System.Windows.Forms.TextBox hamburger_countbox;
        private System.Windows.Forms.TextBox hamburger_pricebox;
        private System.Windows.Forms.TextBox hotdog_countbox;
        private System.Windows.Forms.TextBox hotdog_pricebox;
        private System.Windows.Forms.Label cafecount_lbl;
        private System.Windows.Forms.Label cafeprice_lbl;
        private System.Windows.Forms.GroupBox cafe_res_gbox;
        private System.Windows.Forms.Label caferes_lbl;
        private System.Windows.Forms.Label cur4_lbl;
        private System.Windows.Forms.CheckBox cocacola_chbox;
        private System.Windows.Forms.CheckBox fri_chbox;
        private System.Windows.Forms.CheckBox hamburger_chbox;
        private System.Windows.Forms.CheckBox hotdog_chbox;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.PictureBox cash_logo;
        private System.Windows.Forms.Label allres_lbl;
        private System.Windows.Forms.Label cur5_lbl;
        private System.Windows.Forms.Button pay_btn;
    }
}

