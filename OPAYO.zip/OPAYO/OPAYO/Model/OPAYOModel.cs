﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Collections.ObjectModel;

namespace OPAYO.Model
{
    public class OPAYOModel
    {
        
    }

    public class Category
    {
        public string? Name { get; set; }
        public string? FinanceType { get; set; }
        public string? Icon { get; set; }
    }

    public class Account
    {
        public string? Name { get; set; }
        public string? Currency { get; set; }
        public string? Icon { get; set; }
        public float Balance { get; set; }
    }

    public class Budget
    {
        public string? CategoryName { get; set; }
        public string? AccountName { get; set; }
        public string? BudgetCurrency { get; set; }
        public string? Description { get; set; }
        public float Price { get; set; }
        public double Exchange { get; set; }
        public double ConvertedPrice { get; set; }
        public DateTime CreationDate { get; set; }
    }

    public class Expense
    {
        public string? ExpenseName { get; set; }
        public float TotalValue { get; set; }

        public Expense(string? expenseName, float totalValue)
        {
            ExpenseName = expenseName;
            TotalValue = totalValue;
        }

    }
}
