﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using OPAYO.Model;
using OPAYO.Services.Interfaces;
using GalaSoft.MvvmLight;
using GalaSoft.MvvmLight.Command;
using System.Collections.ObjectModel;
using System.Text.Json;
using System.IO;
using System.Windows;

namespace OPAYO.ViewModel
{
    public class AccountViewModel : ViewModelBase
    {
        private string filename = "accounts.json";

        private IConnectionClient _connectionClient;

        public void Show_Icons()
        {
            AllIcons = new ObservableCollection<string>();

            string[] FilesPaths = Directory.GetFiles(@"..\net6.0-windows\Icons\Account\", "*.png").Select(Path.GetFileName).ToArray();

            for (int i = 0; i < FilesPaths.Length; i++)
            {
                AllIcons.Add("/OPAYO;component/Icons/Account/" + FilesPaths[i]);
                SourceName = AllIcons[i];
            }

        }

        public AccountViewModel(IConnectionClient connectionClient)
        {
            _connectionClient = connectionClient;

            Show_Icons();

            if (File.Exists(filename))
                AllAccounts = connectionClient.GetAccounts();
            else
                AllAccounts = new ObservableCollection<Account>();
        }

        #region Filling_Areas

        private string? accountname;
        public string? AccountName
        {
            get { return accountname; }
            set { Set(ref accountname, value); }
        }

        public int selectedcurrencyindex;
        public int SelectedCurrencyIndex
        {
            get { return selectedcurrencyindex; }
            set { Set(ref selectedcurrencyindex, value); }
        }

        private ObservableCollection<string> allicons;
        public ObservableCollection<string> AllIcons
        {
            get { return allicons; }
            set { Set(ref allicons, value); }
        }

        private string? selectediconpath;
        public string? SelectedIconPath
        {
            get { return selectediconpath; }
            set { Set(ref selectediconpath, value); }
        }

        public ObservableCollection<string> AllCurrencies
        {
            get { return new ObservableCollection<string>()
            {
                "AED",
                "AFN",
                "ALL",
                "AMD",
                "ARS",
                "AUD",
                "AZN",
                "BAM",
                "BDT",
                "BGN",
                "BHD",
                "BND",
                "BOB",
                "BRL",
                "BYR",
                "BZD",
                "CAD",
                "CHF",
                "CLP",
                "CNY",
                "COP",
                "CRC",
                "CZK",
                "DKK",
                "DOP",
                "DZD",
                "EGP",
                "ETB",
                "EUR",
                "GBP",
                "GEL",
                "GTQ",
                "HKD",
                "HNL",
                "HRK",
                "HUF",
                "IDR",
                "ILS",
                "INR",
                "IQD",
                "IRR",
                "ISK",
                "JMD",
                "JOD",
                "JPY",
                "KES",
                "KGS",
                "KHR",
                "KRW",
                "KWD",
                "KZT",
                "LAK",
                "LBP",
                "LKR",
                "LTL",
                "LYD",
                "MAD",
                "MKD",
                "MNT",
                "MOP",
                "MVR",
                "MXN",
                "MYR",
                "NIO",
                "NOK",
                "NPR",
                "NZD",
                "OMR",
                "PAB",
                "PEN",
                "PHP",
                "PKR",
                "PLN",
                "PYG",
                "QAR",
                "RON",
                "RSD",
                "RUB",
                "RWF",
                "SAR",
                "SEK",
                "SGD",
                "SYP",
                "THB",
                "TJS",
                "TND",
                "TRY",
                "TTD",
                "TWD",
                "UAH",
                "USD",
                "UYU",
                "UZS",
                "VEF",
                "VND",
                "XOF",
                "YER",
                "ZAR"
            }; }
        }

        private string? selectedCurItem;
        public string? SelectedCurItem
        {
            get { return selectedCurItem; }
            set { Set(ref selectedCurItem, value); }
        }

        private string? sourcename;
        public string? SourceName
        {
            get { return sourcename; }
            set { Set(ref sourcename, value); }
        }

        #endregion

        #region Category_library

        private ObservableCollection<Account> allaccounts;
        public ObservableCollection<Account> AllAccounts
        {
            get { return allaccounts; }
            set { Set(ref allaccounts, value); }
        }

        public int selectedaccountindex;
        public int SelectedAccountIndex
        {
            get { return selectedaccountindex; }
            set { Set(ref selectedaccountindex, value); }
        }

        #endregion

        #region Buttons

        private RelayCommand? addaccountcommand;
        public RelayCommand? AddAccountCommand
        {
            get => addaccountcommand ??= new RelayCommand(
              () =>
              {
                  if (String.IsNullOrEmpty(AccountName) || String.IsNullOrEmpty(SelectedIconPath))
                  {
                      MessageBox.Show("Fill account name, choose icon");
                      return;
                  }

                  var newaccount = new Account
                  {
                      Name = AccountName,
                      Currency = AllCurrencies[selectedcurrencyindex],
                      Icon = SelectedIconPath,
                      Balance = 0.00F
                  };

                  AllAccounts.Add(newaccount);

                  string jsonstring = JsonSerializer.Serialize(AllAccounts);
                  File.WriteAllText(filename, jsonstring);

                  AccountName = "";
                  SelectedCurrencyIndex = 0;
                  SelectedIconPath = null;
              });
        }

        private RelayCommand? updateaccountcommand;
        public RelayCommand? UpdateAccountCommand
        {
            get => updateaccountcommand ??= new RelayCommand(
              () =>
              {
                  if (String.IsNullOrEmpty(AccountName) || String.IsNullOrEmpty(SelectedIconPath))
                  {
                      MessageBox.Show("Fill account name, choose icon");
                      return;
                  }

                  AllAccounts[SelectedAccountIndex].Name = AccountName;
                  AllAccounts[SelectedAccountIndex].Currency = AllCurrencies[selectedcurrencyindex];
                  AllAccounts[SelectedAccountIndex].Icon = SelectedIconPath;

                  var tmp_list = new ObservableCollection<Account>();
                  for (int i = 0; i < AllAccounts.Count; i++)
                      tmp_list.Add(AllAccounts[i]);

                  AllAccounts.Clear();

                  AllAccounts = new ObservableCollection<Account>();
                  for (int i = 0; i < tmp_list.Count; i++)
                      AllAccounts.Add(tmp_list[i]);

                  tmp_list.Clear();

                  string jsonstring = JsonSerializer.Serialize(AllAccounts);
                  File.WriteAllText(filename, jsonstring);

                  AccountName = "";
                  SelectedCurrencyIndex = 0;
                  SelectedIconPath = null;
              });
        }

        private RelayCommand? deleteaccountcommand;
        public RelayCommand? DeleteAccountCommand
        {
            get => deleteaccountcommand ??= new RelayCommand(
              () =>
              {
                  if (AllAccounts.Count > 0)
                  {
                      AllAccounts.RemoveAt(SelectedAccountIndex);

                      var tmp_list = new ObservableCollection<Account>();

                      for (int i = 0; i < AllAccounts.Count; i++)
                          tmp_list.Add(AllAccounts[i]);

                      AllAccounts.Clear();

                      AllAccounts = new ObservableCollection<Account>();
                      for (int i = 0; i < tmp_list.Count; i++)
                          AllAccounts.Add(tmp_list[i]);

                      tmp_list.Clear();

                      string jsonstring = JsonSerializer.Serialize(AllAccounts);
                      File.WriteAllText(filename, jsonstring);

                      SelectedAccountIndex = 0;
                  }
              });
        }

        private RelayCommand? loadaccountcommand;
        public RelayCommand? LoadAccountCommand
        {
            get => loadaccountcommand ??= new RelayCommand(
              () =>
              {
                  if (AllAccounts.Count > 0)
                  {
                      if (AllAccounts[SelectedAccountIndex].Currency == "AZN")
                          SelectedCurrencyIndex = 0;
                      else if (AllAccounts[SelectedAccountIndex].Currency == "USD")
                          SelectedCurrencyIndex = 1;
                      else
                          SelectedCurrencyIndex = 2;

                      SelectedCurItem = AllAccounts[SelectedAccountIndex].Currency;
                      AccountName = AllAccounts[SelectedAccountIndex].Name;
                      SelectedIconPath = AllAccounts[SelectedAccountIndex].Icon;
                  }
              });
        }

        #endregion
    }
}
