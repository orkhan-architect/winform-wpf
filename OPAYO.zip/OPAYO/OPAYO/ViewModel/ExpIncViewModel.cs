﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using OPAYO.Model;
using OPAYO.Services.Interfaces;
using OPAYO.Messages;
using GalaSoft.MvvmLight;
using GalaSoft.MvvmLight.Command;
using GalaSoft.MvvmLight.Messaging;
using System.Collections.ObjectModel;
using System.Text.Json;
using System.IO;
using System.Windows;

namespace OPAYO.ViewModel
{
    public class ExpIncViewModel : ViewModelBase
    {
        private string categoryFile = "categories.json";
        private string accountFile = "accounts.json";
        private string incomeFile = "incomes.json";
        private string expenseFile = "expenses.json";

        private IConnectionClient _connectionClient;
        private IMessenger _messenger;

        private void UpdateLists()
        {
            AllCategories = _connectionClient.GetCategories();
            AllAccounts = _connectionClient.GetAccounts();
        }

        public ExpIncViewModel(IConnectionClient connectionClient, IMessenger messenger)
        {
            _connectionClient = connectionClient;
            _messenger = messenger;

            if (File.Exists(categoryFile))
                AllCategories = connectionClient.GetCategories();

            if (File.Exists(accountFile))
                AllAccounts = connectionClient.GetAccounts();

            _messenger.Register<UpdateMessage>(this, message => UpdateLists());

            var tmp_list = new List<Budget>();

            if (File.Exists(incomeFile))
            {
                AllIncomes = connectionClient.GetIncomes();
                tmp_list.AddRange(AllIncomes);
                tmp_list = tmp_list.OrderByDescending(x => x.CreationDate).ToList();
                AllIncomes.Clear();
                for(int i = 0; i < tmp_list.Count; i++)
                    AllIncomes.Add(tmp_list[i]);
                tmp_list.Clear();
            }                
            else
            {
                AllIncomes = new ObservableCollection<Budget>();
            }
                

            if (File.Exists(expenseFile))
            {
                AllExpenses = connectionClient.GetExpenses();

                tmp_list.AddRange(AllExpenses);
                tmp_list = tmp_list.OrderByDescending(x => x.CreationDate).ToList();
                AllExpenses.Clear();
                for (int i = 0; i < tmp_list.Count; i++)
                    AllExpenses.Add(tmp_list[i]);
                tmp_list.Clear();
            }
            else
            {
                AllExpenses = new ObservableCollection<Budget>();
            }                
        }

        #region Filled_Areas

        private string? descriptionText;
        public string? DescriptionText
        {
            get { return descriptionText; }
            set { Set(ref descriptionText, value); }
        }

        private string? priceValue;
        public string? PriceValue
        {
            get { return priceValue; }
            set { Set(ref priceValue, value); }
        }

        private string? exchangeRate;
        public string? ExchangeRate
        {
            get { return exchangeRate; }
            set { Set(ref exchangeRate, value); }
        }

        private string? operationDate;
        public string? OperationDate
        {
            get { return operationDate; }
            set { Set(ref operationDate, value); }
        }

        private ObservableCollection<Category> allcategories;
        public ObservableCollection<Category> AllCategories
        {
            get { return allcategories; }
            set { Set(ref allcategories, value); }
        }

        public int selectedcategoryindex;
        public int SelectedCategoryIndex
        {
            get { return selectedcategoryindex; }
            set { Set(ref selectedcategoryindex, value); }
        }

        private ObservableCollection<Account> allaccounts;
        public ObservableCollection<Account> AllAccounts
        {
            get { return allaccounts; }
            set { Set(ref allaccounts, value); }
        }

        public int selectedaccountindex;
        public int SelectedAccountIndex
        {
            get { return selectedaccountindex; }
            set { Set(ref selectedaccountindex, value); }
        }

        #endregion

        #region Show_Library

        private ObservableCollection<Budget> allIncomes;
        public ObservableCollection<Budget> AllIncomes
        {
            get { return allIncomes; }
            set { Set(ref allIncomes, value); }
        }

        public int selectedIncomeIndex;
        public int SelectedIncomeIndex
        {
            get { return selectedIncomeIndex; }
            set { Set(ref selectedIncomeIndex, value); }
        }

        private ObservableCollection<Budget> allExpenses;
        public ObservableCollection<Budget> AllExpenses
        {
            get { return allExpenses; }
            set { Set(ref allExpenses, value); }
        }

        public int selectedExpenseIndex;
        public int SelectedExpenseIndex
        {
            get { return selectedExpenseIndex; }
            set { Set(ref selectedExpenseIndex, value); }
        }

        #endregion

        #region Buttons

        private RelayCommand? addcommand;
        public RelayCommand? AddCommand
        {
            get => addcommand ??= new RelayCommand(
              () =>
              {
                  float number = 0;
                  bool canConvert = float.TryParse(PriceValue, out number);
                  if (!canConvert)
                  {
                      MessageBox.Show("Please, enter available float price");
                      return;
                  }

                  double number2 = 0;
                  bool canConvert2 = double.TryParse(ExchangeRate, out number2);
                  if (!canConvert2)
                  {
                      MessageBox.Show("Please, enter available exchange rate");
                      return;
                  }

                  if (String.IsNullOrEmpty(DescriptionText) || String.IsNullOrEmpty(OperationDate))
                  {
                      MessageBox.Show("Fill description and choose operation date");
                      return;
                  }

                  if (AllCategories[SelectedCategoryIndex].FinanceType == "Expense" &&
                  Convert.ToSingle(PriceValue) > AllAccounts[SelectedAccountIndex].Balance)
                  {
                      MessageBox.Show("You have no enough money for this expense. Your balance is " + AllAccounts[SelectedAccountIndex].Balance + " " + AllAccounts[SelectedAccountIndex].Currency);
                      return;
                  }

                  if(Convert.ToSingle(PriceValue) > 0 && Convert.ToDouble(ExchangeRate) > 0)
                  {
                      var newbudget = new Budget
                      {
                          CategoryName = AllCategories[SelectedCategoryIndex].Name,
                          AccountName = AllAccounts[SelectedAccountIndex].Name,
                          BudgetCurrency = AllAccounts[SelectedAccountIndex].Currency,
                          Description = DescriptionText,
                          Price = Convert.ToSingle(PriceValue),
                          CreationDate = DateTime.Parse(OperationDate),
                          Exchange = Convert.ToDouble(ExchangeRate),
                          ConvertedPrice = Convert.ToSingle(PriceValue) * Convert.ToDouble(ExchangeRate)
                      };

                      string jsonstring = "";
                      string accountjson = "";

                      if (AllCategories[SelectedCategoryIndex].FinanceType == "Income")
                      {
                          AllIncomes.Add(newbudget);

                          AllAccounts[SelectedAccountIndex].Balance += Convert.ToSingle(PriceValue);
                          accountjson = JsonSerializer.Serialize(AllAccounts);
                          File.WriteAllText(accountFile, accountjson);

                          jsonstring = JsonSerializer.Serialize(AllIncomes);
                          File.WriteAllText(incomeFile, jsonstring);
                      }
                      else if (AllCategories[SelectedCategoryIndex].FinanceType == "Expense")
                      {
                          AllExpenses.Add(newbudget);

                          AllAccounts[SelectedAccountIndex].Balance -= Convert.ToSingle(PriceValue);
                          accountjson = JsonSerializer.Serialize(AllAccounts);
                          File.WriteAllText(accountFile, accountjson);

                          jsonstring = JsonSerializer.Serialize(AllExpenses);
                          File.WriteAllText(expenseFile, jsonstring);
                      }

                      DescriptionText = "";
                      PriceValue = "";
                      SelectedCategoryIndex = 0;
                      ExchangeRate = null;
                      SelectedAccountIndex = 0;
                      OperationDate = null;
                  }
                  else
                  {
                      MessageBox.Show("Please, enter available float price and exchange rate more than zero");
                      return;
                  }                  
              });
        }

        private RelayCommand? deleteIncomeCommand;
        public RelayCommand? DeleteIncomeCommand
        {
            get => deleteIncomeCommand ??= new RelayCommand(
              () =>
              {
                  if(AllIncomes.Count > 0)
                  {
                      int selected_balance = 0;
                      for (int i = 0; i < AllAccounts.Count; i++)
                          if ((AllIncomes[SelectedIncomeIndex].AccountName).CompareTo(AllAccounts[i].Name) == 0)
                              selected_balance = i;

                      if (AllIncomes[SelectedIncomeIndex].Price <= AllAccounts[selected_balance].Balance)
                      {
                          AllAccounts[selected_balance].Balance -= AllIncomes[SelectedIncomeIndex].Price;
                          AllIncomes.RemoveAt(SelectedIncomeIndex);

                          var tmp_list = new ObservableCollection<Budget>();
                          for (int i = 0; i < AllIncomes.Count; i++)
                              tmp_list.Add(AllIncomes[i]);

                          AllIncomes.Clear();

                          AllIncomes = new ObservableCollection<Budget>();
                          for (int i = 0; i < tmp_list.Count; i++)
                              AllIncomes.Add(tmp_list[i]);

                          tmp_list.Clear();

                          string jsonstring = "";
                          string accountjson = "";

                          accountjson = JsonSerializer.Serialize(AllAccounts);
                          File.WriteAllText(accountFile, accountjson);

                          jsonstring = JsonSerializer.Serialize(AllIncomes);
                          File.WriteAllText(incomeFile, jsonstring);

                          SelectedIncomeIndex = 0;
                      }
                      else
                      {
                          MessageBox.Show("You can not delete this income. Because you income is less than your account balance");
                      }
                  }
              });
        }

        private RelayCommand? deleteExpenseCommand;
        public RelayCommand? DeleteExpenseCommand
        {
            get => deleteExpenseCommand ??= new RelayCommand(
              () =>
              {
                  if (AllExpenses.Count > 0)
                  {
                        int selected_balance = 0;
                        for (int i = 0; i < AllAccounts.Count; i++)
                            if ((AllExpenses[SelectedExpenseIndex].AccountName).CompareTo(AllAccounts[i].Name) == 0)
                                selected_balance = i;

                        AllAccounts[selected_balance].Balance += AllExpenses[SelectedExpenseIndex].Price;
                        AllExpenses.RemoveAt(SelectedExpenseIndex);

                        var tmp_list = new ObservableCollection<Budget>();
                        for (int i = 0; i < AllExpenses.Count; i++)
                            tmp_list.Add(AllExpenses[i]);

                        AllExpenses.Clear();

                        AllExpenses = new ObservableCollection<Budget>();
                        for (int i = 0; i < tmp_list.Count; i++)
                            AllExpenses.Add(tmp_list[i]);

                        tmp_list.Clear();

                        string jsonstring = "";
                        string accountjson = "";

                        accountjson = JsonSerializer.Serialize(AllAccounts);
                        File.WriteAllText(accountFile, accountjson);

                        jsonstring = JsonSerializer.Serialize(AllExpenses);
                        File.WriteAllText(expenseFile, jsonstring);

                        SelectedExpenseIndex = 0;
                  }
              });
        }

        private RelayCommand? showBalanceCommand;
        public RelayCommand? ShowBalanceCommand
        {
            get => showBalanceCommand ??= new RelayCommand(
              () =>
              {
                  MessageBox.Show("Your balance in " + AllAccounts[SelectedAccountIndex].Name + " is " + AllAccounts[SelectedAccountIndex].Currency + " " + AllAccounts[SelectedAccountIndex].Balance);
              });
        }

        #endregion
    }
}
