﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using OPAYO.Model;
using OPAYO.Services.Interfaces;
using GalaSoft.MvvmLight;
using GalaSoft.MvvmLight.Command;
using System.Collections.ObjectModel;
using System.Text.Json;
using System.IO;
using System.Windows;

namespace OPAYO.ViewModel
{
    public class CategoryViewModel : ViewModelBase
    {
        private string filename = "categories.json";

        private IConnectionClient _connectionClient;

        public void Show_Icons()
        {
            AllIcons = new ObservableCollection<string>();

            string[] FilesPaths = Directory.GetFiles(@"..\net6.0-windows\Icons\Categories\", "*.png").Select(Path.GetFileName).ToArray();

            for (int i = 0; i < FilesPaths.Length; i++)
            {
                AllIcons.Add("/OPAYO;component/Icons/Categories/" + FilesPaths[i]);
                SourceName = AllIcons[i];
            }

        }

        public CategoryViewModel(IConnectionClient connectionClient)
        {
            _connectionClient = connectionClient;

            Show_Icons();

            if (File.Exists(filename))
                AllCategories = connectionClient.GetCategories();
            else
                AllCategories = new ObservableCollection<Category>();
        }

        #region Filling_Areas

        private string? categoryname;
        public string? CategoryName
        {
            get { return categoryname; }
            set { Set(ref categoryname, value); }
        }

        public int? selectedtypeindex;
        public int? SelectedTypeIndex
        {
            get { return selectedtypeindex; }
            set { Set(ref selectedtypeindex, value); }
        }

        private ObservableCollection<string> allicons;
        public ObservableCollection<string> AllIcons
        {
            get { return allicons; }
            set { Set(ref allicons, value); }
        }

        private string? selectediconpath;
        public string? SelectedIconPath
        {
            get { return selectediconpath; }
            set { Set(ref selectediconpath, value); }
        }

        private string? sourcename;
        public string? SourceName
        {
            get { return sourcename; }
            set { Set(ref sourcename, value); }
        }

        #endregion

        #region Category_library

        private ObservableCollection<Category> allcategories;
        public ObservableCollection<Category> AllCategories
        {
            get { return allcategories; }
            set { Set(ref allcategories, value); }
        }

        public int selectedcategoryindex;
        public int SelectedCategoryIndex
        {
            get { return selectedcategoryindex; }
            set { Set(ref selectedcategoryindex, value); }
        }

        #endregion

        #region Buttons

        private RelayCommand? addcategorycommand;
        public RelayCommand? AddCategoryCommand
        {
            get => addcategorycommand ??= new RelayCommand(
              () =>
              {
                  string? GotComboText;
                  if (SelectedTypeIndex == 0)
                      GotComboText = "Expense";
                  else if (SelectedTypeIndex == 1)
                      GotComboText = "Income";
                  else
                      GotComboText = null;

                  if (String.IsNullOrEmpty(CategoryName) || String.IsNullOrEmpty(GotComboText) || String.IsNullOrEmpty(SelectedIconPath))
                  {
                      MessageBox.Show("Fill category name, choose type and icon");
                      return;
                  }

                  var newcategory = new Category
                  {
                      Name = CategoryName,
                      FinanceType = GotComboText,
                      Icon = SelectedIconPath
                  };

                  AllCategories.Add(newcategory);

                  string jsonstring = JsonSerializer.Serialize(AllCategories);
                  File.WriteAllText(filename, jsonstring);

                  CategoryName = "";
                  SelectedTypeIndex = null;
                  SelectedIconPath = null;
              });
        }

        private RelayCommand? updatecategorycommand;
        public RelayCommand? UpdateCategoryCommand
        {
            get => updatecategorycommand ??= new RelayCommand(
              () =>
              {
                  string? GotComboText;
                  if (SelectedTypeIndex == 0)
                      GotComboText = "Expense";
                  else if (SelectedTypeIndex == 1)
                      GotComboText = "Income";
                  else
                      GotComboText = null;

                  if (String.IsNullOrEmpty(CategoryName) || String.IsNullOrEmpty(GotComboText) || String.IsNullOrEmpty(SelectedIconPath))
                  {
                      MessageBox.Show("Fill category name, choose type and icon");
                      return;
                  }

                  AllCategories[SelectedCategoryIndex].Name = CategoryName;
                  AllCategories[SelectedCategoryIndex].FinanceType = GotComboText;
                  AllCategories[SelectedCategoryIndex].Icon = SelectedIconPath;

                  var tmp_list = new ObservableCollection<Category>();
                  for (int i = 0; i < AllCategories.Count; i++)
                      tmp_list.Add(AllCategories[i]);

                  AllCategories.Clear();

                  AllCategories = new ObservableCollection<Category>();
                  for (int i = 0; i < tmp_list.Count; i++)
                      AllCategories.Add(tmp_list[i]);

                  tmp_list.Clear();

                  string jsonstring = JsonSerializer.Serialize(AllCategories);
                  File.WriteAllText(filename, jsonstring);

                  CategoryName = "";
                  SelectedTypeIndex = null;
                  SelectedIconPath = null;
              });
        }

        private RelayCommand? deletecategorycommand;
        public RelayCommand? DeleteCategoryCommand
        {
            get => deletecategorycommand ??= new RelayCommand(
              () =>
              {
                  if (AllCategories.Count > 0)
                  {
                      AllCategories.RemoveAt(SelectedCategoryIndex);

                      var tmp_list = new ObservableCollection<Category>();

                      for (int i = 0; i < AllCategories.Count; i++)
                          tmp_list.Add(AllCategories[i]);

                      AllCategories.Clear();

                      AllCategories = new ObservableCollection<Category>();
                      for (int i = 0; i < tmp_list.Count; i++)
                          AllCategories.Add(tmp_list[i]);

                      tmp_list.Clear();

                      string jsonstring = JsonSerializer.Serialize(AllCategories);
                      File.WriteAllText(filename, jsonstring);

                      SelectedCategoryIndex = 0;
                  }                  
              });
        }

        private RelayCommand? loadcategorycommand;
        public RelayCommand? LoadCategoryCommand
        {
            get => loadcategorycommand ??= new RelayCommand(
              () =>
              {
                  if (AllCategories.Count > 0)
                  {
                      if (AllCategories[SelectedCategoryIndex].FinanceType == "Expense")
                          SelectedTypeIndex = 0;
                      else
                          SelectedTypeIndex = 1;

                      CategoryName = AllCategories[SelectedCategoryIndex].Name;
                      SelectedIconPath = AllCategories[SelectedCategoryIndex].Icon;
                  }
              });
        }

        #endregion
    }
}
