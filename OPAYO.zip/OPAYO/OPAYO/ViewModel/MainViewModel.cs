﻿using GalaSoft.MvvmLight;
using GalaSoft.MvvmLight.Command;
using GalaSoft.MvvmLight.Messaging;
using OPAYO.Messages;
using OPAYO.Services.Interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OPAYO.ViewModel
{
    public class MainViewModel : ViewModelBase
    {
        private ViewModelBase currentViewModel;

        private INavigationService NavigationService;
        private IMessenger Messenger;
        public ViewModelBase CurrentViewModel { get => currentViewModel; set => Set(ref currentViewModel, value); }

        public MainViewModel(IMessenger messenger, INavigationService navigationService)
        {
            NavigationService = navigationService;
            Messenger = messenger;

            messenger.Register<NavigationMessage>(this, message =>
            {
                var viewModel = App.Container.GetInstance(message.ViewModelType) as ViewModelBase;
                CurrentViewModel = viewModel;
            });
        }

        public RelayCommand CategoryCommand
        {
            get => new RelayCommand(() =>
            {
                NavigationService.NavigateTo<CategoryViewModel>();
            });
        }

        public RelayCommand AccountCommand
        {
            get => new RelayCommand(() =>
            {
                NavigationService.NavigateTo<AccountViewModel>();
            });
        }

        public RelayCommand ExpIncCommand
        {
            get => new RelayCommand(() =>
            {
                NavigationService.NavigateTo<ExpIncViewModel>();
                Messenger.Send(new UpdateMessage());
            });
        }

        public RelayCommand ChartCommand
        {
            get => new RelayCommand(() =>
            {
                NavigationService.NavigateTo<ChartViewModel>();
                Messenger.Send(new UpdateMessage());
            });
        }
    }
}
