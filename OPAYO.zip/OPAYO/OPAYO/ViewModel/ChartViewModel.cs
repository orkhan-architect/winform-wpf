﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using GalaSoft.MvvmLight;
using GalaSoft.MvvmLight.Command;
using GalaSoft.MvvmLight.Messaging;
using OPAYO.Model;
using OPAYO.Services.Interfaces;
using OPAYO.Messages;
using System.Collections.ObjectModel;
using System.Text.Json;
using System.IO;

namespace OPAYO.ViewModel
{
    
    public class ChartViewModel : ViewModelBase
    {
        private string expenseFile = "expenses.json";

        private IConnectionClient _connectionClient;
        private IMessenger _messenger;

        private INavigationService NavigationService;

        private ObservableCollection<Budget> ExpensesList;

        public void Updatelist()
        {
            ExpensesList = _connectionClient.GetExpenses();
        }

        public ChartViewModel(IConnectionClient connectionClient, IMessenger messenger)
        {
            _connectionClient = connectionClient;
            _messenger = messenger;

            if (File.Exists("expenses.json"))
                ExpensesList = connectionClient.GetExpenses();
            else
                ExpensesList = new ObservableCollection<Budget>();

            _messenger.Register<UpdateMessage>(this, message => Updatelist());
        }

        #region FilledAreas

        private DateTime givenDate;
        public DateTime GivenDate
        {
            get { return givenDate; }
            set { Set(ref givenDate, value); }
        }

        #endregion

        #region ShowLibrary

        public string? chartDescription;
        public string? ChartDescription
        {
            get { return chartDescription; }
            set { Set(ref chartDescription, value); }
        }

        private ObservableCollection<Expense> expenseCollection;
        public ObservableCollection<Expense> ExpenseCollection
        {
            get { return expenseCollection; }
            set { Set(ref expenseCollection, value); }
        }

        #endregion

        #region Buttons

        private RelayCommand? dailyCommand;
        public RelayCommand? DailyCommand
        {
            get => dailyCommand ??= new RelayCommand(
              () =>
              {
                  List<string> tmpList = new List<string>();
                  List<Expense> specialList = new List<Expense>();

                  int index = 0;

                  for (int i = 0; i < ExpensesList.Count; i++) {
                      if(DayEquality(ExpensesList[i].CreationDate)) {
                          if(tmpList.Contains(ExpensesList[i].CategoryName)) {
                              index = tmpList.IndexOf(ExpensesList[i].CategoryName);
                              specialList[index].TotalValue += (float)ExpensesList[i].ConvertedPrice;
                          }
                          else
                          {
                              tmpList.Add(ExpensesList[i].CategoryName);
                              specialList.Add(new Expense(ExpensesList[i].CategoryName, (float)ExpensesList[i].ConvertedPrice));
                          }
                      }
                  }

                  if(specialList.Count > 0)
                  {
                      ExpenseCollection = new ObservableCollection<Expense>();

                      for (int i = 0; i < specialList.Count; i++)
                      {
                          ExpenseCollection.Add(specialList[i]);
                      }
                      
                      string searchJSON = "";

                      searchJSON = JsonSerializer.Serialize(ExpenseCollection);
                      File.WriteAllText("searched.json", searchJSON);
                  }

                  ChartDescription = "Chart for the date " + GivenDate.ToString();
              });
        }

        private RelayCommand? monthlyCommand;
        public RelayCommand? MonthlyCommand
        {
            get => monthlyCommand ??= new RelayCommand(
              () =>
              {
                  List<string> tmpList = new List<string>();
                  List<Expense> specialList = new List<Expense>();

                  int index = 0;

                  for (int i = 0; i < ExpensesList.Count; i++)
                  {
                      if (MonthEquality(ExpensesList[i].CreationDate))
                      {
                          if (tmpList.Contains(ExpensesList[i].CategoryName))
                          {
                              index = tmpList.IndexOf(ExpensesList[i].CategoryName);
                              specialList[index].TotalValue += (float)ExpensesList[i].ConvertedPrice;
                          }
                          else
                          {
                              tmpList.Add(ExpensesList[i].CategoryName);
                              specialList.Add(new Expense(ExpensesList[i].CategoryName, (float)ExpensesList[i].ConvertedPrice));
                          }
                      }
                  }

                  if (specialList.Count > 0)
                  {
                      ExpenseCollection = new ObservableCollection<Expense>();

                      for (int i = 0; i < specialList.Count; i++)
                      {
                          ExpenseCollection.Add(specialList[i]);
                      }

                      string searchJSON = "";

                      searchJSON = JsonSerializer.Serialize(ExpenseCollection);
                      File.WriteAllText("searched.json", searchJSON);
                  }

                  ChartDescription = "Chart for a month of the date " + GivenDate.ToString();
              });
        }

        private RelayCommand? yearlyCommand;
        public RelayCommand? YearlyCommand
        {
            get => yearlyCommand ??= new RelayCommand(
              () =>
              {
                  List<string> tmpList = new List<string>();
                  List<Expense> specialList = new List<Expense>();

                  int index = 0;

                  for (int i = 0; i < ExpensesList.Count; i++)
                  {
                      if (YearEquality(ExpensesList[i].CreationDate))
                      {
                          if (tmpList.Contains(ExpensesList[i].CategoryName))
                          {
                              index = tmpList.IndexOf(ExpensesList[i].CategoryName);
                              specialList[index].TotalValue += (float)ExpensesList[i].ConvertedPrice;
                          }
                          else
                          {
                              tmpList.Add(ExpensesList[i].CategoryName);
                              specialList.Add(new Expense(ExpensesList[i].CategoryName, (float)ExpensesList[i].ConvertedPrice));
                          }
                      }
                  }

                  if (specialList.Count > 0)
                  {
                      ExpenseCollection = new ObservableCollection<Expense>();

                      for (int i = 0; i < specialList.Count; i++)
                      {
                          ExpenseCollection.Add(specialList[i]);
                      }

                      string searchJSON = "";

                      searchJSON = JsonSerializer.Serialize(ExpenseCollection);
                      File.WriteAllText("searched.json", searchJSON);
                  }

                  ChartDescription = "Chart for a year of the date " + GivenDate.ToString();
              });
        }

        #endregion

        #region OtherFuncs

        public bool DayEquality(DateTime DateInJSON)
        {
            if(DateInJSON.Year == GivenDate.Year &&
                DateInJSON.Month == GivenDate.Month &&
                DateInJSON.Day == GivenDate.Day)
                return true;
            else
                return false;
        }

        public bool MonthEquality(DateTime DateInJSON)
        {
            if (DateInJSON.Year == GivenDate.Year &&
                DateInJSON.Month == GivenDate.Month)
                return true;
            else
                return false;
        }

        public bool YearEquality(DateTime DateInJSON)
        {
            if (DateInJSON.Year == GivenDate.Year)
                return true;
            else
                return false;
        }

        #endregion
    }

    
}
