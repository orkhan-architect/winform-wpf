﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using OPAYO.Model;
using System.Collections.ObjectModel;

namespace OPAYO.Services.Interfaces
{
    public interface IConnectionClient
    {
        public string GetJsonBase();
        public string GetAccountJson();
        public string GetIncomeJson();
        public string GetExpenseJson();
        public string GetSearchJson();

        public ObservableCollection<Category> GetCategories();
        public ObservableCollection<Account> GetAccounts();
        public ObservableCollection<Budget> GetIncomes();
        public ObservableCollection<Budget> GetExpenses();
        public ObservableCollection<Expense> GetSearch();
    }
}
