﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Text.Json;
using System.IO;
using System.Collections.ObjectModel;
using OPAYO.Services.Interfaces;
using OPAYO.Model;

namespace OPAYO.Services.Classes
{
    public class ConnectionClient : IConnectionClient
    {
        private readonly string filename = "categories.json";
        private readonly string accountFile = "accounts.json";
        private readonly string incomeFile = "incomes.json";
        private readonly string expenseFile = "expenses.json";
        private readonly string searchFile = "searched.json";

        public string GetJsonBase()
        {
            string jsonstring = "";
            if (File.Exists(filename))
                jsonstring = File.ReadAllText(filename);
            return jsonstring;
        }

        public string GetAccountJson()
        {
            string jsonstring = "";
            if (File.Exists(accountFile))
                jsonstring = File.ReadAllText(accountFile);
            return jsonstring;
        }

        public string GetIncomeJson()
        {
            string jsonstring = "";
            if (File.Exists(incomeFile))
                jsonstring = File.ReadAllText(incomeFile);
            return jsonstring;
        }

        public string GetExpenseJson()
        {
            string jsonstring = "";
            if (File.Exists(expenseFile))
                jsonstring = File.ReadAllText(expenseFile);
            return jsonstring;
        }

        public string GetSearchJson()
        {
            string jsonstring = "";
            if (File.Exists(searchFile))
                jsonstring = File.ReadAllText(searchFile);
            return jsonstring;
        }

        public ObservableCollection<Category> GetCategories()
        {
            try
            {
                string jsonstring = GetJsonBase();

                var result = JsonSerializer.Deserialize<ObservableCollection<Category>>(jsonstring);

                return result;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public ObservableCollection<Account> GetAccounts()
        {
            try
            {
                string jsonstring = GetAccountJson();

                var result = JsonSerializer.Deserialize<ObservableCollection<Account>>(jsonstring);

                return result;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public ObservableCollection<Budget> GetIncomes()
        {
            try
            {
                string jsonstring = GetIncomeJson();

                var result = JsonSerializer.Deserialize<ObservableCollection<Budget>>(jsonstring);

                return result;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public ObservableCollection<Budget> GetExpenses()
        {
            try
            {
                string jsonstring = GetExpenseJson();

                var result = JsonSerializer.Deserialize<ObservableCollection<Budget>>(jsonstring);

                return result;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public ObservableCollection<Expense> GetSearch()
        {
            try
            {
                string jsonstring = GetSearchJson();

                var result = JsonSerializer.Deserialize<ObservableCollection<Expense>>(jsonstring);

                return result;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
    }
}
