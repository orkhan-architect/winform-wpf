﻿namespace foodmach
{
    partial class ProductUC
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.product_name_lbl = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.buy_btn = new System.Windows.Forms.Button();
            this.product_price_lbl = new System.Windows.Forms.Label();
            this.product_count_lbl = new System.Windows.Forms.Label();
            this.will_pay_lbl = new System.Windows.Forms.Label();
            this.quantity_lbl = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // product_name_lbl
            // 
            this.product_name_lbl.AutoSize = true;
            this.product_name_lbl.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.product_name_lbl.Location = new System.Drawing.Point(17, 9);
            this.product_name_lbl.Name = "product_name_lbl";
            this.product_name_lbl.Size = new System.Drawing.Size(0, 15);
            this.product_name_lbl.TabIndex = 0;
            this.product_name_lbl.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(3, 33);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(34, 15);
            this.label2.TabIndex = 1;
            this.label2.Text = "AZN";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(3, 48);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(36, 15);
            this.label3.TabIndex = 2;
            this.label3.Text = "stock";
            // 
            // buy_btn
            // 
            this.buy_btn.AutoSize = true;
            this.buy_btn.Location = new System.Drawing.Point(13, 66);
            this.buy_btn.Name = "buy_btn";
            this.buy_btn.Size = new System.Drawing.Size(53, 25);
            this.buy_btn.TabIndex = 3;
            this.buy_btn.Text = "Buy";
            this.buy_btn.UseVisualStyleBackColor = true;
            this.buy_btn.Click += new System.EventHandler(this.buy_btn_Click);
            // 
            // product_price_lbl
            // 
            this.product_price_lbl.AutoSize = true;
            this.product_price_lbl.Location = new System.Drawing.Point(43, 33);
            this.product_price_lbl.Name = "product_price_lbl";
            this.product_price_lbl.Size = new System.Drawing.Size(0, 15);
            this.product_price_lbl.TabIndex = 4;
            // 
            // product_count_lbl
            // 
            this.product_count_lbl.AutoSize = true;
            this.product_count_lbl.Location = new System.Drawing.Point(45, 48);
            this.product_count_lbl.Name = "product_count_lbl";
            this.product_count_lbl.Size = new System.Drawing.Size(0, 15);
            this.product_count_lbl.TabIndex = 5;
            // 
            // will_pay_lbl
            // 
            this.will_pay_lbl.AutoSize = true;
            this.will_pay_lbl.Location = new System.Drawing.Point(32, 0);
            this.will_pay_lbl.Name = "will_pay_lbl";
            this.will_pay_lbl.Size = new System.Drawing.Size(13, 15);
            this.will_pay_lbl.TabIndex = 6;
            this.will_pay_lbl.Text = "0";
            this.will_pay_lbl.Visible = false;
            // 
            // quantity_lbl
            // 
            this.quantity_lbl.AutoSize = true;
            this.quantity_lbl.Location = new System.Drawing.Point(32, 18);
            this.quantity_lbl.Name = "quantity_lbl";
            this.quantity_lbl.Size = new System.Drawing.Size(13, 15);
            this.quantity_lbl.TabIndex = 7;
            this.quantity_lbl.Text = "0";
            this.quantity_lbl.Visible = false;
            // 
            // ProductUC
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.Controls.Add(this.quantity_lbl);
            this.Controls.Add(this.will_pay_lbl);
            this.Controls.Add(this.product_count_lbl);
            this.Controls.Add(this.product_price_lbl);
            this.Controls.Add(this.buy_btn);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.product_name_lbl);
            this.Enabled = false;
            this.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.Name = "ProductUC";
            this.Size = new System.Drawing.Size(77, 100);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Button buy_btn;
        public System.Windows.Forms.Label product_price_lbl;
        public System.Windows.Forms.Label product_count_lbl;
        public System.Windows.Forms.Label will_pay_lbl;
        public System.Windows.Forms.Label quantity_lbl;
        public System.Windows.Forms.Label product_name_lbl;
    }
}
