﻿namespace foodmach
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.AZN_1_btn = new System.Windows.Forms.Button();
            this.AZN_10_btn = new System.Windows.Forms.Button();
            this.AZN_5_btn = new System.Windows.Forms.Button();
            this.AZN_20_btn = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.inserted_money_lbl = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.givenback_money_lbl = new System.Windows.Forms.Label();
            this.basket_btn = new System.Windows.Forms.Button();
            this.clear_btn = new System.Windows.Forms.Button();
            this.pay_btn = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Times New Roman", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(346, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(116, 22);
            this.label1.TabIndex = 0;
            this.label1.Text = "Insert money";
            // 
            // AZN_1_btn
            // 
            this.AZN_1_btn.AutoSize = true;
            this.AZN_1_btn.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.AZN_1_btn.Location = new System.Drawing.Point(343, 34);
            this.AZN_1_btn.Name = "AZN_1_btn";
            this.AZN_1_btn.Size = new System.Drawing.Size(59, 58);
            this.AZN_1_btn.TabIndex = 1;
            this.AZN_1_btn.Text = "1 AZN";
            this.AZN_1_btn.UseVisualStyleBackColor = true;
            this.AZN_1_btn.Click += new System.EventHandler(this.AZN_1_btn_Click);
            // 
            // AZN_10_btn
            // 
            this.AZN_10_btn.AutoSize = true;
            this.AZN_10_btn.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.AZN_10_btn.Location = new System.Drawing.Point(343, 98);
            this.AZN_10_btn.Name = "AZN_10_btn";
            this.AZN_10_btn.Size = new System.Drawing.Size(59, 58);
            this.AZN_10_btn.TabIndex = 2;
            this.AZN_10_btn.Text = "10 AZN";
            this.AZN_10_btn.UseVisualStyleBackColor = true;
            this.AZN_10_btn.Click += new System.EventHandler(this.AZN_10_btn_Click);
            // 
            // AZN_5_btn
            // 
            this.AZN_5_btn.AutoSize = true;
            this.AZN_5_btn.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.AZN_5_btn.Location = new System.Drawing.Point(408, 34);
            this.AZN_5_btn.Name = "AZN_5_btn";
            this.AZN_5_btn.Size = new System.Drawing.Size(59, 58);
            this.AZN_5_btn.TabIndex = 3;
            this.AZN_5_btn.Text = "5 AZN";
            this.AZN_5_btn.UseVisualStyleBackColor = true;
            this.AZN_5_btn.Click += new System.EventHandler(this.AZN_5_btn_Click);
            // 
            // AZN_20_btn
            // 
            this.AZN_20_btn.AutoSize = true;
            this.AZN_20_btn.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.AZN_20_btn.Location = new System.Drawing.Point(408, 98);
            this.AZN_20_btn.Name = "AZN_20_btn";
            this.AZN_20_btn.Size = new System.Drawing.Size(59, 58);
            this.AZN_20_btn.TabIndex = 4;
            this.AZN_20_btn.Text = "20 AZN";
            this.AZN_20_btn.UseVisualStyleBackColor = true;
            this.AZN_20_btn.Click += new System.EventHandler(this.AZN_20_btn_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(346, 168);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(118, 19);
            this.label2.TabIndex = 5;
            this.label2.Text = "Inserted amount";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(353, 187);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(41, 19);
            this.label3.TabIndex = 6;
            this.label3.Text = "AZN";
            // 
            // inserted_money_lbl
            // 
            this.inserted_money_lbl.AutoSize = true;
            this.inserted_money_lbl.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.inserted_money_lbl.Location = new System.Drawing.Point(402, 187);
            this.inserted_money_lbl.Name = "inserted_money_lbl";
            this.inserted_money_lbl.Size = new System.Drawing.Size(17, 19);
            this.inserted_money_lbl.TabIndex = 7;
            this.inserted_money_lbl.Text = "0";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(346, 219);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(106, 19);
            this.label4.TabIndex = 8;
            this.label4.Text = "Rest of money";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(353, 238);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(41, 19);
            this.label5.TabIndex = 9;
            this.label5.Text = "AZN";
            // 
            // givenback_money_lbl
            // 
            this.givenback_money_lbl.AutoSize = true;
            this.givenback_money_lbl.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.givenback_money_lbl.Location = new System.Drawing.Point(404, 238);
            this.givenback_money_lbl.Name = "givenback_money_lbl";
            this.givenback_money_lbl.Size = new System.Drawing.Size(17, 19);
            this.givenback_money_lbl.TabIndex = 10;
            this.givenback_money_lbl.Text = "0";
            // 
            // basket_btn
            // 
            this.basket_btn.AutoSize = true;
            this.basket_btn.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.basket_btn.Location = new System.Drawing.Point(350, 261);
            this.basket_btn.Name = "basket_btn";
            this.basket_btn.Size = new System.Drawing.Size(56, 25);
            this.basket_btn.TabIndex = 11;
            this.basket_btn.Text = "Basket";
            this.basket_btn.UseVisualStyleBackColor = true;
            this.basket_btn.Click += new System.EventHandler(this.basket_btn_Click);
            // 
            // clear_btn
            // 
            this.clear_btn.AutoSize = true;
            this.clear_btn.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.clear_btn.Location = new System.Drawing.Point(350, 292);
            this.clear_btn.Name = "clear_btn";
            this.clear_btn.Size = new System.Drawing.Size(56, 25);
            this.clear_btn.TabIndex = 12;
            this.clear_btn.Text = "Clear";
            this.clear_btn.UseVisualStyleBackColor = true;
            this.clear_btn.Click += new System.EventHandler(this.clear_btn_Click);
            // 
            // pay_btn
            // 
            this.pay_btn.AutoSize = true;
            this.pay_btn.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.pay_btn.Location = new System.Drawing.Point(412, 260);
            this.pay_btn.Name = "pay_btn";
            this.pay_btn.Size = new System.Drawing.Size(55, 57);
            this.pay_btn.TabIndex = 13;
            this.pay_btn.Text = "Pay";
            this.pay_btn.UseVisualStyleBackColor = true;
            this.pay_btn.Click += new System.EventHandler(this.pay_btn_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(481, 330);
            this.Controls.Add(this.pay_btn);
            this.Controls.Add(this.clear_btn);
            this.Controls.Add(this.basket_btn);
            this.Controls.Add(this.givenback_money_lbl);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.inserted_money_lbl);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.AZN_20_btn);
            this.Controls.Add(this.AZN_5_btn);
            this.Controls.Add(this.AZN_10_btn);
            this.Controls.Add(this.AZN_1_btn);
            this.Controls.Add(this.label1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button AZN_1_btn;
        private System.Windows.Forms.Button AZN_10_btn;
        private System.Windows.Forms.Button AZN_5_btn;
        private System.Windows.Forms.Button AZN_20_btn;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label inserted_money_lbl;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label givenback_money_lbl;
        private System.Windows.Forms.Button basket_btn;
        private System.Windows.Forms.Button clear_btn;
        private System.Windows.Forms.Button pay_btn;
    }
}

