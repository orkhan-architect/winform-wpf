﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace foodmach
{
    public class ShoppingBase
    {
        public string shoppingList;
        public Single moneyrest;
        public DateTime shoppingdate;

        public ShoppingBase() { }

        public ShoppingBase(string shoppingList, Single moneyrest)
        {
            this.shoppingList = shoppingList;
            this.moneyrest = moneyrest;
            this.shoppingdate = DateTime.Now;
        }
    }
}
