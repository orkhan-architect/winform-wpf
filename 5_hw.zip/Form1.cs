﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using System.Xml.Serialization;

namespace foodmach
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        public Single shopping_AZN;
        public Single givenback_AZN;

        StringBuilder basket_sb;

        public Product[] Products;

        public List<ProductUC> ProductsSheetUC;

        public List<ShoppingBase> Shoping;

        private void Form1_Load(object sender, EventArgs e)
        {
            string user_path = "productlist.xml";

            if (!File.Exists(user_path))
            {
                Products = new Product[]
                {
                    new Product() { Name = "Cola", Price = 0.70F, Count = 9 },
                    new Product() { Name = "Pepsi", Price = 0.70F, Count = 7 },
                    new Product() { Name = "Fanta", Price = 0.70F, Count = 8 },
                    new Product() { Name = "Ice Tea", Price = 0.50F, Count = 10 },
                    new Product() { Name = "Snickers", Price = 0.90F, Count = 5 },
                    new Product() { Name = "Albeni", Price = 0.50F, Count = 8 },
                    new Product() { Name = "Tutku", Price = 0.40F, Count = 6 },
                    new Product() { Name = "Mars", Price = 0.80F, Count = 7 },
                    new Product() { Name = "Bounty", Price = 0.90F, Count = 5 },
                    new Product() { Name = "Oreo", Price = 1.50F, Count = 8 },
                    new Product() { Name = "Vaffles", Price = 0.80F, Count = 10 },
                    new Product() { Name = "Puf", Price = 0.30F, Count = 10 }
                };

                XmlSerializer xmlFormat = new XmlSerializer(typeof(Product[]));
                using (Stream fStream = File.Create(user_path))
                {
                    xmlFormat.Serialize(fStream, Products);
                }
            }                
            else
            {
                XmlSerializer xmlFormat = new XmlSerializer(typeof(Product[]));
                using (Stream fStream = File.OpenRead(user_path))
                {
                    Products = (Product[])xmlFormat.Deserialize(fStream);
                }
            }

            ProductsSheetUC = new List<ProductUC>();
            for (int i = 0; i < Products.Length; i++)
                ProductsSheetUC.Add(new ProductUC(Products[i].Name, Products[i].Price, Products[i].Count));
            Controls.AddRange(ProductsSheetUC.ToArray());

            int X, Y;
            for (int i = 0, k = 0; i < Products.Length;)
            {
                Y = 5 + 107*k;
                for (int j = 0; j < 4; j++)
                {
                    X = 5 + j * 84;
                    ProductsSheetUC[i].Location = new System.Drawing.Point(X, Y);
                    i++;
                }
                k++;
            }
        }

        private void insert_btns(byte amount)
        {
            byte current_money = Convert.ToByte(inserted_money_lbl.Text);
            byte inserted_money = amount;
            inserted_money_lbl.Text = (current_money + inserted_money).ToString();

            for (int i = 0; i < Products.Length; i++)
            {
                if (Convert.ToByte(inserted_money_lbl.Text) > 0)
                {
                    ProductsSheetUC[i].Enabled = true;
                }
            }
        }

        private void AZN_1_btn_Click(object sender, EventArgs e)
        {
            insert_btns(1);
        }

        private void AZN_5_btn_Click(object sender, EventArgs e)
        {
            insert_btns(5);
        }

        private void AZN_10_btn_Click(object sender, EventArgs e)
        {
            insert_btns(10);
        }

        private void AZN_20_btn_Click(object sender, EventArgs e)
        {
            insert_btns(20);
        }

        private void clear_btn_Click(object sender, EventArgs e)
        {
            for (int i = 0; i < Products.Length; i++)
            {
                ProductsSheetUC[i].product_count_lbl.Text = Products[i].Count.ToString();
                ProductsSheetUC[i].product_price_lbl.Text = Products[i].Price.ToString();
                ProductsSheetUC[i].will_pay_lbl.Text = "0";
                ProductsSheetUC[i].quantity_lbl.Text = "0";
            }
            shopping_AZN = 0;
            givenback_AZN = 0;
            givenback_money_lbl.Text = "0";
        }

        private void basket_btn_Click(object sender, EventArgs e)
        {
            shopping_AZN = 0;
            Product[] tmp_product = new Product[12];
            basket_sb = new StringBuilder();

            for (int i = 0; i < tmp_product.Length; i++)
            {
                if (Convert.ToByte(ProductsSheetUC[i].quantity_lbl.Text) > 0)
                {
                    tmp_product[i] = new Product
                    {
                        Name = ProductsSheetUC[i].product_name_lbl.Text,
                        Price = Convert.ToSingle(ProductsSheetUC[i].will_pay_lbl.Text),
                        Count = Convert.ToByte(ProductsSheetUC[i].quantity_lbl.Text)
                    };
                    basket_sb.Append(tmp_product[i]);

                    shopping_AZN += tmp_product[i].Price;
                }                
            }

            basket_sb.Append("\n Your shopping payment will " + shopping_AZN.ToString() + " AZN");

            MessageBox.Show(basket_sb.ToString());

            Single mymoney = Convert.ToSingle(inserted_money_lbl.Text);
            if (mymoney >= shopping_AZN && shopping_AZN > 0)
            {
                givenback_AZN = mymoney - shopping_AZN;
                givenback_money_lbl.Text = givenback_AZN.ToString();
            }
            else
            {
                givenback_money_lbl.Text = "0";
                MessageBox.Show("You have not enough money or you did not shop yet");
            }
        }

        private void pay_btn_Click(object sender, EventArgs e)
        {
            Single mymoney = Convert.ToSingle(inserted_money_lbl.Text);

            string shopping_path = "shopinglist.xml";

            if (mymoney >= shopping_AZN)
            {
                if (!File.Exists(shopping_path))
                {
                    Shoping = new List<ShoppingBase>();                    
                }
                else
                {
                    XmlSerializer xmlFormat = new XmlSerializer(typeof(List<ShoppingBase>));
                    using (Stream fStream = File.OpenRead(shopping_path))
                    {
                        Shoping = (List<ShoppingBase>)xmlFormat.Deserialize(fStream);
                    }
                }

                ShoppingBase new_one = new ShoppingBase(basket_sb.ToString(), (Single)(mymoney - shopping_AZN));

                Shoping.Add(new_one);
                XmlSerializer xmlFormat2 = new XmlSerializer(typeof(List<ShoppingBase>));
                using (Stream fStream = File.Create(shopping_path))
                {
                    xmlFormat2.Serialize(fStream, Shoping);
                }

                Product[] tmp_prod = new Product[Products.Length];
                for (int i = 0; i < Products.Length; i++)
                {
                    tmp_prod[i] = new Product
                    {
                        Name = ProductsSheetUC[i].product_name_lbl.Text,
                        Price = Convert.ToSingle(ProductsSheetUC[i].product_price_lbl.Text),
                        Count = Convert.ToByte(ProductsSheetUC[i].product_count_lbl.Text)
                    };
                }
                Products = tmp_prod;

                string user_path = "productlist.xml";
                XmlSerializer xmlFormat3 = new XmlSerializer(typeof(Product[]));
                using (Stream fStream = File.Create(user_path))
                {
                    xmlFormat3.Serialize(fStream, Products);
                }

                for (int i = 0; i < Products.Length; i++)
                {
                    ProductsSheetUC[i].will_pay_lbl.Text = "0";
                    ProductsSheetUC[i].quantity_lbl.Text = "0";
                }

                basket_sb.Clear();
                shopping_AZN = 0;
                givenback_AZN = 0;
                inserted_money_lbl.Text = "0";
                givenback_money_lbl.Text = "0";

                MessageBox.Show("Thanks for shopping. Good luck");
            }
            else
            {
                MessageBox.Show("You have not enough money for shopping. Insert money");
            }
        }
    }
}
