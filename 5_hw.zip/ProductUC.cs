﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace foodmach
{
    public partial class ProductUC : UserControl
    {
        public ProductUC()
        {
            InitializeComponent();
        }

        public ProductUC(string name, Single price, byte count)
        {
            InitializeComponent();

            product_name_lbl.Text = name;
            product_price_lbl.Text = price.ToString();
            product_count_lbl.Text = count.ToString();
        }

        private void buy_btn_Click(object sender, EventArgs e)
        {
            byte in_stock = Convert.ToByte(product_count_lbl.Text);
            byte got_count = Convert.ToByte(quantity_lbl.Text);
            Single wil_pay_price = Convert.ToSingle(will_pay_lbl.Text);
            if (in_stock > 0)
            {
                in_stock--;
                got_count++;
                wil_pay_price += Convert.ToSingle(product_price_lbl.Text);

                product_count_lbl.Text = in_stock.ToString();
                quantity_lbl.Text = got_count.ToString();
                will_pay_lbl.Text = wil_pay_price.ToString();
            }
        }
    }
}
