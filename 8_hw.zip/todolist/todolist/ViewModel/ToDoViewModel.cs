﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.ComponentModel;
using System.Reflection;
using GalaSoft.MvvmLight;
using GalaSoft.MvvmLight.Command;
using todolist.Model;
using System.Reflection;
using System.Windows;
using System.Windows.Input;
using System.ComponentModel;
using System.Runtime.CompilerServices;
using System.Collections.ObjectModel;

namespace todolist.ViewModel
{
    public class ToDoViewModel : ViewModelBase, INotifyPropertyChanged
    {
        public event PropertyChangedEventHandler PropertyChanged;
        public void OnPropertyChanged([CallerMemberName] string prop="")
        {
            if (PropertyChanged != null)
                PropertyChanged(this, new PropertyChangedEventArgs(prop));
        }        

        private string? planname;
        public string? PlanName 
        { 
            get { return planname; }
            set { planname = value; OnPropertyChanged("PlanName"); }
        }

        private string? plandesc;
        public string? PlanDesc
        {
            get { return plandesc; }
            set { plandesc = value; OnPropertyChanged("PlanDesc"); }
        }

        private string? plandeadline;
        public string? PlanDeadline
        {
            get { return plandeadline; }
            set { plandeadline = value; OnPropertyChanged("PlanDeadline"); }
        }

        private string? plancreation;
        public string? PlanCreation
        {
            get { return plancreation; }
            set { plancreation = value; OnPropertyChanged("PlanCreation"); }
        }

        private ObservableCollection<ToDoModel> allplan;
        public ObservableCollection<ToDoModel> AllPlan
        {
            get { return allplan; }
            set { allplan = value; OnPropertyChanged("AllPlan"); }
        }

        private int selectedplanindex;
        public int SelectedPlanIndex
        {
            get { return selectedplanindex; }
            set { selectedplanindex = value; }
        }

        public ToDoViewModel()
        {
            AllPlan = new ObservableCollection<ToDoModel>();

        }

        private RelayCommand? addcommand;
        public RelayCommand? AddCommand
        {
            get => addcommand ??= new RelayCommand(
              () =>
              {
                  var todo = new ToDoModel
                  {                     
                    Name = PlanName,
                    Description = PlanDesc,
                    CreationDate = DateTime.Parse(PlanCreation),
                    DeadlineDate = DateTime.Parse(PlanDeadline),
                    Done = false,
                    DoneColor = "Red"
                  };

                  AllPlan.Add(todo);                  
              });
        }

        private RelayCommand? donecommand;
        public RelayCommand? DoneCommand
        {
            get => donecommand ??= new RelayCommand(
              () =>
              {
                  AllPlan[SelectedPlanIndex].DoneColor = "Green";
                  AllPlan[SelectedPlanIndex].Done = true;

                  var tmp_list = new ObservableCollection<ToDoModel>();
                  for (int i = 0; i < AllPlan.Count; i++)                  
                      tmp_list.Add(AllPlan[i]);

                  AllPlan.Clear();

                  AllPlan = new ObservableCollection<ToDoModel>();
                  for (int i = 0; i < tmp_list.Count; i++)
                      AllPlan.Add(tmp_list[i]);

                  tmp_list.Clear();
              });
        }

        private RelayCommand? deletecommand;
        public RelayCommand? DeleteCommand
        {
            get => deletecommand ??= new RelayCommand(
              () =>
              {
                  AllPlan.RemoveAt(SelectedPlanIndex);

                  var tmp_list = new ObservableCollection<ToDoModel>();
                  for (int i = 0; i < AllPlan.Count; i++)
                      tmp_list.Add(AllPlan[i]);

                  AllPlan.Clear();

                  AllPlan = new ObservableCollection<ToDoModel>();
                  for (int i = 0; i < tmp_list.Count; i++)
                      AllPlan.Add(tmp_list[i]);

                  tmp_list.Clear();
              });
        }
    }
}
