﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace todolist.Model
{
    public class ToDoModel
    {
        public string? Name { get; set; }
        public string? Description { get; set; }
        public DateTime? CreationDate { get; set; }
        public DateTime? DeadlineDate { get; set; }
        public bool Done { get; set; }
        public string? DoneColor { get; set; }

        public ToDoModel() { }

        public override string ToString()
        {
            return $"{Name} {DeadlineDate}";
        }
    }
}
