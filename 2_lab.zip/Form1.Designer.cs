﻿namespace lab2
{
    partial class Questionnaire
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.questionnaire_gbox = new System.Windows.Forms.GroupBox();
            this.update_btn = new System.Windows.Forms.Button();
            this.insert_btn = new System.Windows.Forms.Button();
            this.contact_txtbox = new System.Windows.Forms.TextBox();
            this.mail_txtbox = new System.Windows.Forms.TextBox();
            this.name_txtbox = new System.Windows.Forms.TextBox();
            this.surname_txtbox = new System.Windows.Forms.TextBox();
            this.fincode_txtbox = new System.Windows.Forms.TextBox();
            this.birthdate_dpicker = new System.Windows.Forms.DateTimePicker();
            this.birthdate_lbl = new System.Windows.Forms.Label();
            this.contact_lbl = new System.Windows.Forms.Label();
            this.email_lbl = new System.Windows.Forms.Label();
            this.name_lbl = new System.Windows.Forms.Label();
            this.surname_lbl = new System.Windows.Forms.Label();
            this.fincode_lbl = new System.Windows.Forms.Label();
            this.quest_listbox = new System.Windows.Forms.ListBox();
            this.filename_txtbox = new System.Windows.Forms.TextBox();
            this.load_btn = new System.Windows.Forms.Button();
            this.save_btn = new System.Windows.Forms.Button();
            this.questionnaire_gbox.SuspendLayout();
            this.SuspendLayout();
            // 
            // questionnaire_gbox
            // 
            this.questionnaire_gbox.Controls.Add(this.update_btn);
            this.questionnaire_gbox.Controls.Add(this.insert_btn);
            this.questionnaire_gbox.Controls.Add(this.contact_txtbox);
            this.questionnaire_gbox.Controls.Add(this.mail_txtbox);
            this.questionnaire_gbox.Controls.Add(this.name_txtbox);
            this.questionnaire_gbox.Controls.Add(this.surname_txtbox);
            this.questionnaire_gbox.Controls.Add(this.fincode_txtbox);
            this.questionnaire_gbox.Controls.Add(this.birthdate_dpicker);
            this.questionnaire_gbox.Controls.Add(this.birthdate_lbl);
            this.questionnaire_gbox.Controls.Add(this.contact_lbl);
            this.questionnaire_gbox.Controls.Add(this.email_lbl);
            this.questionnaire_gbox.Controls.Add(this.name_lbl);
            this.questionnaire_gbox.Controls.Add(this.surname_lbl);
            this.questionnaire_gbox.Controls.Add(this.fincode_lbl);
            this.questionnaire_gbox.Font = new System.Drawing.Font("Times New Roman", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.questionnaire_gbox.Location = new System.Drawing.Point(18, 18);
            this.questionnaire_gbox.Margin = new System.Windows.Forms.Padding(4);
            this.questionnaire_gbox.Name = "questionnaire_gbox";
            this.questionnaire_gbox.Padding = new System.Windows.Forms.Padding(4);
            this.questionnaire_gbox.Size = new System.Drawing.Size(331, 321);
            this.questionnaire_gbox.TabIndex = 0;
            this.questionnaire_gbox.TabStop = false;
            this.questionnaire_gbox.Text = "Questionnaire";
            // 
            // update_btn
            // 
            this.update_btn.AutoSize = true;
            this.update_btn.Font = new System.Drawing.Font("Times New Roman", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.update_btn.Location = new System.Drawing.Point(124, 268);
            this.update_btn.Name = "update_btn";
            this.update_btn.Size = new System.Drawing.Size(85, 34);
            this.update_btn.TabIndex = 13;
            this.update_btn.Text = "Update";
            this.update_btn.UseVisualStyleBackColor = true;
            this.update_btn.Visible = false;
            this.update_btn.Click += new System.EventHandler(this.update_btn_Click);
            // 
            // insert_btn
            // 
            this.insert_btn.AutoSize = true;
            this.insert_btn.Font = new System.Drawing.Font("Times New Roman", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.insert_btn.Location = new System.Drawing.Point(239, 268);
            this.insert_btn.Name = "insert_btn";
            this.insert_btn.Size = new System.Drawing.Size(85, 34);
            this.insert_btn.TabIndex = 12;
            this.insert_btn.Text = "Insert";
            this.insert_btn.UseVisualStyleBackColor = true;
            this.insert_btn.Click += new System.EventHandler(this.insert_btn_Click);
            // 
            // contact_txtbox
            // 
            this.contact_txtbox.Location = new System.Drawing.Point(124, 181);
            this.contact_txtbox.Name = "contact_txtbox";
            this.contact_txtbox.Size = new System.Drawing.Size(200, 32);
            this.contact_txtbox.TabIndex = 11;
            // 
            // mail_txtbox
            // 
            this.mail_txtbox.Location = new System.Drawing.Point(124, 143);
            this.mail_txtbox.Name = "mail_txtbox";
            this.mail_txtbox.Size = new System.Drawing.Size(200, 32);
            this.mail_txtbox.TabIndex = 10;
            // 
            // name_txtbox
            // 
            this.name_txtbox.Location = new System.Drawing.Point(124, 105);
            this.name_txtbox.Name = "name_txtbox";
            this.name_txtbox.Size = new System.Drawing.Size(200, 32);
            this.name_txtbox.TabIndex = 9;
            // 
            // surname_txtbox
            // 
            this.surname_txtbox.Location = new System.Drawing.Point(124, 67);
            this.surname_txtbox.Name = "surname_txtbox";
            this.surname_txtbox.Size = new System.Drawing.Size(200, 32);
            this.surname_txtbox.TabIndex = 8;
            // 
            // fincode_txtbox
            // 
            this.fincode_txtbox.Location = new System.Drawing.Point(124, 29);
            this.fincode_txtbox.Name = "fincode_txtbox";
            this.fincode_txtbox.Size = new System.Drawing.Size(200, 32);
            this.fincode_txtbox.TabIndex = 7;
            // 
            // birthdate_dpicker
            // 
            this.birthdate_dpicker.Location = new System.Drawing.Point(124, 219);
            this.birthdate_dpicker.Name = "birthdate_dpicker";
            this.birthdate_dpicker.Size = new System.Drawing.Size(200, 32);
            this.birthdate_dpicker.TabIndex = 6;
            // 
            // birthdate_lbl
            // 
            this.birthdate_lbl.AutoSize = true;
            this.birthdate_lbl.Font = new System.Drawing.Font("Times New Roman", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.birthdate_lbl.Location = new System.Drawing.Point(11, 227);
            this.birthdate_lbl.Name = "birthdate_lbl";
            this.birthdate_lbl.Size = new System.Drawing.Size(95, 24);
            this.birthdate_lbl.TabIndex = 5;
            this.birthdate_lbl.Text = "Birthdate";
            // 
            // contact_lbl
            // 
            this.contact_lbl.AutoSize = true;
            this.contact_lbl.Font = new System.Drawing.Font("Times New Roman", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.contact_lbl.Location = new System.Drawing.Point(11, 189);
            this.contact_lbl.Name = "contact_lbl";
            this.contact_lbl.Size = new System.Drawing.Size(82, 24);
            this.contact_lbl.TabIndex = 4;
            this.contact_lbl.Text = "Contact";
            // 
            // email_lbl
            // 
            this.email_lbl.AutoSize = true;
            this.email_lbl.Font = new System.Drawing.Font("Times New Roman", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.email_lbl.Location = new System.Drawing.Point(11, 151);
            this.email_lbl.Name = "email_lbl";
            this.email_lbl.Size = new System.Drawing.Size(62, 24);
            this.email_lbl.TabIndex = 3;
            this.email_lbl.Text = "Email";
            // 
            // name_lbl
            // 
            this.name_lbl.AutoSize = true;
            this.name_lbl.Font = new System.Drawing.Font("Times New Roman", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.name_lbl.Location = new System.Drawing.Point(11, 113);
            this.name_lbl.Name = "name_lbl";
            this.name_lbl.Size = new System.Drawing.Size(63, 24);
            this.name_lbl.TabIndex = 2;
            this.name_lbl.Text = "Name";
            // 
            // surname_lbl
            // 
            this.surname_lbl.AutoSize = true;
            this.surname_lbl.Font = new System.Drawing.Font("Times New Roman", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.surname_lbl.Location = new System.Drawing.Point(11, 75);
            this.surname_lbl.Name = "surname_lbl";
            this.surname_lbl.Size = new System.Drawing.Size(90, 24);
            this.surname_lbl.TabIndex = 1;
            this.surname_lbl.Text = "Surname";
            // 
            // fincode_lbl
            // 
            this.fincode_lbl.AutoSize = true;
            this.fincode_lbl.Font = new System.Drawing.Font("Times New Roman", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.fincode_lbl.Location = new System.Drawing.Point(11, 37);
            this.fincode_lbl.Name = "fincode_lbl";
            this.fincode_lbl.Size = new System.Drawing.Size(82, 24);
            this.fincode_lbl.TabIndex = 0;
            this.fincode_lbl.Text = "Fincode";
            // 
            // quest_listbox
            // 
            this.quest_listbox.FormattingEnabled = true;
            this.quest_listbox.ItemHeight = 19;
            this.quest_listbox.Location = new System.Drawing.Point(357, 28);
            this.quest_listbox.Name = "quest_listbox";
            this.quest_listbox.Size = new System.Drawing.Size(174, 194);
            this.quest_listbox.TabIndex = 1;
            this.quest_listbox.SelectedIndexChanged += new System.EventHandler(this.quest_listbox_SelectedIndexChanged);
            // 
            // filename_txtbox
            // 
            this.filename_txtbox.Font = new System.Drawing.Font("Times New Roman", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.filename_txtbox.Location = new System.Drawing.Point(356, 237);
            this.filename_txtbox.Name = "filename_txtbox";
            this.filename_txtbox.Size = new System.Drawing.Size(175, 32);
            this.filename_txtbox.TabIndex = 2;
            this.filename_txtbox.MouseMove += new System.Windows.Forms.MouseEventHandler(this.filename_txtbox_MouseMove);
            // 
            // load_btn
            // 
            this.load_btn.AutoSize = true;
            this.load_btn.Font = new System.Drawing.Font("Times New Roman", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.load_btn.Location = new System.Drawing.Point(357, 286);
            this.load_btn.Name = "load_btn";
            this.load_btn.Size = new System.Drawing.Size(75, 34);
            this.load_btn.TabIndex = 3;
            this.load_btn.Text = "Load";
            this.load_btn.UseVisualStyleBackColor = true;
            this.load_btn.Click += new System.EventHandler(this.load_btn_Click);
            // 
            // save_btn
            // 
            this.save_btn.AutoSize = true;
            this.save_btn.Font = new System.Drawing.Font("Times New Roman", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.save_btn.Location = new System.Drawing.Point(456, 286);
            this.save_btn.Name = "save_btn";
            this.save_btn.Size = new System.Drawing.Size(75, 34);
            this.save_btn.TabIndex = 4;
            this.save_btn.Text = "Save";
            this.save_btn.UseVisualStyleBackColor = true;
            this.save_btn.Click += new System.EventHandler(this.save_btn_Click);
            // 
            // Questionnaire
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 19F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(555, 361);
            this.Controls.Add(this.save_btn);
            this.Controls.Add(this.load_btn);
            this.Controls.Add(this.filename_txtbox);
            this.Controls.Add(this.quest_listbox);
            this.Controls.Add(this.questionnaire_gbox);
            this.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "Questionnaire";
            this.Text = "Questionnaire";
            this.questionnaire_gbox.ResumeLayout(false);
            this.questionnaire_gbox.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.GroupBox questionnaire_gbox;
        private System.Windows.Forms.TextBox contact_txtbox;
        private System.Windows.Forms.TextBox mail_txtbox;
        private System.Windows.Forms.TextBox name_txtbox;
        private System.Windows.Forms.TextBox surname_txtbox;
        private System.Windows.Forms.TextBox fincode_txtbox;
        private System.Windows.Forms.DateTimePicker birthdate_dpicker;
        private System.Windows.Forms.Label birthdate_lbl;
        private System.Windows.Forms.Label contact_lbl;
        private System.Windows.Forms.Label email_lbl;
        private System.Windows.Forms.Label name_lbl;
        private System.Windows.Forms.Label surname_lbl;
        private System.Windows.Forms.Label fincode_lbl;
        private System.Windows.Forms.Button update_btn;
        private System.Windows.Forms.Button insert_btn;
        private System.Windows.Forms.ListBox quest_listbox;
        private System.Windows.Forms.TextBox filename_txtbox;
        private System.Windows.Forms.Button load_btn;
        private System.Windows.Forms.Button save_btn;
    }
}

