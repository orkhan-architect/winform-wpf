﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Text.RegularExpressions;
using System.IO;
using System.Xml.Serialization;

namespace lab2
{
    public partial class Questionnaire : Form
    {
        public Questionnaire()
        {
            InitializeComponent();
        }

        public List<Personal> packages = new List<Personal>();

        private void filename_txtbox_MouseMove(object sender, MouseEventArgs e)
        {
            ToolTip tooltip1 = new ToolTip();

            tooltip1.AutoPopDelay = 5000;
            tooltip1.InitialDelay = 1000;
            tooltip1.ReshowDelay = 500;
            tooltip1.ShowAlways = true;

            tooltip1.SetToolTip(this.filename_txtbox, "enter file name for loading listbox");
        }

        private void insert_btn_Click(object sender, EventArgs e)
        {
            const string emailPattern = @"^([a-z0-9_-]+\.)*[a-z0-9_-]+@[a-z0-9_-]+(\.[a-z0-9_-]+)*\.[a-z]{2,6}$";
            const string phonePattern = @"^\(?[\+]?994[-]?([1-9]{2})\)?[-. ]?([0-9]{3})[-. ]?([0-9]{2})[-.]?([0-9]{2})$";
            /*
             contact input options for Azerbaijan
            +99455-123-45-67
            +99455.123.45.67
            +99455-1234567
            +994551234567
            and etc.
             */

            string fincode = fincode_txtbox.Text.ToUpper();
            string surname = surname_txtbox.Text.ToUpper();
            string name = name_txtbox.Text.ToUpper();
            string mail = mail_txtbox.Text;
            string contact = contact_txtbox.Text;
            DateTime birthdate = birthdate_dpicker.Value;            

            Regex regex = new Regex(emailPattern);
            if (!regex.IsMatch(mail))
            {
                MessageBox.Show("Error.\nHint: test@test.com");
                return;
            }                

            regex = new Regex(phonePattern);
            if (!regex.IsMatch(contact))
            {
                MessageBox.Show("Error.\nHint: +99455-123-45-67");
                return;
            }

            var new_questionnaire = new Personal
            {
                Fincode = fincode,
                Surname = surname,
                Name = name,
                Mail = mail,
                Contact = contact,
                Birthdate = birthdate
            };

            packages.Add(new_questionnaire);

            quest_listbox.Items.Add(new_questionnaire);

            fincode_txtbox.Text = "";
            surname_txtbox.Text = "";
            name_txtbox.Text = "";
            mail_txtbox.Text = "";
            contact_txtbox.Text = "";
            birthdate_dpicker.Value = DateTime.Now;
        }

        private void save_btn_Click(object sender, EventArgs e)
        {
            if (!Directory.Exists("packetlists"))
                Directory.CreateDirectory("packetlists");

            string user_path = "";
            if (!String.IsNullOrEmpty(filename_txtbox.Text))
                user_path = "packetlists/" + filename_txtbox.Text + ".xml";

                         
            XmlSerializer xmlFormat = new XmlSerializer(typeof(List<Personal>));
            using (Stream fStream = File.Create(user_path))
            {
                xmlFormat.Serialize(fStream, packages);
            }

            MessageBox.Show("file was added/edited in our system");

            packages.Clear();
            quest_listbox.Items.Clear();
            filename_txtbox.Text = "";
        }

        private void load_btn_Click(object sender, EventArgs e)
        {
            if (packages.Count == 0)
            {
                string user_path = "";
                if (!String.IsNullOrEmpty(filename_txtbox.Text))
                    user_path = "packetlists/" + filename_txtbox.Text + ".xml";

                if (File.Exists(user_path))
                {
                    XmlSerializer xmlFormat = new XmlSerializer(typeof(List<Personal>));
                    using (Stream fStream = File.OpenRead(user_path))
                    {
                        packages = (List<Personal>)xmlFormat.Deserialize(fStream);
                        quest_listbox.Items.AddRange(packages.ToArray());
                    }
                }
                else
                {
                    MessageBox.Show("this file does not exist in our system");
                }
            }
            else
            {
                MessageBox.Show("save your file. load then");
            }
        }

        private void quest_listbox_SelectedIndexChanged(object sender, EventArgs e)
        {
            update_btn.Visible = true;
            insert_btn.Visible = false;

            int ID = quest_listbox.SelectedIndex;

            fincode_txtbox.Text = packages[ID].Fincode;
            surname_txtbox.Text = packages[ID].Surname;
            name_txtbox.Text = packages[ID].Name;
            mail_txtbox.Text = packages[ID].Mail;
            contact_txtbox.Text = packages[ID].Contact;
            birthdate_dpicker.Value = packages[ID].Birthdate;
        }

        private void update_btn_Click(object sender, EventArgs e)
        {
            const string emailPattern = @"^([a-z0-9_-]+\.)*[a-z0-9_-]+@[a-z0-9_-]+(\.[a-z0-9_-]+)*\.[a-z]{2,6}$";
            const string phonePattern = @"^\(?[\+]?994[-]?([1-9]{2})\)?[-. ]?([0-9]{3})[-. ]?([0-9]{2})[-.]?([0-9]{2})$";
            /*
             contact input options for Azerbaijan
            +99455-123-45-67
            +99455.123.45.67
            +99455-1234567
            +994551234567
            and etc.
             */

            string fincode = fincode_txtbox.Text.ToUpper();
            string surname = surname_txtbox.Text.ToUpper();
            string name = name_txtbox.Text.ToUpper();
            string mail = mail_txtbox.Text;
            string contact = contact_txtbox.Text;
            DateTime birthdate = birthdate_dpicker.Value;

            Regex regex = new Regex(emailPattern);
            if (!regex.IsMatch(mail))
            {
                MessageBox.Show("Error.\nHint: test@test.com");
                return;
            }

            regex = new Regex(phonePattern);
            if (!regex.IsMatch(contact))
            {
                MessageBox.Show("Error.\nHint: +99455-123-45-67");
                return;
            }

            int ID = quest_listbox.SelectedIndex;

            packages[ID].Fincode = fincode;
            packages[ID].Surname = surname;
            packages[ID].Name = name;
            packages[ID].Mail = mail;
            packages[ID].Contact = contact;
            packages[ID].Birthdate = birthdate;

            fincode_txtbox.Text = "";
            surname_txtbox.Text = "";
            name_txtbox.Text = "";
            mail_txtbox.Text = "";
            contact_txtbox.Text = "";
            birthdate_dpicker.Value = DateTime.Now;

            update_btn.Visible = false;
            insert_btn.Visible = true;

            MessageBox.Show("successfully updated");
        }
    }

    public class Personal
    {
        public string Fincode { get; set; }
        public string Surname { get; set; }
        public string Name { get; set; }
        public string Mail { get; set; }
        public string Contact { get; set; }
        public DateTime Birthdate { get; set; }

        public Personal() { }

        public override string ToString()
        {
            return $"{Fincode} {Surname}";
        }
    }
}
