﻿namespace students_sheet
{
    partial class students_notes
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.students_group_lbl = new System.Windows.Forms.Label();
            this.subject_lbl = new System.Windows.Forms.Label();
            this.main_lector_rbutton = new System.Windows.Forms.RadioButton();
            this.subst_lector_rbutton = new System.Windows.Forms.RadioButton();
            this.theme_lbl = new System.Windows.Forms.Label();
            this.theme_name_lbl = new System.Windows.Forms.Label();
            this.theme_name_textbox = new System.Windows.Forms.TextBox();
            this.change_btn = new System.Windows.Forms.Button();
            this.cancel_btn = new System.Windows.Forms.Button();
            this.header_gbox = new System.Windows.Forms.GroupBox();
            this.check_all_rbutton = new System.Windows.Forms.RadioButton();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.crystal_count_lbl = new System.Windows.Forms.Label();
            this.class_work_lbl = new System.Windows.Forms.Label();
            this.test_work_lbl = new System.Windows.Forms.Label();
            this.student_check_lbl = new System.Windows.Forms.Label();
            this.appearance_lbl = new System.Windows.Forms.Label();
            this.name_surname_lbl = new System.Windows.Forms.Label();
            this.student_1_gbox = new System.Windows.Forms.GroupBox();
            this.button13 = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.comboBox1 = new System.Windows.Forms.ComboBox();
            this.radioButton3 = new System.Windows.Forms.RadioButton();
            this.radioButton2 = new System.Windows.Forms.RadioButton();
            this.radioButton1 = new System.Windows.Forms.RadioButton();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.label1 = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.button14 = new System.Windows.Forms.Button();
            this.button4 = new System.Windows.Forms.Button();
            this.button5 = new System.Windows.Forms.Button();
            this.button6 = new System.Windows.Forms.Button();
            this.comboBox3 = new System.Windows.Forms.ComboBox();
            this.comboBox4 = new System.Windows.Forms.ComboBox();
            this.radioButton4 = new System.Windows.Forms.RadioButton();
            this.radioButton5 = new System.Windows.Forms.RadioButton();
            this.radioButton6 = new System.Windows.Forms.RadioButton();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.label6 = new System.Windows.Forms.Label();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.button15 = new System.Windows.Forms.Button();
            this.button7 = new System.Windows.Forms.Button();
            this.button8 = new System.Windows.Forms.Button();
            this.button9 = new System.Windows.Forms.Button();
            this.comboBox5 = new System.Windows.Forms.ComboBox();
            this.comboBox6 = new System.Windows.Forms.ComboBox();
            this.radioButton7 = new System.Windows.Forms.RadioButton();
            this.radioButton8 = new System.Windows.Forms.RadioButton();
            this.radioButton9 = new System.Windows.Forms.RadioButton();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.pictureBox4 = new System.Windows.Forms.PictureBox();
            this.label9 = new System.Windows.Forms.Label();
            this.theme_name_btn = new System.Windows.Forms.Button();
            this.comboBox2 = new System.Windows.Forms.ComboBox();
            this.header_gbox.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.student_1_gbox.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            this.groupBox2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).BeginInit();
            this.SuspendLayout();
            // 
            // students_group_lbl
            // 
            this.students_group_lbl.AutoSize = true;
            this.students_group_lbl.Font = new System.Drawing.Font("Times New Roman", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.students_group_lbl.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(2)))), ((int)(((byte)(166)))), ((int)(((byte)(243)))));
            this.students_group_lbl.Location = new System.Drawing.Point(12, 9);
            this.students_group_lbl.Name = "students_group_lbl";
            this.students_group_lbl.Size = new System.Drawing.Size(129, 21);
            this.students_group_lbl.TabIndex = 0;
            this.students_group_lbl.Text = "FBAS_1215_az";
            // 
            // subject_lbl
            // 
            this.subject_lbl.AutoSize = true;
            this.subject_lbl.Font = new System.Drawing.Font("Times New Roman", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.subject_lbl.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(2)))), ((int)(((byte)(166)))), ((int)(((byte)(243)))));
            this.subject_lbl.Location = new System.Drawing.Point(164, 9);
            this.subject_lbl.Name = "subject_lbl";
            this.subject_lbl.Size = new System.Drawing.Size(584, 21);
            this.subject_lbl.TabIndex = 1;
            this.subject_lbl.Text = "(Basics of application development using Windows Forms and WPF (CT-3))";
            // 
            // main_lector_rbutton
            // 
            this.main_lector_rbutton.AutoSize = true;
            this.main_lector_rbutton.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.main_lector_rbutton.Location = new System.Drawing.Point(16, 34);
            this.main_lector_rbutton.Name = "main_lector_rbutton";
            this.main_lector_rbutton.Size = new System.Drawing.Size(93, 21);
            this.main_lector_rbutton.TabIndex = 2;
            this.main_lector_rbutton.Text = "Main lector";
            this.main_lector_rbutton.UseVisualStyleBackColor = true;
            this.main_lector_rbutton.CheckedChanged += new System.EventHandler(this.main_lector_rbutton_CheckedChanged);
            // 
            // subst_lector_rbutton
            // 
            this.subst_lector_rbutton.AutoSize = true;
            this.subst_lector_rbutton.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.subst_lector_rbutton.Location = new System.Drawing.Point(115, 34);
            this.subst_lector_rbutton.Name = "subst_lector_rbutton";
            this.subst_lector_rbutton.Size = new System.Drawing.Size(120, 21);
            this.subst_lector_rbutton.TabIndex = 3;
            this.subst_lector_rbutton.Text = "Substitute lector";
            this.subst_lector_rbutton.UseVisualStyleBackColor = true;
            this.subst_lector_rbutton.CheckedChanged += new System.EventHandler(this.subst_lector_rbutton_CheckedChanged);
            // 
            // theme_lbl
            // 
            this.theme_lbl.AutoSize = true;
            this.theme_lbl.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.theme_lbl.Location = new System.Drawing.Point(363, 38);
            this.theme_lbl.Name = "theme_lbl";
            this.theme_lbl.Size = new System.Drawing.Size(54, 17);
            this.theme_lbl.TabIndex = 4;
            this.theme_lbl.Text = "Theme";
            // 
            // theme_name_lbl
            // 
            this.theme_name_lbl.AutoSize = true;
            this.theme_name_lbl.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.theme_name_lbl.Location = new System.Drawing.Point(366, 69);
            this.theme_name_lbl.Name = "theme_name_lbl";
            this.theme_name_lbl.Size = new System.Drawing.Size(0, 17);
            this.theme_name_lbl.TabIndex = 5;
            // 
            // theme_name_textbox
            // 
            this.theme_name_textbox.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.theme_name_textbox.Location = new System.Drawing.Point(366, 61);
            this.theme_name_textbox.Name = "theme_name_textbox";
            this.theme_name_textbox.Size = new System.Drawing.Size(238, 25);
            this.theme_name_textbox.TabIndex = 6;
            this.theme_name_textbox.Visible = false;
            // 
            // change_btn
            // 
            this.change_btn.AutoSize = true;
            this.change_btn.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(2)))), ((int)(((byte)(166)))), ((int)(((byte)(243)))));
            this.change_btn.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.change_btn.Location = new System.Drawing.Point(610, 61);
            this.change_btn.Name = "change_btn";
            this.change_btn.Size = new System.Drawing.Size(75, 27);
            this.change_btn.TabIndex = 8;
            this.change_btn.Text = "Change";
            this.change_btn.UseVisualStyleBackColor = false;
            this.change_btn.Visible = false;
            this.change_btn.Click += new System.EventHandler(this.change_btn_Click);
            // 
            // cancel_btn
            // 
            this.cancel_btn.AutoSize = true;
            this.cancel_btn.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(2)))), ((int)(((byte)(166)))), ((int)(((byte)(243)))));
            this.cancel_btn.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.cancel_btn.Location = new System.Drawing.Point(691, 61);
            this.cancel_btn.Name = "cancel_btn";
            this.cancel_btn.Size = new System.Drawing.Size(75, 27);
            this.cancel_btn.TabIndex = 9;
            this.cancel_btn.Text = "Cancel";
            this.cancel_btn.UseVisualStyleBackColor = false;
            this.cancel_btn.Visible = false;
            this.cancel_btn.Click += new System.EventHandler(this.cancel_btn_Click);
            // 
            // header_gbox
            // 
            this.header_gbox.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(227)))), ((int)(((byte)(246)))), ((int)(((byte)(255)))));
            this.header_gbox.Controls.Add(this.check_all_rbutton);
            this.header_gbox.Controls.Add(this.pictureBox1);
            this.header_gbox.Controls.Add(this.crystal_count_lbl);
            this.header_gbox.Controls.Add(this.class_work_lbl);
            this.header_gbox.Controls.Add(this.test_work_lbl);
            this.header_gbox.Controls.Add(this.student_check_lbl);
            this.header_gbox.Controls.Add(this.appearance_lbl);
            this.header_gbox.Controls.Add(this.name_surname_lbl);
            this.header_gbox.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.header_gbox.Location = new System.Drawing.Point(16, 93);
            this.header_gbox.Name = "header_gbox";
            this.header_gbox.Size = new System.Drawing.Size(874, 78);
            this.header_gbox.TabIndex = 10;
            this.header_gbox.TabStop = false;
            // 
            // check_all_rbutton
            // 
            this.check_all_rbutton.AutoSize = true;
            this.check_all_rbutton.Enabled = false;
            this.check_all_rbutton.Location = new System.Drawing.Point(447, 49);
            this.check_all_rbutton.Name = "check_all_rbutton";
            this.check_all_rbutton.Size = new System.Drawing.Size(14, 13);
            this.check_all_rbutton.TabIndex = 7;
            this.check_all_rbutton.TabStop = true;
            this.check_all_rbutton.UseVisualStyleBackColor = true;
            this.check_all_rbutton.CheckedChanged += new System.EventHandler(this.check_all_rbutton_CheckedChanged);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::students_sheet.Properties.Resources.act_cryst_btn;
            this.pictureBox1.Location = new System.Drawing.Point(789, 28);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(18, 18);
            this.pictureBox1.TabIndex = 6;
            this.pictureBox1.TabStop = false;
            this.pictureBox1.Tag = "";
            // 
            // crystal_count_lbl
            // 
            this.crystal_count_lbl.AutoSize = true;
            this.crystal_count_lbl.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.crystal_count_lbl.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(2)))), ((int)(((byte)(166)))), ((int)(((byte)(243)))));
            this.crystal_count_lbl.Location = new System.Drawing.Point(766, 27);
            this.crystal_count_lbl.Name = "crystal_count_lbl";
            this.crystal_count_lbl.Size = new System.Drawing.Size(17, 19);
            this.crystal_count_lbl.TabIndex = 5;
            this.crystal_count_lbl.Text = "5";
            // 
            // class_work_lbl
            // 
            this.class_work_lbl.AutoSize = true;
            this.class_work_lbl.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(2)))), ((int)(((byte)(166)))), ((int)(((byte)(243)))));
            this.class_work_lbl.Location = new System.Drawing.Point(649, 27);
            this.class_work_lbl.Name = "class_work_lbl";
            this.class_work_lbl.Size = new System.Drawing.Size(83, 19);
            this.class_work_lbl.TabIndex = 4;
            this.class_work_lbl.Text = "Class work";
            // 
            // test_work_lbl
            // 
            this.test_work_lbl.AutoSize = true;
            this.test_work_lbl.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(2)))), ((int)(((byte)(166)))), ((int)(((byte)(243)))));
            this.test_work_lbl.Location = new System.Drawing.Point(546, 27);
            this.test_work_lbl.Name = "test_work_lbl";
            this.test_work_lbl.Size = new System.Drawing.Size(75, 19);
            this.test_work_lbl.TabIndex = 3;
            this.test_work_lbl.Text = "Test work";
            // 
            // student_check_lbl
            // 
            this.student_check_lbl.AutoSize = true;
            this.student_check_lbl.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(2)))), ((int)(((byte)(166)))), ((int)(((byte)(243)))));
            this.student_check_lbl.Location = new System.Drawing.Point(397, 27);
            this.student_check_lbl.Name = "student_check_lbl";
            this.student_check_lbl.Size = new System.Drawing.Size(123, 19);
            this.student_check_lbl.TabIndex = 2;
            this.student_check_lbl.Text = "Students cheking";
            // 
            // appearance_lbl
            // 
            this.appearance_lbl.AutoSize = true;
            this.appearance_lbl.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(2)))), ((int)(((byte)(166)))), ((int)(((byte)(243)))));
            this.appearance_lbl.Location = new System.Drawing.Point(250, 27);
            this.appearance_lbl.Name = "appearance_lbl";
            this.appearance_lbl.Size = new System.Drawing.Size(120, 19);
            this.appearance_lbl.TabIndex = 1;
            this.appearance_lbl.Text = "Last appearance";
            // 
            // name_surname_lbl
            // 
            this.name_surname_lbl.AutoSize = true;
            this.name_surname_lbl.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(2)))), ((int)(((byte)(166)))), ((int)(((byte)(243)))));
            this.name_surname_lbl.Location = new System.Drawing.Point(42, 27);
            this.name_surname_lbl.Name = "name_surname_lbl";
            this.name_surname_lbl.Size = new System.Drawing.Size(165, 19);
            this.name_surname_lbl.TabIndex = 0;
            this.name_surname_lbl.Text = "Student name, surname";
            // 
            // student_1_gbox
            // 
            this.student_1_gbox.Controls.Add(this.comboBox2);
            this.student_1_gbox.Controls.Add(this.button13);
            this.student_1_gbox.Controls.Add(this.button3);
            this.student_1_gbox.Controls.Add(this.button2);
            this.student_1_gbox.Controls.Add(this.button1);
            this.student_1_gbox.Controls.Add(this.comboBox1);
            this.student_1_gbox.Controls.Add(this.radioButton3);
            this.student_1_gbox.Controls.Add(this.radioButton2);
            this.student_1_gbox.Controls.Add(this.radioButton1);
            this.student_1_gbox.Controls.Add(this.label3);
            this.student_1_gbox.Controls.Add(this.label2);
            this.student_1_gbox.Controls.Add(this.pictureBox2);
            this.student_1_gbox.Controls.Add(this.label1);
            this.student_1_gbox.Enabled = false;
            this.student_1_gbox.Location = new System.Drawing.Point(16, 177);
            this.student_1_gbox.Name = "student_1_gbox";
            this.student_1_gbox.Size = new System.Drawing.Size(874, 84);
            this.student_1_gbox.TabIndex = 11;
            this.student_1_gbox.TabStop = false;
            // 
            // button13
            // 
            this.button13.BackgroundImage = global::students_sheet.Properties.Resources.close_btn;
            this.button13.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.button13.Enabled = false;
            this.button13.Location = new System.Drawing.Point(840, 36);
            this.button13.Name = "button13";
            this.button13.Size = new System.Drawing.Size(22, 22);
            this.button13.TabIndex = 16;
            this.button13.UseVisualStyleBackColor = true;
            this.button13.Click += new System.EventHandler(this.button13_Click);
            // 
            // button3
            // 
            this.button3.BackgroundImage = global::students_sheet.Properties.Resources.pas_cryst_btn;
            this.button3.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.button3.Enabled = false;
            this.button3.Location = new System.Drawing.Point(812, 36);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(22, 22);
            this.button3.TabIndex = 15;
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // button2
            // 
            this.button2.BackgroundImage = global::students_sheet.Properties.Resources.pas_cryst_btn;
            this.button2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.button2.Enabled = false;
            this.button2.Location = new System.Drawing.Point(784, 36);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(22, 22);
            this.button2.TabIndex = 14;
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // button1
            // 
            this.button1.BackgroundImage = global::students_sheet.Properties.Resources.pas_cryst_btn;
            this.button1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.button1.Enabled = false;
            this.button1.Location = new System.Drawing.Point(756, 36);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(22, 22);
            this.button1.TabIndex = 13;
            this.button1.Tag = "";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // comboBox1
            // 
            this.comboBox1.Enabled = false;
            this.comboBox1.FormattingEnabled = true;
            this.comboBox1.Location = new System.Drawing.Point(550, 36);
            this.comboBox1.Name = "comboBox1";
            this.comboBox1.Size = new System.Drawing.Size(71, 21);
            this.comboBox1.TabIndex = 11;
            // 
            // radioButton3
            // 
            this.radioButton3.AutoSize = true;
            this.radioButton3.Location = new System.Drawing.Point(481, 36);
            this.radioButton3.Name = "radioButton3";
            this.radioButton3.Size = new System.Drawing.Size(14, 13);
            this.radioButton3.TabIndex = 10;
            this.radioButton3.TabStop = true;
            this.radioButton3.UseVisualStyleBackColor = true;
            this.radioButton3.CheckedChanged += new System.EventHandler(this.radioButton3_CheckedChanged);
            // 
            // radioButton2
            // 
            this.radioButton2.AutoSize = true;
            this.radioButton2.Location = new System.Drawing.Point(447, 36);
            this.radioButton2.Name = "radioButton2";
            this.radioButton2.Size = new System.Drawing.Size(14, 13);
            this.radioButton2.TabIndex = 9;
            this.radioButton2.TabStop = true;
            this.radioButton2.UseVisualStyleBackColor = true;
            this.radioButton2.CheckedChanged += new System.EventHandler(this.radioButton2_CheckedChanged);
            // 
            // radioButton1
            // 
            this.radioButton1.AutoSize = true;
            this.radioButton1.Location = new System.Drawing.Point(413, 36);
            this.radioButton1.Name = "radioButton1";
            this.radioButton1.Size = new System.Drawing.Size(14, 13);
            this.radioButton1.TabIndex = 8;
            this.radioButton1.TabStop = true;
            this.radioButton1.UseVisualStyleBackColor = true;
            this.radioButton1.CheckedChanged += new System.EventHandler(this.radioButton1_CheckedChanged);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label3.Location = new System.Drawing.Point(272, 36);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(72, 17);
            this.label3.TabIndex = 3;
            this.label3.Text = "14.02.2022";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label2.Location = new System.Drawing.Point(85, 36);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(122, 17);
            this.label2.TabIndex = 2;
            this.label2.Text = "Filankes Filankesov";
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = global::students_sheet.Properties.Resources.st_pict;
            this.pictureBox2.Location = new System.Drawing.Point(29, 19);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(50, 50);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox2.TabIndex = 1;
            this.pictureBox2.TabStop = false;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label1.Location = new System.Drawing.Point(8, 36);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(15, 17);
            this.label1.TabIndex = 0;
            this.label1.Text = "1";
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.button14);
            this.groupBox1.Controls.Add(this.button4);
            this.groupBox1.Controls.Add(this.button5);
            this.groupBox1.Controls.Add(this.button6);
            this.groupBox1.Controls.Add(this.comboBox3);
            this.groupBox1.Controls.Add(this.comboBox4);
            this.groupBox1.Controls.Add(this.radioButton4);
            this.groupBox1.Controls.Add(this.radioButton5);
            this.groupBox1.Controls.Add(this.radioButton6);
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Controls.Add(this.label5);
            this.groupBox1.Controls.Add(this.pictureBox3);
            this.groupBox1.Controls.Add(this.label6);
            this.groupBox1.Enabled = false;
            this.groupBox1.Location = new System.Drawing.Point(16, 267);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(874, 84);
            this.groupBox1.TabIndex = 12;
            this.groupBox1.TabStop = false;
            // 
            // button14
            // 
            this.button14.BackgroundImage = global::students_sheet.Properties.Resources.close_btn;
            this.button14.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.button14.Enabled = false;
            this.button14.Location = new System.Drawing.Point(840, 36);
            this.button14.Name = "button14";
            this.button14.Size = new System.Drawing.Size(22, 22);
            this.button14.TabIndex = 17;
            this.button14.UseVisualStyleBackColor = true;
            this.button14.Click += new System.EventHandler(this.button14_Click);
            // 
            // button4
            // 
            this.button4.BackgroundImage = global::students_sheet.Properties.Resources.pas_cryst_btn;
            this.button4.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.button4.Enabled = false;
            this.button4.Location = new System.Drawing.Point(812, 36);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(22, 22);
            this.button4.TabIndex = 15;
            this.button4.UseVisualStyleBackColor = true;
            this.button4.Click += new System.EventHandler(this.button4_Click);
            // 
            // button5
            // 
            this.button5.BackgroundImage = global::students_sheet.Properties.Resources.pas_cryst_btn;
            this.button5.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.button5.Enabled = false;
            this.button5.Location = new System.Drawing.Point(784, 36);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(22, 22);
            this.button5.TabIndex = 14;
            this.button5.UseVisualStyleBackColor = true;
            this.button5.Click += new System.EventHandler(this.button5_Click);
            // 
            // button6
            // 
            this.button6.BackgroundImage = global::students_sheet.Properties.Resources.pas_cryst_btn;
            this.button6.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.button6.Enabled = false;
            this.button6.Location = new System.Drawing.Point(756, 36);
            this.button6.Name = "button6";
            this.button6.Size = new System.Drawing.Size(22, 22);
            this.button6.TabIndex = 13;
            this.button6.UseVisualStyleBackColor = true;
            this.button6.Click += new System.EventHandler(this.button6_Click);
            // 
            // comboBox3
            // 
            this.comboBox3.Enabled = false;
            this.comboBox3.FormattingEnabled = true;
            this.comboBox3.Location = new System.Drawing.Point(653, 36);
            this.comboBox3.Name = "comboBox3";
            this.comboBox3.Size = new System.Drawing.Size(71, 21);
            this.comboBox3.TabIndex = 12;
            // 
            // comboBox4
            // 
            this.comboBox4.Enabled = false;
            this.comboBox4.FormattingEnabled = true;
            this.comboBox4.Location = new System.Drawing.Point(550, 36);
            this.comboBox4.Name = "comboBox4";
            this.comboBox4.Size = new System.Drawing.Size(71, 21);
            this.comboBox4.TabIndex = 11;
            // 
            // radioButton4
            // 
            this.radioButton4.AutoSize = true;
            this.radioButton4.Location = new System.Drawing.Point(481, 36);
            this.radioButton4.Name = "radioButton4";
            this.radioButton4.Size = new System.Drawing.Size(14, 13);
            this.radioButton4.TabIndex = 10;
            this.radioButton4.TabStop = true;
            this.radioButton4.UseVisualStyleBackColor = true;
            this.radioButton4.CheckedChanged += new System.EventHandler(this.radioButton4_CheckedChanged);
            // 
            // radioButton5
            // 
            this.radioButton5.AutoSize = true;
            this.radioButton5.Location = new System.Drawing.Point(447, 36);
            this.radioButton5.Name = "radioButton5";
            this.radioButton5.Size = new System.Drawing.Size(14, 13);
            this.radioButton5.TabIndex = 9;
            this.radioButton5.TabStop = true;
            this.radioButton5.UseVisualStyleBackColor = true;
            this.radioButton5.CheckedChanged += new System.EventHandler(this.radioButton5_CheckedChanged);
            // 
            // radioButton6
            // 
            this.radioButton6.AutoSize = true;
            this.radioButton6.Location = new System.Drawing.Point(413, 36);
            this.radioButton6.Name = "radioButton6";
            this.radioButton6.Size = new System.Drawing.Size(14, 13);
            this.radioButton6.TabIndex = 8;
            this.radioButton6.TabStop = true;
            this.radioButton6.UseVisualStyleBackColor = true;
            this.radioButton6.CheckedChanged += new System.EventHandler(this.radioButton6_CheckedChanged);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label4.Location = new System.Drawing.Point(272, 36);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(72, 17);
            this.label4.TabIndex = 3;
            this.label4.Text = "14.02.2022";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label5.Location = new System.Drawing.Point(85, 36);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(122, 17);
            this.label5.TabIndex = 2;
            this.label5.Text = "Filankes Filankesov";
            // 
            // pictureBox3
            // 
            this.pictureBox3.Image = global::students_sheet.Properties.Resources.st_pict;
            this.pictureBox3.Location = new System.Drawing.Point(29, 19);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(50, 50);
            this.pictureBox3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox3.TabIndex = 1;
            this.pictureBox3.TabStop = false;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label6.Location = new System.Drawing.Point(8, 36);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(15, 17);
            this.label6.TabIndex = 0;
            this.label6.Text = "2";
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.button15);
            this.groupBox2.Controls.Add(this.button7);
            this.groupBox2.Controls.Add(this.button8);
            this.groupBox2.Controls.Add(this.button9);
            this.groupBox2.Controls.Add(this.comboBox5);
            this.groupBox2.Controls.Add(this.comboBox6);
            this.groupBox2.Controls.Add(this.radioButton7);
            this.groupBox2.Controls.Add(this.radioButton8);
            this.groupBox2.Controls.Add(this.radioButton9);
            this.groupBox2.Controls.Add(this.label7);
            this.groupBox2.Controls.Add(this.label8);
            this.groupBox2.Controls.Add(this.pictureBox4);
            this.groupBox2.Controls.Add(this.label9);
            this.groupBox2.Enabled = false;
            this.groupBox2.Location = new System.Drawing.Point(16, 357);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(874, 84);
            this.groupBox2.TabIndex = 13;
            this.groupBox2.TabStop = false;
            // 
            // button15
            // 
            this.button15.BackgroundImage = global::students_sheet.Properties.Resources.close_btn;
            this.button15.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.button15.Enabled = false;
            this.button15.Location = new System.Drawing.Point(840, 36);
            this.button15.Name = "button15";
            this.button15.Size = new System.Drawing.Size(22, 22);
            this.button15.TabIndex = 17;
            this.button15.UseVisualStyleBackColor = true;
            this.button15.Click += new System.EventHandler(this.button15_Click);
            // 
            // button7
            // 
            this.button7.BackgroundImage = global::students_sheet.Properties.Resources.pas_cryst_btn;
            this.button7.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.button7.Enabled = false;
            this.button7.Location = new System.Drawing.Point(812, 36);
            this.button7.Name = "button7";
            this.button7.Size = new System.Drawing.Size(22, 22);
            this.button7.TabIndex = 15;
            this.button7.UseVisualStyleBackColor = true;
            this.button7.Click += new System.EventHandler(this.button7_Click);
            // 
            // button8
            // 
            this.button8.BackgroundImage = global::students_sheet.Properties.Resources.pas_cryst_btn;
            this.button8.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.button8.Enabled = false;
            this.button8.Location = new System.Drawing.Point(784, 36);
            this.button8.Name = "button8";
            this.button8.Size = new System.Drawing.Size(22, 22);
            this.button8.TabIndex = 14;
            this.button8.UseVisualStyleBackColor = true;
            this.button8.Click += new System.EventHandler(this.button8_Click);
            // 
            // button9
            // 
            this.button9.BackgroundImage = global::students_sheet.Properties.Resources.pas_cryst_btn;
            this.button9.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.button9.Enabled = false;
            this.button9.Location = new System.Drawing.Point(756, 36);
            this.button9.Name = "button9";
            this.button9.Size = new System.Drawing.Size(22, 22);
            this.button9.TabIndex = 13;
            this.button9.UseVisualStyleBackColor = true;
            this.button9.Click += new System.EventHandler(this.button9_Click);
            // 
            // comboBox5
            // 
            this.comboBox5.Enabled = false;
            this.comboBox5.FormattingEnabled = true;
            this.comboBox5.Location = new System.Drawing.Point(653, 36);
            this.comboBox5.Name = "comboBox5";
            this.comboBox5.Size = new System.Drawing.Size(71, 21);
            this.comboBox5.TabIndex = 12;
            // 
            // comboBox6
            // 
            this.comboBox6.Enabled = false;
            this.comboBox6.FormattingEnabled = true;
            this.comboBox6.Location = new System.Drawing.Point(550, 36);
            this.comboBox6.Name = "comboBox6";
            this.comboBox6.Size = new System.Drawing.Size(71, 21);
            this.comboBox6.TabIndex = 11;
            // 
            // radioButton7
            // 
            this.radioButton7.AutoSize = true;
            this.radioButton7.Location = new System.Drawing.Point(481, 36);
            this.radioButton7.Name = "radioButton7";
            this.radioButton7.Size = new System.Drawing.Size(14, 13);
            this.radioButton7.TabIndex = 10;
            this.radioButton7.TabStop = true;
            this.radioButton7.UseVisualStyleBackColor = true;
            this.radioButton7.CheckedChanged += new System.EventHandler(this.radioButton7_CheckedChanged);
            // 
            // radioButton8
            // 
            this.radioButton8.AutoSize = true;
            this.radioButton8.Location = new System.Drawing.Point(447, 36);
            this.radioButton8.Name = "radioButton8";
            this.radioButton8.Size = new System.Drawing.Size(14, 13);
            this.radioButton8.TabIndex = 9;
            this.radioButton8.TabStop = true;
            this.radioButton8.UseVisualStyleBackColor = true;
            this.radioButton8.CheckedChanged += new System.EventHandler(this.radioButton8_CheckedChanged);
            // 
            // radioButton9
            // 
            this.radioButton9.AutoSize = true;
            this.radioButton9.Location = new System.Drawing.Point(413, 36);
            this.radioButton9.Name = "radioButton9";
            this.radioButton9.Size = new System.Drawing.Size(14, 13);
            this.radioButton9.TabIndex = 8;
            this.radioButton9.TabStop = true;
            this.radioButton9.UseVisualStyleBackColor = true;
            this.radioButton9.CheckedChanged += new System.EventHandler(this.radioButton9_CheckedChanged);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label7.Location = new System.Drawing.Point(272, 36);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(72, 17);
            this.label7.TabIndex = 3;
            this.label7.Text = "14.02.2022";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label8.Location = new System.Drawing.Point(85, 36);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(122, 17);
            this.label8.TabIndex = 2;
            this.label8.Text = "Filankes Filankesov";
            // 
            // pictureBox4
            // 
            this.pictureBox4.Image = global::students_sheet.Properties.Resources.st_pict;
            this.pictureBox4.Location = new System.Drawing.Point(29, 19);
            this.pictureBox4.Name = "pictureBox4";
            this.pictureBox4.Size = new System.Drawing.Size(50, 50);
            this.pictureBox4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox4.TabIndex = 1;
            this.pictureBox4.TabStop = false;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label9.Location = new System.Drawing.Point(8, 36);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(15, 17);
            this.label9.TabIndex = 0;
            this.label9.Text = "3";
            // 
            // theme_name_btn
            // 
            this.theme_name_btn.BackgroundImage = global::students_sheet.Properties.Resources.pen_btn;
            this.theme_name_btn.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.theme_name_btn.Enabled = false;
            this.theme_name_btn.FlatAppearance.BorderColor = System.Drawing.Color.White;
            this.theme_name_btn.FlatAppearance.BorderSize = 0;
            this.theme_name_btn.Location = new System.Drawing.Point(338, 56);
            this.theme_name_btn.Name = "theme_name_btn";
            this.theme_name_btn.Size = new System.Drawing.Size(22, 22);
            this.theme_name_btn.TabIndex = 7;
            this.theme_name_btn.UseVisualStyleBackColor = true;
            this.theme_name_btn.Click += new System.EventHandler(this.theme_name_btn_Click);
            // 
            // comboBox2
            // 
            this.comboBox2.Enabled = false;
            this.comboBox2.FormattingEnabled = true;
            this.comboBox2.Location = new System.Drawing.Point(653, 36);
            this.comboBox2.Name = "comboBox2";
            this.comboBox2.Size = new System.Drawing.Size(71, 21);
            this.comboBox2.TabIndex = 17;
            // 
            // students_notes
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(905, 461);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.student_1_gbox);
            this.Controls.Add(this.header_gbox);
            this.Controls.Add(this.cancel_btn);
            this.Controls.Add(this.change_btn);
            this.Controls.Add(this.theme_name_btn);
            this.Controls.Add(this.theme_name_textbox);
            this.Controls.Add(this.theme_name_lbl);
            this.Controls.Add(this.theme_lbl);
            this.Controls.Add(this.subst_lector_rbutton);
            this.Controls.Add(this.main_lector_rbutton);
            this.Controls.Add(this.subject_lbl);
            this.Controls.Add(this.students_group_lbl);
            this.Name = "students_notes";
            this.Load += new System.EventHandler(this.students_notes_Load);
            this.header_gbox.ResumeLayout(false);
            this.header_gbox.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.student_1_gbox.ResumeLayout(false);
            this.student_1_gbox.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label students_group_lbl;
        private System.Windows.Forms.Label subject_lbl;
        private System.Windows.Forms.RadioButton main_lector_rbutton;
        private System.Windows.Forms.RadioButton subst_lector_rbutton;
        private System.Windows.Forms.Label theme_lbl;
        private System.Windows.Forms.Label theme_name_lbl;
        private System.Windows.Forms.TextBox theme_name_textbox;
        private System.Windows.Forms.Button theme_name_btn;
        private System.Windows.Forms.Button change_btn;
        private System.Windows.Forms.Button cancel_btn;
        private System.Windows.Forms.GroupBox header_gbox;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label crystal_count_lbl;
        private System.Windows.Forms.Label class_work_lbl;
        private System.Windows.Forms.Label test_work_lbl;
        private System.Windows.Forms.Label student_check_lbl;
        private System.Windows.Forms.Label appearance_lbl;
        private System.Windows.Forms.Label name_surname_lbl;
        private System.Windows.Forms.RadioButton check_all_rbutton;
        private System.Windows.Forms.GroupBox student_1_gbox;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.ComboBox comboBox1;
        private System.Windows.Forms.RadioButton radioButton3;
        private System.Windows.Forms.RadioButton radioButton2;
        private System.Windows.Forms.RadioButton radioButton1;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.Button button6;
        private System.Windows.Forms.ComboBox comboBox3;
        private System.Windows.Forms.ComboBox comboBox4;
        private System.Windows.Forms.RadioButton radioButton4;
        private System.Windows.Forms.RadioButton radioButton5;
        private System.Windows.Forms.RadioButton radioButton6;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.PictureBox pictureBox3;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Button button7;
        private System.Windows.Forms.Button button8;
        private System.Windows.Forms.Button button9;
        private System.Windows.Forms.ComboBox comboBox5;
        private System.Windows.Forms.ComboBox comboBox6;
        private System.Windows.Forms.RadioButton radioButton7;
        private System.Windows.Forms.RadioButton radioButton8;
        private System.Windows.Forms.RadioButton radioButton9;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.PictureBox pictureBox4;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Button button13;
        private System.Windows.Forms.Button button14;
        private System.Windows.Forms.Button button15;
        private System.Windows.Forms.ComboBox comboBox2;
    }
}

