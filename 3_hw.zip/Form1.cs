﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace students_sheet
{
    public partial class students_notes : Form
    {
        public students_notes()
        {
            InitializeComponent();
        }

        private void group_bx_1_radiobuttons()
        {
            comboBox1.Enabled = true;
            comboBox2.Enabled = true;
            button1.Enabled = true;
            button2.Enabled = true;
            button3.Enabled = true;
            button13.Enabled = true;
        }

        private void group_bx_2_radiobuttons()
        {
            comboBox3.Enabled = true;
            comboBox4.Enabled = true;
            button4.Enabled = true;
            button5.Enabled = true;
            button6.Enabled = true;
            button14.Enabled = true;
        }

        private void group_bx_3_radiobuttons()
        {
            comboBox5.Enabled = true;
            comboBox6.Enabled = true;
            button7.Enabled = true;
            button8.Enabled = true;
            button9.Enabled = true;
            button15.Enabled = true;
        }

        private void group_bx_1_buttons()
        {
            button1.BackgroundImage = global::students_sheet.Properties.Resources.act_cryst_btn;
            button1.Enabled = false;

            radioButton1.Enabled = false;
            radioButton2.Enabled = false;
            radioButton3.Enabled = false;
        }

        private void group_bx_2_buttons()
        {
            button6.BackgroundImage = global::students_sheet.Properties.Resources.act_cryst_btn;
            button6.Enabled = false;

            radioButton4.Enabled = false;
            radioButton5.Enabled = false;
            radioButton6.Enabled = false;
        }

        private void group_bx_3_buttons()
        {
            button9.BackgroundImage = global::students_sheet.Properties.Resources.act_cryst_btn;
            button9.Enabled = false;

            radioButton7.Enabled = false;
            radioButton8.Enabled = false;
            radioButton9.Enabled = false;
        }

        private void main_lector_rbutton_CheckedChanged(object sender, EventArgs e)
        {
            if (main_lector_rbutton.Checked)
            {
                theme_name_btn.Enabled = true;
                subst_lector_rbutton.Checked = false;
            }
        }

        private void subst_lector_rbutton_CheckedChanged(object sender, EventArgs e)
        {
            if (subst_lector_rbutton.Checked)
            {
                theme_name_btn.Enabled = true;
                main_lector_rbutton.Checked = false;
            }
        }

        private void theme_name_btn_Click(object sender, EventArgs e)
        {
            theme_name_textbox.Visible = true;
            change_btn.Visible = true;
            cancel_btn.Visible = true;
            theme_name_lbl.Visible = false;
        }

        private void change_btn_Click(object sender, EventArgs e)
        {
            theme_name_lbl.Text = theme_name_textbox.Text;
            if (!String.IsNullOrEmpty(theme_name_lbl.Text))
            {
                theme_name_textbox.Visible = false;
                change_btn.Visible = false;
                cancel_btn.Visible = false;
                theme_name_lbl.Visible = true;
                check_all_rbutton.Enabled = true;
                student_1_gbox.Enabled = true;
                groupBox1.Enabled = true;
                groupBox2.Enabled = true;
            }
        }

        private void cancel_btn_Click(object sender, EventArgs e)
        {
            theme_name_textbox.Visible = false;
            change_btn.Visible = false;
            cancel_btn.Visible = false;
            theme_name_lbl.Visible = true;
            theme_name_textbox.Text = "";
        }

        private void check_all_rbutton_CheckedChanged(object sender, EventArgs e)
        {
            if(check_all_rbutton.Checked)
            {
                radioButton1.Checked = true;
                radioButton6.Checked = true;
                radioButton9.Checked = true;
            }
        }

        private void radioButton1_CheckedChanged(object sender, EventArgs e)
        {
            if (radioButton1.Checked)
                group_bx_1_radiobuttons();

            check_all_rbutton.Checked = false;
        }

        private void radioButton2_CheckedChanged(object sender, EventArgs e)
        {
            if (radioButton2.Checked)
                group_bx_1_radiobuttons();

            check_all_rbutton.Checked = false;
        }

        private void radioButton3_CheckedChanged(object sender, EventArgs e)
        {
            if (radioButton3.Checked)
            {
                comboBox1.Enabled = false;
                comboBox2.Enabled = false;
                button1.Enabled = false;
                button2.Enabled = false;
                button3.Enabled = false;
                button13.Enabled = false;
            }

            check_all_rbutton.Checked = false;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (Convert.ToByte(crystal_count_lbl.Text) > 0)
            {
                group_bx_1_buttons();
                crystal_count_lbl.Text = (Convert.ToByte(crystal_count_lbl.Text) - 1).ToString();
            }            
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (button1.Enabled == true && Convert.ToByte(crystal_count_lbl.Text) > 1)
            {
                group_bx_1_buttons();
                crystal_count_lbl.Text = (Convert.ToByte(crystal_count_lbl.Text) - 2).ToString();

                button2.BackgroundImage = global::students_sheet.Properties.Resources.act_cryst_btn;
                button2.Enabled = false;
            }
            else if (button1.Enabled == false && Convert.ToByte(crystal_count_lbl.Text) == 1)
            {
                crystal_count_lbl.Text = (Convert.ToByte(crystal_count_lbl.Text) - 1).ToString();

                button2.BackgroundImage = global::students_sheet.Properties.Resources.act_cryst_btn;
                button2.Enabled = false;

                radioButton1.Enabled = false;
                radioButton2.Enabled = false;
                radioButton3.Enabled = false;
            }                       
        }

        private void button3_Click(object sender, EventArgs e)
        {
            if (button1.Enabled == true && button2.Enabled == true && Convert.ToByte(crystal_count_lbl.Text) > 2)
            {
                group_bx_1_buttons();
                crystal_count_lbl.Text = (Convert.ToByte(crystal_count_lbl.Text) - 3).ToString();
                
                button2.Enabled = false;
                button3.Enabled = false;

                button2.BackgroundImage = global::students_sheet.Properties.Resources.act_cryst_btn;
                button3.BackgroundImage = global::students_sheet.Properties.Resources.act_cryst_btn;   
            }
            else if (button1.Enabled == false && button2.Enabled == true && Convert.ToByte(crystal_count_lbl.Text) == 2)
            {
                crystal_count_lbl.Text = (Convert.ToByte(crystal_count_lbl.Text) - 2).ToString();

                button2.Enabled = false;
                button3.Enabled = false;

                button2.BackgroundImage = global::students_sheet.Properties.Resources.act_cryst_btn;
                button3.BackgroundImage = global::students_sheet.Properties.Resources.act_cryst_btn;

                radioButton1.Enabled = false;
                radioButton2.Enabled = false;
                radioButton3.Enabled = false;
            }
            else if (button2.Enabled == false && Convert.ToByte(crystal_count_lbl.Text) > 0)
            {
                crystal_count_lbl.Text = (Convert.ToByte(crystal_count_lbl.Text) - 1).ToString();

                button3.Enabled = false;
                button3.BackgroundImage = global::students_sheet.Properties.Resources.act_cryst_btn;

                radioButton1.Enabled = false;
                radioButton2.Enabled = false;
                radioButton3.Enabled = false;
            }
        }

        private void button13_Click(object sender, EventArgs e)
        {
            if (button1.Enabled == false && button2.Enabled == false && button3.Enabled == false)
                crystal_count_lbl.Text = (Convert.ToByte(crystal_count_lbl.Text) + 3).ToString();
            else if (button1.Enabled == false && button2.Enabled == false)
                crystal_count_lbl.Text = (Convert.ToByte(crystal_count_lbl.Text) + 2).ToString();
            else if (button1.Enabled == false)
                crystal_count_lbl.Text = (Convert.ToByte(crystal_count_lbl.Text) + 1).ToString();

            button1.Enabled = true;
            button2.Enabled = true;
            button3.Enabled = true;

            button1.BackgroundImage = global::students_sheet.Properties.Resources.pas_cryst_btn;
            button2.BackgroundImage = global::students_sheet.Properties.Resources.pas_cryst_btn;
            button3.BackgroundImage = global::students_sheet.Properties.Resources.pas_cryst_btn;

            radioButton1.Enabled = true;
            radioButton2.Enabled = true;
            radioButton3.Enabled = true;
        }

        private void radioButton6_CheckedChanged(object sender, EventArgs e)
        {
            if (radioButton6.Checked)
                group_bx_2_radiobuttons();

            check_all_rbutton.Checked = false;
        }

        private void radioButton5_CheckedChanged(object sender, EventArgs e)
        {
            if (radioButton5.Checked)
                group_bx_2_radiobuttons();

            check_all_rbutton.Checked = false;
        }

        private void radioButton4_CheckedChanged(object sender, EventArgs e)
        {
            if (radioButton4.Checked)
            {
                comboBox3.Enabled = false;
                comboBox4.Enabled = false;
                button4.Enabled = false;
                button5.Enabled = false;
                button6.Enabled = false;
                button14.Enabled = false;
            }

            check_all_rbutton.Checked = false;
        }

        private void button6_Click(object sender, EventArgs e)
        {
            if (Convert.ToByte(crystal_count_lbl.Text) > 0)
            {
                group_bx_2_buttons();
                crystal_count_lbl.Text = (Convert.ToByte(crystal_count_lbl.Text) - 1).ToString();
            }
        }

        private void button5_Click(object sender, EventArgs e)
        {
            if (button6.Enabled == true && Convert.ToByte(crystal_count_lbl.Text) > 1)
            {
                group_bx_2_buttons();
                crystal_count_lbl.Text = (Convert.ToByte(crystal_count_lbl.Text) - 2).ToString();

                button5.BackgroundImage = global::students_sheet.Properties.Resources.act_cryst_btn;
                button5.Enabled = false;
            }
            else if (button6.Enabled == false && Convert.ToByte(crystal_count_lbl.Text) == 1)
            {
                crystal_count_lbl.Text = (Convert.ToByte(crystal_count_lbl.Text) - 1).ToString();

                button5.BackgroundImage = global::students_sheet.Properties.Resources.act_cryst_btn;
                button5.Enabled = false;

                radioButton4.Enabled = false;
                radioButton5.Enabled = false;
                radioButton6.Enabled = false;
            }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            if (button6.Enabled == true && button5.Enabled == true && Convert.ToByte(crystal_count_lbl.Text) > 2)
            {
                group_bx_2_buttons();
                crystal_count_lbl.Text = (Convert.ToByte(crystal_count_lbl.Text) - 3).ToString();

                button4.Enabled = false;
                button5.Enabled = false;

                button4.BackgroundImage = global::students_sheet.Properties.Resources.act_cryst_btn;
                button5.BackgroundImage = global::students_sheet.Properties.Resources.act_cryst_btn;
            }
            else if (button6.Enabled == false && button5.Enabled == true && Convert.ToByte(crystal_count_lbl.Text) == 2)
            {
                crystal_count_lbl.Text = (Convert.ToByte(crystal_count_lbl.Text) - 2).ToString();

                button4.Enabled = false;
                button5.Enabled = false;

                button4.BackgroundImage = global::students_sheet.Properties.Resources.act_cryst_btn;
                button5.BackgroundImage = global::students_sheet.Properties.Resources.act_cryst_btn;

                radioButton4.Enabled = false;
                radioButton5.Enabled = false;
                radioButton6.Enabled = false;
            }
            else if (button5.Enabled == false && Convert.ToByte(crystal_count_lbl.Text) > 0)
            {
                crystal_count_lbl.Text = (Convert.ToByte(crystal_count_lbl.Text) - 1).ToString();

                button4.Enabled = false;
                button4.BackgroundImage = global::students_sheet.Properties.Resources.act_cryst_btn;

                radioButton4.Enabled = false;
                radioButton5.Enabled = false;
                radioButton6.Enabled = false;
            }
        }

        private void button14_Click(object sender, EventArgs e)
        {
            if (button6.Enabled == false && button5.Enabled == false && button4.Enabled == false)
                crystal_count_lbl.Text = (Convert.ToByte(crystal_count_lbl.Text) + 3).ToString();
            else if (button6.Enabled == false && button5.Enabled == false)
                crystal_count_lbl.Text = (Convert.ToByte(crystal_count_lbl.Text) + 2).ToString();
            else if (button6.Enabled == false)
                crystal_count_lbl.Text = (Convert.ToByte(crystal_count_lbl.Text) + 1).ToString();

            button4.Enabled = true;
            button5.Enabled = true;
            button6.Enabled = true;

            button4.BackgroundImage = global::students_sheet.Properties.Resources.pas_cryst_btn;
            button5.BackgroundImage = global::students_sheet.Properties.Resources.pas_cryst_btn;
            button6.BackgroundImage = global::students_sheet.Properties.Resources.pas_cryst_btn;

            radioButton4.Enabled = true;
            radioButton5.Enabled = true;
            radioButton6.Enabled = true;
        }

        private void radioButton9_CheckedChanged(object sender, EventArgs e)
        {
            if (radioButton9.Checked)
                group_bx_3_radiobuttons();

            check_all_rbutton.Checked = false;
        }

        private void radioButton8_CheckedChanged(object sender, EventArgs e)
        {
            if (radioButton8.Checked)
                group_bx_3_radiobuttons();

            check_all_rbutton.Checked = false;
        }

        private void radioButton7_CheckedChanged(object sender, EventArgs e)
        {
            if (radioButton7.Checked)
            {
                comboBox5.Enabled = false;
                comboBox6.Enabled = false;
                button7.Enabled = false;
                button8.Enabled = false;
                button9.Enabled = false;
                button15.Enabled = false;
            }

            check_all_rbutton.Checked = false;
        }

        private void button9_Click(object sender, EventArgs e)
        {
            if (Convert.ToByte(crystal_count_lbl.Text) > 0)
            {
                group_bx_3_buttons();
                crystal_count_lbl.Text = (Convert.ToByte(crystal_count_lbl.Text) - 1).ToString();
            }
        }

        private void button8_Click(object sender, EventArgs e)
        {
            if (button9.Enabled == true && Convert.ToByte(crystal_count_lbl.Text) > 1)
            {
                group_bx_3_buttons();
                crystal_count_lbl.Text = (Convert.ToByte(crystal_count_lbl.Text) - 2).ToString();

                button8.BackgroundImage = global::students_sheet.Properties.Resources.act_cryst_btn;
                button8.Enabled = false;
            }
            else if (button9.Enabled == false && Convert.ToByte(crystal_count_lbl.Text) == 1)
            {
                crystal_count_lbl.Text = (Convert.ToByte(crystal_count_lbl.Text) - 1).ToString();

                button8.BackgroundImage = global::students_sheet.Properties.Resources.act_cryst_btn;
                button8.Enabled = false;

                radioButton7.Enabled = false;
                radioButton8.Enabled = false;
                radioButton9.Enabled = false;
            }
        }

        private void button7_Click(object sender, EventArgs e)
        {
            if (button9.Enabled == true && button8.Enabled == true && Convert.ToByte(crystal_count_lbl.Text) > 2)
            {
                group_bx_3_buttons();
                crystal_count_lbl.Text = (Convert.ToByte(crystal_count_lbl.Text) - 3).ToString();

                button7.Enabled = false;
                button8.Enabled = false;

                button7.BackgroundImage = global::students_sheet.Properties.Resources.act_cryst_btn;
                button8.BackgroundImage = global::students_sheet.Properties.Resources.act_cryst_btn;
            }
            else if (button9.Enabled == false && button8.Enabled == true && Convert.ToByte(crystal_count_lbl.Text) == 2)
            {
                crystal_count_lbl.Text = (Convert.ToByte(crystal_count_lbl.Text) - 2).ToString();

                button7.Enabled = false;
                button8.Enabled = false;

                button7.BackgroundImage = global::students_sheet.Properties.Resources.act_cryst_btn;
                button8.BackgroundImage = global::students_sheet.Properties.Resources.act_cryst_btn;

                radioButton7.Enabled = false;
                radioButton8.Enabled = false;
                radioButton9.Enabled = false;
            }
            else if (button8.Enabled == false && Convert.ToByte(crystal_count_lbl.Text) > 0)
            {
                crystal_count_lbl.Text = (Convert.ToByte(crystal_count_lbl.Text) - 1).ToString();

                button7.Enabled = false;
                button7.BackgroundImage = global::students_sheet.Properties.Resources.act_cryst_btn;

                radioButton7.Enabled = false;
                radioButton8.Enabled = false;
                radioButton9.Enabled = false;
            }
        }

        private void button15_Click(object sender, EventArgs e)
        {
            if (button9.Enabled == false && button8.Enabled == false && button7.Enabled == false)
                crystal_count_lbl.Text = (Convert.ToByte(crystal_count_lbl.Text) + 3).ToString();
            else if (button9.Enabled == false && button8.Enabled == false)
                crystal_count_lbl.Text = (Convert.ToByte(crystal_count_lbl.Text) + 2).ToString();
            else if (button9.Enabled == false)
                crystal_count_lbl.Text = (Convert.ToByte(crystal_count_lbl.Text) + 1).ToString();

            button7.Enabled = true;
            button8.Enabled = true;
            button9.Enabled = true;

            button7.BackgroundImage = global::students_sheet.Properties.Resources.pas_cryst_btn;
            button8.BackgroundImage = global::students_sheet.Properties.Resources.pas_cryst_btn;
            button9.BackgroundImage = global::students_sheet.Properties.Resources.pas_cryst_btn;

            radioButton7.Enabled = true;
            radioButton8.Enabled = true;
            radioButton9.Enabled = true;
        }

        private void students_notes_Load(object sender, EventArgs e)
        {
            var grade_list1 = new List<string> {"-", "12", "11", "10", "9", "8", "7", "6", "5", "4", "3", "2", "1" };
            var grade_list2 = new List<string> { "-", "12", "11", "10", "9", "8", "7", "6", "5", "4", "3", "2", "1" };
            var grade_list3 = new List<string> { "-", "12", "11", "10", "9", "8", "7", "6", "5", "4", "3", "2", "1" };
            var grade_list4 = new List<string> { "-", "12", "11", "10", "9", "8", "7", "6", "5", "4", "3", "2", "1" };
            var grade_list5 = new List<string> { "-", "12", "11", "10", "9", "8", "7", "6", "5", "4", "3", "2", "1" };
            var grade_list6 = new List<string> { "-", "12", "11", "10", "9", "8", "7", "6", "5", "4", "3", "2", "1" };

            comboBox1.DataSource = grade_list1;
            comboBox2.DataSource = grade_list2;
            comboBox3.DataSource = grade_list3;
            comboBox4.DataSource = grade_list4;
            comboBox5.DataSource = grade_list5;
            comboBox6.DataSource = grade_list6;
        }
    }
}
