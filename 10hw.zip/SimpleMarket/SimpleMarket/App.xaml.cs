﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Threading.Tasks;
using System.Windows;
using GalaSoft.MvvmLight;
using GalaSoft.MvvmLight.Messaging;
using SimpleInjector;
using SimpleMarket.ViewModel;
using SimpleMarket.View;
using SimpleMarket.Services.Classes;
using SimpleMarket.Services.Interfaces;
using SimpleMarket.Model;

namespace SimpleMarket
{
    /// <summary>
    /// Interaction logic for App.xaml
    /// </summary>
    public partial class App : Application
    {
        public static Container Container { get; set; }

        protected override void OnStartup(StartupEventArgs e)
        {
            Register();
            StartMain<MainViewModel>();
            base.OnStartup(e);
        }

        public void Register()
        {
            Container = new Container();

            Container.RegisterSingleton<INavigationService, NavigationService>();
            Container.RegisterSingleton<IMessenger, Messenger>();
            Container.RegisterSingleton<IConnectionClient, ConnectionClient>();

            Container.RegisterSingleton<MainViewModel>();
            Container.RegisterSingleton<AdminViewModel>();
            Container.RegisterSingleton<UserViewModel>();

            Container.Verify();
        }

        public void StartMain<T>() where T : ViewModelBase
        {
            Window window = new MainView();
            var viewModel = Container.GetInstance<T>();
            window.DataContext = viewModel;
            window.ShowDialog();
        }
    }
}
