﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using SimpleMarket.Model;
using System.Collections.ObjectModel;

namespace SimpleMarket.Services.Interfaces
{
    public interface IConnectionClient
    {
        public string GetJsonBase();
        public ObservableCollection<ProductModel> GetProducts();
    }
}
