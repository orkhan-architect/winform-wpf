﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using SimpleMarket.Services.Interfaces;
using SimpleMarket.Model;
using System.Text.Json;
using System.IO;
using System.Collections.ObjectModel;

namespace SimpleMarket.Services.Classes
{
    public class ConnectionClient : IConnectionClient
    {
        private readonly string filename = "products.json";
        public string GetJsonBase()
        {
            string jsonstring = "";
            if (File.Exists(filename))
                jsonstring = File.ReadAllText(filename);
            return jsonstring;
        }

        public ObservableCollection<ProductModel> GetProducts()
        {
            try
            {
                string jsonstring = GetJsonBase();

                var result = JsonSerializer.Deserialize<ObservableCollection<ProductModel>>(jsonstring);

                return result;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
    }
}
