﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using GalaSoft.MvvmLight;
using System.IO;
using System.Windows;
using System.Collections.ObjectModel;
using SimpleMarket.Model;
using SimpleMarket.Services.Interfaces;
using System.Text.Json;
using GalaSoft.MvvmLight;
using GalaSoft.MvvmLight.Command;
using GalaSoft.MvvmLight.Messaging;
using SimpleMarket.Messages;

namespace SimpleMarket.ViewModel
{
    public class UserViewModel : ViewModelBase
    {
        private IConnectionClient _connectionClient;
        private IMessenger _messenger;

        private float sum = 0.0F;

        private string? shopping;
        public string? Shopping
        {
            get { return shopping; }
            set { Set(ref shopping, value); }
        }

        private ObservableCollection<ProductModel> allProduct;
        public ObservableCollection<ProductModel> AllProduct
        {
            get { return allProduct; }
            set { Set(ref allProduct, value); }
        }

        private int selectedProductIndex;
        public int SelectedProductIndex
        {
            get { return selectedProductIndex; }
            set { Set(ref selectedProductIndex, value); }
        }

        private void UpdateProduct()
        {
            AllProduct = _connectionClient.GetProducts();
        }

        public UserViewModel(IConnectionClient connectionClient, IMessenger messenger)
        {
            _connectionClient = connectionClient;
            _messenger = messenger;

            AllProduct = connectionClient.GetProducts();

            _messenger.Register<UpdateMessage>(this, message => UpdateProduct());
        }

        private RelayCommand? buycommand;
        public RelayCommand? BuyCommand
        {
            get => buycommand ??= new RelayCommand(
              () =>
              {
                  float selectedProdPrice = AllProduct[SelectedProductIndex].Price;
                  sum += selectedProdPrice;

                  Shopping = sum.ToString();
              });
        }

        private RelayCommand? clearcommand;
        public RelayCommand? ClearCommand
        {
            get => clearcommand ??= new RelayCommand(
              () =>
              {
                  sum = 0;
                  Shopping = sum.ToString();
              });
        }
    }
}
