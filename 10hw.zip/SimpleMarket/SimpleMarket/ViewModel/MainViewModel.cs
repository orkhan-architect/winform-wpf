﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using GalaSoft.MvvmLight;
using GalaSoft.MvvmLight.Command;
using GalaSoft.MvvmLight.Messaging;
using SimpleMarket.Messages;
using SimpleMarket.Services.Interfaces;

namespace SimpleMarket.ViewModel
{
    public class MainViewModel : ViewModelBase
    {
        private ViewModelBase currentViewModel;

        private INavigationService NavigationService;
        private IMessenger Messenger;
        public ViewModelBase CurrentViewModel { get => currentViewModel; set => Set(ref currentViewModel, value); }

        public MainViewModel(IMessenger messenger, INavigationService navigationService)
        {
            NavigationService = navigationService;
            Messenger = messenger;

            messenger.Register<NavigationMessage>(this, message =>
            {
                var viewModel = App.Container.GetInstance(message.ViewModelType) as ViewModelBase;
                CurrentViewModel = viewModel;
            });
        }

        public RelayCommand AdminCommand
        {
            get => new RelayCommand(() =>
            {
                NavigationService.NavigateTo<AdminViewModel>();
            });
        }

        public RelayCommand UserCommand
        {
            get => new RelayCommand(() =>
            {
                NavigationService.NavigateTo<UserViewModel>();
                Messenger.Send(new UpdateMessage());
            });
        }
    }
}
