﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using SimpleMarket.Model;
using SimpleMarket.Services.Interfaces;
using GalaSoft.MvvmLight;
using GalaSoft.MvvmLight.Command;
using System.Collections.ObjectModel;
using System.Text.Json;
using System.IO;
using System.Windows;

namespace SimpleMarket.ViewModel
{
    public class AdminViewModel : ViewModelBase
    {
        private string filename = "products.json";
        private IConnectionClient _connectionClient;

        private string? productName;
        public string? ProductName
        {
            get { return productName; }
            set { Set(ref productName, value); }
        }

        private string? productDesc;
        public string? ProductDesc
        {
            get { return productDesc; }
            set { Set(ref productDesc, value); }
        }

        private string? productPrice;
        public string? ProductPrice
        {
            get { return productPrice; }
            set { Set(ref productPrice, value); }
        }

        private ObservableCollection<ProductModel> allProduct;
        public ObservableCollection<ProductModel> AllProduct
        {
            get { return allProduct; }
            set { Set(ref allProduct, value); }
        }

        private int selectedProductIndex;
        public int SelectedProductIndex
        {
            get { return selectedProductIndex; }
            set { Set(ref selectedProductIndex, value); }
        }

        public AdminViewModel(IConnectionClient connectionClient) 
        {
            _connectionClient = connectionClient;

            AllProduct = connectionClient.GetProducts();
        }

        private RelayCommand? addcommand;
        public RelayCommand? AddCommand
        {
            get => addcommand ??= new RelayCommand(
              () =>
              {
                  var newproduct = new ProductModel
                  {
                      Name = ProductName,
                      Description = ProductDesc,
                      Price = Convert.ToSingle(ProductPrice)
                  };

                  AllProduct.Add(newproduct);
              });
        }

        private RelayCommand? deletecommand;
        public RelayCommand? DeleteCommand
        {
            get => deletecommand ??= new RelayCommand(
              () =>
              {
                  AllProduct.RemoveAt(SelectedProductIndex);

                  var tmp_list = new ObservableCollection<ProductModel>();

                  for (int i = 0; i < AllProduct.Count; i++)
                      tmp_list.Add(AllProduct[i]);

                  AllProduct.Clear();

                  AllProduct = new ObservableCollection<ProductModel>();
                  for (int i = 0; i < tmp_list.Count; i++)
                      AllProduct.Add(tmp_list[i]);

                  tmp_list.Clear();
              });
        }

        private RelayCommand? savecommand;
        public RelayCommand? SaveCommand
        {
            get => savecommand ??= new RelayCommand(
              () =>
              {                  
                  string jsonstring = JsonSerializer.Serialize(AllProduct);
                  File.WriteAllText(filename, jsonstring);

                  MessageBox.Show("List saved successfullly");
              });
        }
    }
}
